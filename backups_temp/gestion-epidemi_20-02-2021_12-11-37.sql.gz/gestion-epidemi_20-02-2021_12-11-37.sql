--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5 (Ubuntu 12.5-1.pgdg18.04+1)
-- Dumped by pg_dump version 13.1 (Ubuntu 13.1-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.usuarios_preguntas DROP CONSTRAINT usuariospreguntas_ibfk_3;
ALTER TABLE ONLY public.usuarios_preguntas DROP CONSTRAINT usuariospreguntas_ibfk_1;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_ibfk_3;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_ibfk_1;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_fkey3;
ALTER TABLE ONLY public.personas DROP CONSTRAINT personas_ibfk_1;
ALTER TABLE ONLY public.personas DROP CONSTRAINT personas_fkey3;
ALTER TABLE ONLY public.casos_epidemi DROP CONSTRAINT casos_epidemi_ibfk_3;
ALTER TABLE ONLY public.casos_epidemi DROP CONSTRAINT casos_epidemi_ibfk_2;
ALTER TABLE ONLY public.casos_epidemi DROP CONSTRAINT casos_epidemi_ibfk_1;
ALTER TABLE ONLY public.casos_epidemi DROP CONSTRAINT casos_epidemi_fkey4;
ALTER TABLE ONLY public.casos_epidemi_bitacora DROP CONSTRAINT casos_epidemi_bitacora_ibkf_3;
DROP INDEX public.fki_usuarios_fkey3;
DROP INDEX public.fki_personas_fkey3;
DROP INDEX public.fki_orden_informe_casos_epidemi_bitacora_ibfk_3;
DROP INDEX public.fki_orden_informe_casos_epidemi_bitacora_ibfk_1;
DROP INDEX public.fki_casos_epidemi_fkey4;
DROP INDEX public.fki_casos_epidemi_bitacora_ibkf_3;
DROP INDEX public.fki_casos_epidemi_bitacora_ibfk_3;
DROP INDEX public.fki_casos_epidemi_bitacora_ibfk_2;
DROP INDEX public.fki_casos_epidemi_bitacora_ibfk_1;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.usuarios_preguntas DROP CONSTRAINT "usuariosPreguntas_pkey";
ALTER TABLE ONLY public.usuarios_preguntas_disponibles DROP CONSTRAINT "usuariosPreguntasDisponibles_pkey";
ALTER TABLE ONLY public.usuarios_niveles DROP CONSTRAINT "usuariosNiveles_pkey";
ALTER TABLE ONLY public.usuarios_estados DROP CONSTRAINT "usuariosEstados_pkey";
ALTER TABLE ONLY public.tipos_operaciones_caso DROP CONSTRAINT tipos_operaciones_pkey;
ALTER TABLE ONLY public.tipos_operaciones_caso DROP CONSTRAINT tipos_operaciones_descripcion_tipo_operacion_key;
ALTER TABLE ONLY public.tipos_de_entrada_caso_epidemi DROP CONSTRAINT tipos_de_entrada_caso_epidemi_pkey;
ALTER TABLE ONLY public.personas DROP CONSTRAINT personas_pkey;
ALTER TABLE public.personas DROP CONSTRAINT personas_id_nacionalidad_check;
ALTER TABLE ONLY public.parroquias DROP CONSTRAINT parroquias_pkey;
ALTER TABLE ONLY public.nacionalidades DROP CONSTRAINT nacionalidad_pkey;
ALTER TABLE ONLY public.generos DROP CONSTRAINT generos_pkey;
ALTER TABLE ONLY public.generos DROP CONSTRAINT "generos_idGenero_key1";
ALTER TABLE ONLY public.generos DROP CONSTRAINT "generos_idGenero_key";
ALTER TABLE ONLY public.data_cie10 DROP CONSTRAINT data_cie10_pkey;
ALTER TABLE ONLY public.data_cie10 DROP CONSTRAINT data_cie10_consecutivo_key;
ALTER TABLE ONLY public.data_cie10 DROP CONSTRAINT data_cie10_catalog_key_key;
ALTER TABLE ONLY public.casos_epidemi_bitacora DROP CONSTRAINT casos_epidemi_bitacora_pkey;
ALTER TABLE ONLY public.casos_epidemi DROP CONSTRAINT "casosEpidemi_pkey";
ALTER TABLE ONLY public.usuario_bitacora DROP CONSTRAINT bitacora_pkey;
ALTER TABLE ONLY public.atribs_especiales_epi DROP CONSTRAINT atribs_especiales_cie10_pkey;
ALTER TABLE ONLY public.agrupacion_epi DROP CONSTRAINT agrupacion_epi12_pkey;
ALTER TABLE public.atribs_especiales_epi ALTER COLUMN id_atrib_especial DROP DEFAULT;
ALTER TABLE public.agrupacion_epi ALTER COLUMN id_agrupacion DROP DEFAULT;
DROP TABLE public.usuarios_preguntas_disponibles;
DROP TABLE public.usuarios_preguntas;
DROP TABLE public.usuarios_estados;
DROP SEQUENCE public.person_seq;
DROP SEQUENCE public.casos_epidemiologicos_seq;
DROP SEQUENCE public.casos_epidemi_seq;
DROP VIEW public.casos_epidemi_bitacora_view;
DROP TABLE public.tipos_operaciones_caso;
DROP SEQUENCE public.tipos_operaciones_seq;
DROP VIEW public.caso_epidemi_view;
DROP TABLE public.tipos_de_entrada_caso_epidemi;
DROP TABLE public.parroquias;
DROP SEQUENCE public.parroquias_seq;
DROP TABLE public.data_cie10;
DROP TABLE public.casos_epidemi_bitacora;
DROP SEQUENCE public.casos_epidemi_bitacora_seq;
DROP TABLE public.casos_epidemi;
DROP SEQUENCE public.atribs_especiales_cie10_id_atrib_rango_seq;
DROP TABLE public.atribs_especiales_epi;
DROP SEQUENCE public.agrupacion_epi12_seq;
DROP SEQUENCE public.agrupacion_epi12_id_agrupacion_seq;
DROP TABLE public.agrupacion_epi;
DROP VIEW public.activity_log_sessions_view;
DROP TABLE public.usuarios_niveles;
DROP TABLE public.usuarios;
DROP TABLE public.usuario_bitacora;
DROP TABLE public.personas;
DROP SEQUENCE public.persona_seq;
DROP TABLE public.nacionalidades;
DROP TABLE public.generos;
DROP SEQUENCE public.bitacora_seq;
DROP FUNCTION public.test(par1 character varying, par2 character varying);
DROP FUNCTION public.strfrombool(value_bool boolean);
DROP FUNCTION public.iscie10inmediatenotice(n_inter character varying, nin character varying, ninmtobs character varying, notdiaria character varying, sistema_especial character varying, es_suive_notin character varying, es_suive_est_epi character varying, es_suive_est_brote character varying);
DROP FUNCTION public.get_doc_identidad_complete(id_nacionalidad integer, doc_identidad character varying);
DROP FUNCTION public.get_descripcion_nacionalidad(id character varying);
DROP FUNCTION public.get_descripcion_nacionalidad(id integer);
DROP EXTENSION unaccent;
DROP SCHEMA "dptoEpidemi0";
--
-- Name: dptoEpidemi0; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "dptoEpidemi0";


ALTER SCHEMA "dptoEpidemi0" OWNER TO postgres;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: get_descripcion_nacionalidad(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_descripcion_nacionalidad(id integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
if id = 1 then
		 return 'V';
		 elsif id = 2 then
		 return 'E';
	 elsif id = 0 then
		 return 'No Posee';
	  else 
		 return 'No Posee';
	  end if;
END;
$$;


ALTER FUNCTION public.get_descripcion_nacionalidad(id integer) OWNER TO postgres;

--
-- Name: get_descripcion_nacionalidad(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_descripcion_nacionalidad(id character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
      if id = '1' then
		 return 'V-';
		 elsif id = '2' then
		 return 'E-';
	  else 
		 return 'No Posee';
	  end if;
END;
$$;


ALTER FUNCTION public.get_descripcion_nacionalidad(id character varying) OWNER TO postgres;

--
-- Name: get_doc_identidad_complete(integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_doc_identidad_complete(id_nacionalidad integer, doc_identidad character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
  return (coalesce(get_descripcion_nacionalidad(id_nacionalidad::integer),'') || '' || coalesce(doc_identidad,''));
END;
$$;


ALTER FUNCTION public.get_doc_identidad_complete(id_nacionalidad integer, doc_identidad character varying) OWNER TO postgres;

--
-- Name: iscie10inmediatenotice(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.iscie10inmediatenotice(n_inter character varying, nin character varying, ninmtobs character varying, notdiaria character varying, sistema_especial character varying, es_suive_notin character varying, es_suive_est_epi character varying, es_suive_est_brote character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF n_inter = 'SI' THEN
     RETURN 'SI';
	ELSIF nin = 'SI' THEN
     RETURN 'SI';
	ELSIF ninmtobs = 'SI' THEN
     RETURN 'SI';
	ELSIF ninmtobs = 'SI' THEN
     RETURN 'SI';
	ELSIF notdiaria = 'SI' THEN
     RETURN 'SI';
	ELSIF sistema_especial = 'SI' THEN
     RETURN 'SI';
	ELSIF es_suive_notin = 'SI' THEN
     RETURN 'SI';
	ELSIF es_suive_est_epi = 'SI' THEN
     RETURN 'SI';
	ELSIF es_suive_est_brote = 'SI' THEN
     RETURN 'SI';
	END IF;
     RETURN 'NO';
	END;
$$;


ALTER FUNCTION public.iscie10inmediatenotice(n_inter character varying, nin character varying, ninmtobs character varying, notdiaria character varying, sistema_especial character varying, es_suive_notin character varying, es_suive_est_epi character varying, es_suive_est_brote character varying) OWNER TO postgres;

--
-- Name: strfrombool(boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.strfrombool(value_bool boolean) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN

if value_bool = true then
  	RETURN 'SI';
else
	RETURN 'NO';
END if;

END;
$$;


ALTER FUNCTION public.strfrombool(value_bool boolean) OWNER TO postgres;

--
-- Name: test(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.test(par1 character varying, par2 character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF par1 = 'SI' THEN
     RETURN 'SI';
	ELSIF par2 = 'SI' THEN
     RETURN 'SI';
	END IF;
     RETURN 'NO';
END;
$$;


ALTER FUNCTION public.test(par1 character varying, par2 character varying) OWNER TO postgres;

--
-- Name: bitacora_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bitacora_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bitacora_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: generos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generos (
    id_genero integer NOT NULL,
    descripcion_genero character varying(20) NOT NULL
);


ALTER TABLE public.generos OWNER TO postgres;

--
-- Name: nacionalidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nacionalidades (
    descripcion_nacionalidad character varying(20) NOT NULL,
    id_nacionalidad integer NOT NULL
);


ALTER TABLE public.nacionalidades OWNER TO postgres;

--
-- Name: persona_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.persona_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.persona_seq OWNER TO postgres;

--
-- Name: personas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personas (
    doc_identidad character varying(15),
    nombres character varying(50) NOT NULL,
    apellidos character varying(50) NOT NULL,
    fecha_nacimiento date NOT NULL,
    id_genero integer NOT NULL,
    id_person integer DEFAULT nextval('public.persona_seq'::regclass) NOT NULL,
    id_nacionalidad integer NOT NULL
);


ALTER TABLE public.personas OWNER TO postgres;

--
-- Name: usuario_bitacora; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario_bitacora (
    usuario_alias character varying(20) NOT NULL,
    id_bitacora integer DEFAULT nextval('public.bitacora_seq'::regclass) NOT NULL,
    bitacora_codigo character varying(15) NOT NULL,
    bitacora_fecha date NOT NULL,
    bitacora_hora_inicio character varying(12) NOT NULL,
    bitacora_hora_final character varying(12) DEFAULT NULL::character varying,
    bitacora_nivel_usuario integer NOT NULL,
    bitacora_year character varying(4) NOT NULL
);


ALTER TABLE public.usuario_bitacora OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    alias character varying(20) NOT NULL,
    id_nivel_permiso integer NOT NULL,
    id_estado integer NOT NULL,
    pass_encrypt character varying(130) NOT NULL,
    email character varying(100) NOT NULL,
    telefono character varying(11) NOT NULL,
    id_person integer NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_niveles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios_niveles (
    id_nivel_permiso integer NOT NULL,
    descripcion_nivel_permiso character varying(20) NOT NULL
);


ALTER TABLE public.usuarios_niveles OWNER TO postgres;

--
-- Name: activity_log_sessions_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.activity_log_sessions_view AS
 SELECT usr_bit.id_bitacora,
    row_number() OVER (ORDER BY usr_bit.id_bitacora DESC) AS row_number,
    pers.id_genero,
    gnro.descripcion_genero,
    pers.id_nacionalidad,
    nacion.descripcion_nacionalidad,
    (((nacion.descripcion_nacionalidad)::text || ''::text) || (pers.doc_identidad)::text) AS doc_identidad_complete,
    pers.doc_identidad,
    usr.alias,
    pers.nombres,
    pers.apellidos,
    usr_nivl.descripcion_nivel_permiso,
    usr_bit.bitacora_fecha,
    usr_bit.bitacora_hora_inicio,
    usr_bit.bitacora_hora_final
   FROM public.usuarios usr,
    public.personas pers,
    public.nacionalidades nacion,
    public.generos gnro,
    public.usuarios_niveles usr_nivl,
    public.usuario_bitacora usr_bit
  WHERE ((usr.id_person = pers.id_person) AND (pers.id_nacionalidad = nacion.id_nacionalidad) AND (pers.id_genero = gnro.id_genero) AND ((usr.alias)::text = (usr_bit.usuario_alias)::text) AND (usr_bit.bitacora_nivel_usuario = usr_nivl.id_nivel_permiso));


ALTER TABLE public.activity_log_sessions_view OWNER TO postgres;

--
-- Name: agrupacion_epi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agrupacion_epi (
    orden integer NOT NULL,
    enfermedad_evento_epi character varying(150) NOT NULL,
    key_cie10_inicio character varying(5),
    key_cie10_final character varying(5),
    id_agrupacion integer NOT NULL,
    edad_incio integer,
    edad_final integer,
    inicio_id_rango_atrib_especial integer DEFAULT 0,
    final_id_rango_atrib_especial integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.agrupacion_epi OWNER TO postgres;

--
-- Name: agrupacion_epi12_id_agrupacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agrupacion_epi12_id_agrupacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agrupacion_epi12_id_agrupacion_seq OWNER TO postgres;

--
-- Name: agrupacion_epi12_id_agrupacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agrupacion_epi12_id_agrupacion_seq OWNED BY public.agrupacion_epi.id_agrupacion;


--
-- Name: agrupacion_epi12_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agrupacion_epi12_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agrupacion_epi12_seq OWNER TO postgres;

--
-- Name: atribs_especiales_epi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atribs_especiales_epi (
    id_atrib_rango_especial integer NOT NULL,
    descripcion character varying(50),
    key_cie10_inicio character varying(6),
    key_cie10_final character varying(6),
    id_atrib_especial integer NOT NULL
);


ALTER TABLE public.atribs_especiales_epi OWNER TO postgres;

--
-- Name: atribs_especiales_cie10_id_atrib_rango_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.atribs_especiales_cie10_id_atrib_rango_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.atribs_especiales_cie10_id_atrib_rango_seq OWNER TO postgres;

--
-- Name: atribs_especiales_cie10_id_atrib_rango_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.atribs_especiales_cie10_id_atrib_rango_seq OWNED BY public.atribs_especiales_epi.id_atrib_especial;


--
-- Name: casos_epidemi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.casos_epidemi (
    id_caso_epidemi integer DEFAULT nextval('public.bitacora_seq'::regclass) NOT NULL,
    catalog_key_cie10 character varying(5) NOT NULL,
    id_parroquia integer NOT NULL,
    direccion character varying(200) NOT NULL,
    telefono character varying(11) NOT NULL,
    fecha_registro date NOT NULL,
    year_registro character varying(4) NOT NULL,
    id_atrib_especial integer DEFAULT 0 NOT NULL,
    is_hospital boolean DEFAULT false NOT NULL,
    id_person integer,
    id_tipo_entrada integer DEFAULT 1
);


ALTER TABLE public.casos_epidemi OWNER TO postgres;

--
-- Name: casos_epidemi_bitacora_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.casos_epidemi_bitacora_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.casos_epidemi_bitacora_seq OWNER TO postgres;

--
-- Name: casos_epidemi_bitacora; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.casos_epidemi_bitacora (
    id_bitacora integer DEFAULT nextval('public.casos_epidemi_bitacora_seq'::regclass) NOT NULL,
    usuario_alias character varying(20) NOT NULL,
    bitacora_fecha date NOT NULL,
    bitacora_hora character varying(12) NOT NULL,
    bitacora_year character varying(4) NOT NULL,
    id_tipo_operacion integer NOT NULL,
    fecha_caso_epidemi date NOT NULL,
    id_caso_epidemi integer NOT NULL,
    catalog_key_cie10 character varying(5) NOT NULL,
    doc_identidad_caso character varying(15),
    id_atrib_especial integer DEFAULT 0 NOT NULL,
    is_hospital boolean DEFAULT false NOT NULL,
    id_person_caso integer NOT NULL,
    id_nacionalidad_caso integer,
    id_person_usuario integer NOT NULL
);


ALTER TABLE public.casos_epidemi_bitacora OWNER TO postgres;

--
-- Name: data_cie10; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_cie10 (
    consecutivo integer NOT NULL,
    letra character varying(1) NOT NULL,
    catalog_key character varying(5) NOT NULL,
    nombre character varying(300) NOT NULL,
    codigox character varying(2) NOT NULL,
    lsex character varying(2) NOT NULL,
    linf character varying(4) NOT NULL,
    lsup character varying(4) NOT NULL,
    trivial character varying(2) NOT NULL,
    erradicado character varying(2) NOT NULL,
    n_inter character varying(2) NOT NULL,
    nin character varying(2) NOT NULL,
    ninmtobs character varying(2) NOT NULL,
    cod_sit_lesion character varying(2) NOT NULL,
    no_cbd character varying(2) NOT NULL,
    cbd character varying(2) NOT NULL,
    no_aph character varying(2) NOT NULL,
    af_prin character varying(2) NOT NULL,
    dia_sis character varying(2) NOT NULL,
    clave_programa_sis character varying(2) NOT NULL,
    cod_complemen_morbi character varying(2) NOT NULL,
    def_fetal_cm character varying(2) NOT NULL,
    def_fetal_cbd character varying(2) NOT NULL,
    clave_capitulo character varying(2) NOT NULL,
    capitulo character varying(200) NOT NULL,
    lista1 character varying(3) NOT NULL,
    grupo1 character varying(3) NOT NULL,
    lista5 character varying(3) NOT NULL,
    rubrica_type character varying(3) NOT NULL,
    year_modifi character varying(150) NOT NULL,
    year_aplicacion character varying(4) NOT NULL,
    valid character varying(2) NOT NULL,
    prinmorta character varying(4) NOT NULL,
    prinmorbi character varying(4) NOT NULL,
    lm_morbi character varying(4) NOT NULL,
    lm_morta character varying(5) NOT NULL,
    lgbd165 character varying(3) NOT NULL,
    lomsbeck character varying(3) NOT NULL,
    lgbd190 character varying(3) NOT NULL,
    notdiaria character varying(2) NOT NULL,
    notsemanal character varying(2) NOT NULL,
    sistema_especial character varying(2) NOT NULL,
    birmm character varying(2) NOT NULL,
    cve_causa_type character varying(2) NOT NULL,
    causa_type character varying(50) NOT NULL,
    epi_morta character varying(2) NOT NULL,
    edas_e_iras_en_m5 character varying(2) NOT NULL,
    csve_maternas_seed_epid character varying(2) NOT NULL,
    epi_morta_m5 character varying(2) NOT NULL,
    epi_morbi character varying(2) NOT NULL,
    def_maternas character varying(3) NOT NULL,
    es_causes character varying(2) NOT NULL,
    num_causes character varying(3) NOT NULL,
    es_suive_morta character varying(2) NOT NULL,
    es_suive_morb character varying(2) NOT NULL,
    epi_clave character varying(5) NOT NULL,
    epi_clave_desc character varying(120) NOT NULL,
    es_suive_notin character varying(2) NOT NULL,
    es_suive_est_epi character varying(2) NOT NULL,
    es_suive_est_brote character varying(2) NOT NULL,
    sinac character varying(2) NOT NULL,
    prin_sinac character varying(3) NOT NULL,
    prin_sinac_grupo character varying(2) NOT NULL,
    descripcion_sinac_grupo character varying(180) NOT NULL,
    prin_sinac_subgrupo character varying(3) NOT NULL,
    descripcion_sinac_subgrupo character varying(180) NOT NULL,
    daga character varying(2) NOT NULL,
    asterisco character varying(2) NOT NULL
);


ALTER TABLE public.data_cie10 OWNER TO postgres;

--
-- Name: parroquias_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parroquias_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parroquias_seq OWNER TO postgres;

--
-- Name: parroquias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parroquias (
    id_parroquia integer DEFAULT nextval('public.parroquias_seq'::regclass) NOT NULL,
    id_municipio integer NOT NULL,
    parroquia character varying(250) NOT NULL
);


ALTER TABLE public.parroquias OWNER TO postgres;

--
-- Name: tipos_de_entrada_caso_epidemi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipos_de_entrada_caso_epidemi (
    id_tipo_entrada integer NOT NULL,
    descripcion_tipo_entrada character varying(10) NOT NULL
);


ALTER TABLE public.tipos_de_entrada_caso_epidemi OWNER TO postgres;

--
-- Name: caso_epidemi_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.caso_epidemi_view AS
 SELECT DISTINCT ON (caso.id_caso_epidemi) caso.id_caso_epidemi,
    row_number() OVER () AS row_number,
    caso.telefono,
    caso.catalog_key_cie10,
    caso.fecha_registro,
    caso.direccion,
    public.strfrombool(caso.is_hospital) AS hospitalizado,
    caso.is_hospital,
    caso.id_atrib_especial,
    atr_esp.descripcion AS atributo_especial,
    parr.parroquia,
    parr.id_parroquia,
    casos_bit.id_bitacora,
    casos_bit.usuario_alias,
    casos_bit.bitacora_year,
    casos_bit.bitacora_fecha,
    casos_bit.bitacora_hora,
    pers.nombres,
    pers.apellidos,
    pers.fecha_nacimiento,
    pers.id_genero,
    (date_part('year'::text, age((caso.fecha_registro)::timestamp with time zone, (pers.fecha_nacimiento)::timestamp with time zone)))::integer AS edad,
    pers.id_person AS id_person_caso,
    pers.id_nacionalidad AS id_nacionalidad_caso,
    pers.doc_identidad AS doc_identidad_caso,
    public.get_doc_identidad_complete(pers.id_nacionalidad, pers.doc_identidad) AS doc_identidad_caso_complete,
    ( SELECT public.get_doc_identidad_complete(personas.id_nacionalidad, personas.doc_identidad) AS get_doc_identidad_complete
           FROM public.personas
          WHERE (personas.id_person = casos_bit.id_person_usuario)) AS doc_identidad_usuario_complete,
    gnro.descripcion_genero AS descripcion_genero_caso,
    cie10.nombre AS nombre_cie10,
    cie10.clave_capitulo AS clave_capitulo_cie10,
    split_part((cie10.capitulo)::text, ' '::text, 1) AS capitulo_cie10,
    caso.id_tipo_entrada,
    entrad_caso.descripcion_tipo_entrada AS descrip_entrad_caso,
    public.iscie10inmediatenotice(cie10.n_inter, cie10.nin, cie10.ninmtobs, cie10.notdiaria, cie10.sistema_especial, cie10.es_suive_notin, cie10.es_suive_est_epi, cie10.es_suive_est_brote) AS notific_inmediata
   FROM public.casos_epidemi caso,
    public.casos_epidemi_bitacora casos_bit,
    public.personas pers,
    public.parroquias parr,
    public.generos gnro,
    public.data_cie10 cie10,
    public.atribs_especiales_epi atr_esp,
    public.tipos_de_entrada_caso_epidemi entrad_caso
  WHERE ((caso.id_caso_epidemi = casos_bit.id_caso_epidemi) AND (caso.id_person = pers.id_person) AND (caso.id_parroquia = parr.id_parroquia) AND (pers.id_genero = gnro.id_genero) AND (casos_bit.id_tipo_operacion = 1) AND (caso.id_tipo_entrada = entrad_caso.id_tipo_entrada) AND (caso.id_atrib_especial = atr_esp.id_atrib_especial) AND ((caso.catalog_key_cie10)::text = (cie10.catalog_key)::text));


ALTER TABLE public.caso_epidemi_view OWNER TO postgres;

--
-- Name: tipos_operaciones_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipos_operaciones_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipos_operaciones_seq OWNER TO postgres;

--
-- Name: tipos_operaciones_caso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipos_operaciones_caso (
    id_tipo_operacion integer DEFAULT nextval('public.tipos_operaciones_seq'::regclass) NOT NULL,
    descripcion_tipo_operacion character varying(15) NOT NULL
);


ALTER TABLE public.tipos_operaciones_caso OWNER TO postgres;

--
-- Name: casos_epidemi_bitacora_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.casos_epidemi_bitacora_view AS
 SELECT DISTINCT ON (casos_bit.id_bitacora) casos_bit.id_bitacora,
    row_number() OVER (ORDER BY casos_bit.id_bitacora DESC) AS row_number,
    casos_bit.id_caso_epidemi,
    casos_bit.catalog_key_cie10,
    casos_bit.fecha_caso_epidemi,
    casos_bit.usuario_alias,
    casos_bit.id_person_usuario,
    casos_bit.id_person_caso,
    casos_bit.doc_identidad_caso,
    casos_bit.id_nacionalidad_caso,
    public.get_doc_identidad_complete(casos_bit.id_nacionalidad_caso, casos_bit.doc_identidad_caso) AS doc_identidad_caso_complete,
    ( SELECT public.get_doc_identidad_complete(personas.id_nacionalidad, personas.doc_identidad) AS get_doc_identidad_complete
           FROM public.personas
          WHERE (personas.id_person = casos_bit.id_person_usuario)) AS doc_identidad_usuario_complete,
    tpo.descripcion_tipo_operacion,
    casos_bit.bitacora_fecha,
    casos_bit.bitacora_hora,
    public.strfrombool(casos_bit.is_hospital) AS hospitalizado,
    atr_esp.descripcion AS atributo_especial
   FROM public.casos_epidemi_bitacora casos_bit,
    public.tipos_operaciones_caso tpo,
    public.atribs_especiales_epi atr_esp
  WHERE ((tpo.id_tipo_operacion = casos_bit.id_tipo_operacion) AND (casos_bit.id_atrib_especial = atr_esp.id_atrib_especial))
  ORDER BY casos_bit.id_bitacora DESC;


ALTER TABLE public.casos_epidemi_bitacora_view OWNER TO postgres;

--
-- Name: casos_epidemi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.casos_epidemi_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.casos_epidemi_seq OWNER TO postgres;

--
-- Name: casos_epidemiologicos_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.casos_epidemiologicos_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.casos_epidemiologicos_seq OWNER TO postgres;

--
-- Name: person_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.person_seq OWNER TO postgres;

--
-- Name: usuarios_estados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios_estados (
    id_estado integer NOT NULL,
    descripcion_estado character varying(20) NOT NULL
);


ALTER TABLE public.usuarios_estados OWNER TO postgres;

--
-- Name: usuarios_preguntas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios_preguntas (
    usuario_alias character varying(20) NOT NULL,
    id_pregunta integer NOT NULL,
    respuesta character varying(150) NOT NULL
);


ALTER TABLE public.usuarios_preguntas OWNER TO postgres;

--
-- Name: usuarios_preguntas_disponibles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios_preguntas_disponibles (
    id_pregunta integer NOT NULL,
    descripcion_preguntas character varying(50) NOT NULL
);


ALTER TABLE public.usuarios_preguntas_disponibles OWNER TO postgres;

--
-- Name: agrupacion_epi id_agrupacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agrupacion_epi ALTER COLUMN id_agrupacion SET DEFAULT nextval('public.agrupacion_epi12_id_agrupacion_seq'::regclass);


--
-- Name: atribs_especiales_epi id_atrib_especial; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atribs_especiales_epi ALTER COLUMN id_atrib_especial SET DEFAULT nextval('public.atribs_especiales_cie10_id_atrib_rango_seq'::regclass);


--
-- Data for Name: agrupacion_epi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agrupacion_epi (orden, enfermedad_evento_epi, key_cie10_inicio, key_cie10_final, id_agrupacion, edad_incio, edad_final, inicio_id_rango_atrib_especial, final_id_rango_atrib_especial) FROM stdin;
6	DIARREA SIN DESHIDRATACION (A08-A09)	A08	A09	6	0	200	1	1
1	I) ENFERM. INFECCIOSAS Y PARASITARIAS	A00	A09	1	0	200	0	20
2	I.a) TRANSMISION HIDRICA Y ALIMENTOS	A08	A09	2	0	200	0	20
3	DIARREAS <1a. (A08-A09)	A08	A09	3	0	0	0	20
4	DIARREAS 1-4a.(A08-A09)	A08	A09	4	1	4	0	20
5	DIARREAS 5a. Y MAS (A08-A09)	A08	A09	5	5	200	0	20
7	GIARDIASIS (A07.1)	A07	A071	7	0	200	0	20
8	OTRAS CAUSAS DE CONSULTA	9999	9999	8	0	200	0	20
9	PACIENTES HOSPITALIZADOS O REFERIDOS PARA HOSPITALIZACION	A00	Z999	9	0	200	0	20
9	PACIENTES HOSPITALIZADOS O REFERIDOS PARA HOSPITALIZACION	9999	9999	10	0	200	0	20
10	TOTAL CAUSAS DE CONSULTA	A00	Z999	11	0	200	0	20
10	TOTAL CAUSAS DE CONSULTA	9999	9999	12	0	200	0	20
\.


--
-- Data for Name: atribs_especiales_epi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atribs_especiales_epi (id_atrib_rango_especial, descripcion, key_cie10_inicio, key_cie10_final, id_atrib_especial) FROM stdin;
1	DIARREA SIN DESHIDRATACION (A08-A09)	A08	A09	1
2	DIARREA CON DESHIDRATACION LEVE/MODERADA (A08-A09)	A08	A09	2
0	Ninguno	\N	\N	0
\.


--
-- Data for Name: casos_epidemi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.casos_epidemi (id_caso_epidemi, catalog_key_cie10, id_parroquia, direccion, telefono, fecha_registro, year_registro, id_atrib_especial, is_hospital, id_person, id_tipo_entrada) FROM stdin;
28958	D50	1123	Mi casa	04120304030	2021-02-04	2021	0	t	70	2
28966	A20	1124	Mi casa	04120304040	2021-02-14	2021	0	t	75	1
28957	A06	1123	Mi casa	04120304030	2021-02-01	2021	0	t	70	1
28959	C068	1124	Mi casa	04120040994	2020-02-14	2020	0	t	71	1
28961	D50	1123	Mi casa	04128384938	2021-02-04	2021	0	f	72	2
\.


--
-- Data for Name: casos_epidemi_bitacora; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.casos_epidemi_bitacora (id_bitacora, usuario_alias, bitacora_fecha, bitacora_hora, bitacora_year, id_tipo_operacion, fecha_caso_epidemi, id_caso_epidemi, catalog_key_cie10, doc_identidad_caso, id_atrib_especial, is_hospital, id_person_caso, id_nacionalidad_caso, id_person_usuario) FROM stdin;
12666	admin	2021-02-14	11:27:26 am	2021	1	2021-02-13	28930	E00	3040400	0	f	70	1	0
12667	admin	2021-02-15	01:06:37 pm	2021	1	2021-02-14	28944	D50	3040400	0	f	70	1	0
12668	admin	2021-02-15	01:07:43 pm	2021	1	2021-02-13	28945	D50	3040400	0	f	70	1	0
12669	admin	2021-02-15	02:45:27 pm	2021	1	2021-02-14	28947	D510	3040400	0	f	70	1	0
12670	admin	2021-02-15	02:50:45 pm	2021	3	2021-02-14	28947	III	\N	0	t	70	0	0
12682	newman207	2021-02-15	04:34:35 pm	2021	3	2021-02-13	28945	III	3040400	0	t	70	1	67
12683	newman207	2021-02-15	05:19:09 pm	2021	2	2021-02-14	28944	D50	3040400	0	t	70	1	67
12684	newman207	2021-02-15	09:26:08 pm	2021	2	2021-02-14	28944	D50	3040400	0	t	70	1	67
12685	newman207	2021-02-15	09:39:10 pm	2021	1	2021-02-01	28957	D50	3040400	0	t	70	1	67
12686	newman207	2021-02-15	09:50:57 pm	2021	1	2021-02-04	28958	D50	3040400	0	t	70	1	67
12687	newman207	2021-02-15	10:06:09 pm	2021	1	2021-02-14	28959	E00	\N	0	t	71	0	67
12688	newman207	2021-02-15	10:06:47 pm	2021	1	2021-02-14	28960	E00	\N	0	t	72	0	67
12689	newman207	2021-02-15	10:22:29 pm	2021	3	2021-02-13	28930	IV	3040400	0	t	70	1	67
12691	newman207	2021-02-15	11:05:02 pm	2021	2	2021-02-14	28960	E00		0	t	72	0	67
12692	newman207	2021-02-15	11:05:38 pm	2021	2	2021-02-14	28960	E00		0	t	72	0	67
12693	newman207	2021-02-15	11:08:25 pm	2021	1	2021-02-04	28961	E00	\N	0	f	72	0	67
12694	newman207	2021-02-16	12:02:06 pm	2021	2	2021-02-14	28960	E00		0	t	72	0	67
12695	newman207	2021-02-16	12:04:33 pm	2021	3	2021-02-14	28960	IV	\N	0	t	72	0	67
12696	admin	2021-02-16	10:26:05 pm	2021	2	2021-02-14	28944	D50	3040400	0	f	70	1	0
12697	admin	2021-02-16	10:26:41 pm	2021	2	2021-02-14	28944	A09	3040400	0	f	70	1	0
12698	admin	2021-02-16	10:27:30 pm	2021	2	2021-02-14	28944	A09	3040400	0	f	70	1	0
12699	admin	2021-02-16	11:01:49 pm	2021	1	2021-02-14	28966	A20	\N	0	t	75	0	0
12700	newman207	2021-02-19	06:36:39 pm	2021	2	1980-02-14	28959	E00		0	t	71	0	67
12701	newman207	2021-02-19	06:37:25 pm	2021	2	2021-02-01	28957	D50	3040400	0	t	70	1	67
12702	newman207	2021-02-19	06:38:00 pm	2021	2	2021-02-01	28957	J180	3040400	0	t	70	1	67
12703	newman207	2021-02-19	06:38:49 pm	2021	2	2021-02-01	28957	J21	3040400	0	t	70	1	67
12704	newman207	2021-02-19	06:39:02 pm	2021	2	2021-02-01	28957	J219	3040400	0	t	70	1	67
12705	newman207	2021-02-20	11:09:42 am	2021	2	2020-02-14	28959	E00		0	t	71	0	67
12706	newman207	2021-02-20	11:10:24 am	2021	2	2021-02-01	28957	A06	3040400	0	t	70	1	67
12707	newman207	2021-02-20	11:11:09 am	2021	2	2020-02-14	28959	C068		0	t	71	0	67
12708	newman207	2021-02-20	11:11:38 am	2021	2	2021-02-04	28961	D50		0	f	72	0	67
\.


--
-- Data for Name: data_cie10; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_cie10 (consecutivo, letra, catalog_key, nombre, codigox, lsex, linf, lsup, trivial, erradicado, n_inter, nin, ninmtobs, cod_sit_lesion, no_cbd, cbd, no_aph, af_prin, dia_sis, clave_programa_sis, cod_complemen_morbi, def_fetal_cm, def_fetal_cbd, clave_capitulo, capitulo, lista1, grupo1, lista5, rubrica_type, year_modifi, year_aplicacion, valid, prinmorta, prinmorbi, lm_morbi, lm_morta, lgbd165, lomsbeck, lgbd190, notdiaria, notsemanal, sistema_especial, birmm, cve_causa_type, causa_type, epi_morta, edas_e_iras_en_m5, csve_maternas_seed_epid, epi_morta_m5, epi_morbi, def_maternas, es_causes, num_causes, es_suive_morta, es_suive_morb, epi_clave, epi_clave_desc, es_suive_notin, es_suive_est_epi, es_suive_est_brote, sinac, prin_sinac, prin_sinac_grupo, descripcion_sinac_grupo, prin_sinac_subgrupo, descripcion_sinac_subgrupo, daga, asterisco) FROM stdin;
43	A	A06	AMEBIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
15	A	A028	OTRAS INFECCIONES ESPECIFICADAS COMO DEBIDAS A SALMONELLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	177	OTRAS SALMONELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
16	A	A029	INFECCIÓN DEBIDA A SALMONELLA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	177	OTRAS SALMONELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
13	A	A021	SEPSIS DEBIDA A SALMONELLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	C	2010 CORRECCION TITULOS	2014	SI	001	001	01E	01E	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	177	OTRAS SALMONELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
17	A	A03	SHIGELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
18	A	A030	SHIGELOSIS DEBIDA A SHIGELLA DYSENTERIAE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
19	A	A031	SHIGELOSIS DEBIDA A SHIGELLA FLEXNERI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
20	A	A032	SHIGELOSIS DEBIDA A SHIGELLA BOYDII	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
335	A	A67	PINTA [CARATE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
21	A	A033	SHIGELOSIS DEBIDA A SHIGELLA SONNEI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
22	A	A038	OTRAS SHIGELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1359	C	C814	LINFOMA DE HODGKIN CLÁSICO RICO EN LINFOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	A	2010 NUEVA CATEGORIA	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
14	A	A022	INFECCIONES LOCALIZADAS DEBIDAS A SALMONELLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	C	2003 (SE ELIMINO DAGA)	2003	SI	001	001	01E	01E	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	177	OTRAS SALMONELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
8	A	A012	FIEBRE PARATIFOIDEA B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	01C	01C	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	SI	56	NO	NO	178	FIEBRE PARATIFOIDEA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
10	A	A014	FIEBRE PARATIFOIDEA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	01C	01C	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	SI	56	NO	NO	178	FIEBRE PARATIFOIDEA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1581	D	D142	TUMOR BENIGNO DE LA TRÁQUEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
23	A	A039	SHIGELOSIS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	003	NO	NO	NO	SI	001	001	01D	01D	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	05	SHIGELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
24	A	A04	OTRAS INFECCIONES INTESTINALES BACTERIANAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	SI	55	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1744	D	D392	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA PLACENTA	NO	2	010A	054A	NO	NO	NO	NO	SI	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	122	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
9	A	A013	FIEBRE PARATIFOIDEA C	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	01C	01C	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	SI	56	NO	NO	178	FIEBRE PARATIFOIDEA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
25	A	A040	INFECCIÓN DEBIDA A ESCHERICHIA COLI ENTEROPATÓGENA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
11	A	A02	OTRAS INFECCIONES DEBIDAS A SALMONELLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
26	A	A041	INFECCIÓN DEBIDA A ESCHERICHIA COLI ENTEROTOXÍGENA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1079	C	C313	TUMOR MALIGNO DEL SENO ESFENOIDAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1954	D	D801	HIPOGAMMAGLOBULINEMIA NO FAMILIAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
12	A	A020	ENTERITIS DEBIDA A SALMONELLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	56	SI	SI	177	OTRAS SALMONELOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1	A	A00	CÓLERA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	002	001	001	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	SI	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
2	A	A000	CÓLERA DEBIDO A VIBRIO CHOLERAE 01, BIOTIPO CHOLERAE	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	002	001	001	NO	NO	NO	SI	001	001	01A	01A	10	1	10	SI	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	01	COLERA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
3	A	A001	CÓLERA DEBIDO A VIBRIO CHOLERAE 01, BIOTIPO EL TOR	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	002	001	001	NO	NO	NO	SI	001	001	01A	01A	10	1	10	SI	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	01	COLERA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
4	A	A009	CÓLERA, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	002	001	001	NO	NO	NO	SI	001	001	01A	01A	10	1	10	SI	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	01	COLERA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
5	A	A01	FIEBRES TIFOIDEA Y PARATIFOIDEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
6	A	A010	FIEBRE TIFOIDEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	01B	01B	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	57	SI	SI	06	FIEBRE TIFOIDEA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
7	A	A011	FIEBRE PARATIFOIDEA A	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	002	NO	NO	NO	SI	001	001	01C	01C	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	56	SI	SI	178	FIEBRE PARATIFOIDEA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
27	A	A042	INFECCIÓN DEBIDA A ESCHERICHIA COLI ENTEROINVASIVA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
28	A	A043	INFECCIÓN DEBIDA A ESCHERICHIA COLI ENTEROHEMORRÁGICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
29	A	A044	OTRAS INFECCIONES INTESTINALES DEBIDAS A ESCHERICHIA COLI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
30	A	A045	ENTERITIS DEBIDA A CAMPYLOBACTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
31	A	A046	ENTERITIS DEBIDA A YERSINIA ENTEROCOLITICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
32	A	A047	ENTEROCOLITIS DEBIDA A CLOSTRIDIUM DIFFICILE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
34	A	A049	INFECCIÓN INTESTINAL BACTERIANA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
35	A	A05	OTRAS INTOXICACIONES ALIMENTARIAS BACTERIANAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	C	2006 (SE AGREGO NCOP)	2006	SI	001	001	NO	NO	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	168	NO	SI	NO	NO	NO	NO	SI	NO	000	NO	NO	NO	NO	NO	NO
36	A	A050	INTOXICACIÓN ALIMENTARIA ESTAFILOCÓCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
1026	C	C18	TUMOR MALIGNO DEL COLON	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	NO	NO	NO	10	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
37	A	A051	BOTULISMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
38	A	A052	INTOXICACIÓN ALIMENTARIA DEBIDA A CLOSTRIDIUM PERFRINGENS [CLOSTRIDIUM WELCHII	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
39	A	A053	INTOXICACIÓN ALIMENTARIA DEBIDA A VIBRIO PARAHAEMOLYTICUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
40	A	A054	INTOXICACIÓN ALIMENTARIA DEBIDA A BACILLUS CEREUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
41	A	A058	OTRAS INTOXICACIONES ALIMENTARIAS DEBIDAS A BACTERIAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
42	A	A059	INTOXICACIÓN ALIMENTARIA BACTERIANA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01E	01E	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	168	SI	SI	09	INTOXICACION ALIMENTARIA BACTERIANA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
44	A	A060	DISENTERÍA AMEBIANA AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	68	SI	SI	02	AMEBIASIS INTESTINAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
45	A	A061	AMEBIASIS INTESTINAL CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	68	SI	SI	02	AMEBIASIS INTESTINAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
46	A	A062	COLITIS AMEBIANA NO DISENTÉRICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	68	SI	SI	02	AMEBIASIS INTESTINAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
47	A	A063	AMEBOMA INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	68	SI	SI	02	AMEBIASIS INTESTINAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
48	A	A064	ABSCESO AMEBIANO DEL HÍGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	SI	206	NO	SI	03	ABSCESO HEPATICO AMEBIANO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
33	A	A048	OTRAS INFECCIONES INTESTINALES BACTERIANAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
49	A	A065	ABSCESO AMEBIANO DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
50	A	A066	ABSCESO AMEBIANO DEL CEREBRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
51	A	A067	AMEBIASIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
52	A	A068	INFECCIÓN AMEBIANA DE OTRAS LOCALIZACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
53	A	A069	AMEBIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	004	NO	NO	NO	SI	001	001	01F	01F	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	02	AMEBIASIS INTESTINAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
54	A	A07	OTRAS ENFERMEDADES INTESTINALES DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
55	A	A070	BALANTIDIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	93	OTRAS INFECCIONES INTESTINALES DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
56	A	A071	GIARDIASIS [LAMBLIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	76	SI	SI	07	GIARDIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
57	A	A072	CRIPTOSPORIDIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	93	OTRAS INFECCIONES INTESTINALES DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
58	A	A073	ISOSPORIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
59	A	A078	OTRAS ENFERMEDADES INTESTINALES ESPECIFICADAS DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	NO	0	SI	55	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
60	A	A079	ENFERMEDAD INTESTINAL DEBIDA A PROTOZOARIOS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	93	OTRAS INFECCIONES INTESTINALES DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
61	A	A08	INFECCIONES INTESTINALES DEBIDAS A VIRUS Y OTROS ORGANISMOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	NO	NO	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
62	A	A080	ENTERITIS DEBIDA A ROTAVIRUS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	137	ENTERITIS DEBIDA A ROTAVIRUS	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
63	A	A081	GASTROENTEROPATÍA AGUDA DEBIDA AL AGENTE DE NORWALK	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
64	A	A082	ENTERITIS DEBIDA A ADENOVIRUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
65	A	A083	OTRAS ENTERITIS VIRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
66	A	A084	INFECCIÓN INTESTINAL VIRAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
67	A	A085	OTRAS INFECCIONES INTESTINALES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	004	001	006	NO	NO	NO	SI	001	001	01G	01G	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
68	A	A09	OTRAS GASTROENTERITIS Y COLITIS DE ORIGEN INFECCIOSO Y NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	003	001	005	A	2010 CAMBIO X SUBCATEGORIAS Y CAMBIO DE TITULO	2014	SI	001	001	01H	01H	NO	1	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	SI	55	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
69	A	A090	OTRAS GASTROENTERITIS Y COLITIS DE ORIGEN INFECCIOSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	003	001	005	A	2010 NUEVA CATEGORIA	2014	SI	001	001	01H	01H	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
70	A	A099	GASTROENTERITIS Y COLITIS DE ORIGEN NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	003	001	005	A	2010 NUEVA CATEGORIA	2014	SI	001	001	01H	01H	10	1	10	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	NO	SI	0	SI	55	SI	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
71	A	A09X	DIARREA Y GASTROENTERITIS DE PRESUNTO ORIGEN INFECCIOSO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	003	001	005	B	2010 CAMBIO X SUBCATEGORIAS	2014	NO	001	001	01H	01H	10	1	10	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	NO	0	SI	55	NO	SI	08	INFECCIONES INTESTINALES POR OTROS ORGANISMOS Y LAS MAL DEFINIDAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
72	A	A15	TUBERCULOSIS RESPIRATORIA, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	NO	NO	NO	2	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
73	A	A150	TUBERCULOSIS DEL PULMÓN, CONFIRMADA POR HALLAZGO MICROSCÓPICO DEL BACILO TUBERCULOSO EN ESPUTO, CON O SIN CULTIVO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
74	A	A151	TUBERCULOSIS DEL PULMÓN, CONFIRMADA ÚNICAMENTE POR CULTIVO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
75	A	A152	TUBERCULOSIS DEL PULMÓN, CONFIRMADA HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
76	A	A153	TUBERCULOSIS DEL PULMÓN, CONFIRMADA POR MEDIOS NO ESPECIFICADOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
77	A	A154	TUBERCULOSIS DE GANGLIOS LINFÁTICOS INTRATORÁCICOS, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
78	A	A155	TUBERCULOSIS DE LARINGE, TRAQUEA Y BRONQUIOS, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
79	A	A156	PLEURESÍA TUBERCULOSA, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
80	A	A157	TUBERCULOSIS RESPIRATORIA PRIMARIA, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
81	A	A158	OTRAS TUBERCULOSIS RESPIRATORIAS, CONFIRMADAS BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
82	A	A159	TUBERCULOSIS RESPIRATORIA NO ESPECIFICADA, CONFIRMADA BACTERIOLÓGICA E HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
83	A	A16	TUBERCULOSIS RESPIRATORIA, NO CONFIRMADA BACTERIOLÓGICA O HISTOLÓGICAMENTE	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	NO	NO	NO	2	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
84	A	A160	TUBERCULOSIS DEL PULMÓN, CON EXAMEN BACTERIOLÓGICO E HISTOLÓGICO NEGATIVOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
85	A	A161	TUBERCULOSIS DE PULMÓN, SIN EXAMEN BACTERIOLÓGICO E HISTOLÓGICO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
86	A	A162	TUBERCULOSIS DE PULMÓN, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
87	A	A163	TUBERCULOSIS DE GANGLIOS LINFÁTICOS INTRATORÁCICOS, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
88	A	A164	TUBERCULOSIS DE LARINGE, TRAQUEA Y BRONQUIOS, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
89	A	A165	PLEURESÍA TUBERCULOSA, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
90	A	A167	TUBERCULOSIS RESPIRATORIA PRIMARIA, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
91	A	A168	OTRAS TUBERCULOSIS RESPIRATORIAS, SIN MENCIÓN DE CONFIRMACIÓN	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	999	999	02B	02B	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
92	A	A169	TUBERCULOSIS RESPIRATORIA NO ESPECIFICADA, SIN MENCIÓN DE CONFIRMACIÓN BACTERIOLÓGICA O HISTOLÓGICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	005	001	007	NO	NO	NO	SI	002	002	02A	02A	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	19	TUBERCULOSIS RESPIRATORIA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
94	A	A170	MENINGITIS TUBERCULOSA	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	003	003	02C	02C	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	44	MENINGITIS TUBERCULOSA	SI	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
95	A	A171	TUBERCULOMA MENÍNGEO	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	003	003	02C	02C	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
96	A	A178	OTRAS TUBERCULOSIS DEL SISTEMA NERVIOSO	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	003	003	02C	02C	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
97	A	A179	TUBERCULOSIS DEL SISTEMA NERVIOSO, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	003	003	02C	02C	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	51	SI	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
98	A	A18	TUBERCULOSIS DE OTROS ÓRGANOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	NO	NO	NO	2	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
99	A	A180	TUBERCULOSIS DE HUESOS Y ARTICULACIONES	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	005	005	02E	02E	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
100	A	A181	TUBERCULOSIS DEL APARATO GENITOURINARIO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	C	2003 (SE ELIMINO DAGA)	2003	SI	006	006	02F	02F	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
101	A	A182	LINFADENOPATÍA PERIFÉRICA TUBERCULOSA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
102	A	A183	TUBERCULOSIS DE LOS INTESTINOS, EL PERITONEO Y LOS GANGLIOS MESENTÉRICOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	004	004	02D	02D	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
103	A	A184	TUBERCULOSIS DE LA PIEL Y EL TEJIDO SUBCUTÁNEO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
104	A	A185	TUBERCULOSIS DEL OJO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	C	2003 (SE ELIMINO DAGA)	2003	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
105	A	A186	TUBERCULOSIS DEL OÍDO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	C	2003 (SE ELIMINO DAGA)	2003	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
106	A	A187	TUBERCULOSIS DE GLÁNDULAS SUPRARRENALES	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
107	A	A188	TUBERCULOSIS DE OTROS ÓRGANOS ESPECIFICADOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
93	A	A17	TUBERCULOSIS DEL SISTEMA NERVIOSO	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	003	003	NO	NO	NO	2	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	51	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	SI	NO
108	A	A19	TUBERCULOSIS MILIAR	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	NO	NO	NO	2	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
109	A	A190	TUBERCULOSIS MILIAR AGUDA DE UN SOLO SITIO ESPECIFICADO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
110	A	A191	TUBERCULOSIS MILIAR AGUDA DE SITIOS MÚLTIPLES	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
111	A	A192	TUBERCULOSIS MILIAR AGUDA, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
112	A	A198	OTRAS TUBERCULOSIS MILIARES	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
113	A	A199	TUBERCULOSIS MILIAR, SIN OTRA ESPECIFICACIÓN	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	006	001	008	NO	NO	NO	SI	999	999	02Z	02Z	3	2	3	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	51	NO	SI	45	TUBERCULOSIS OTRAS FORMAS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
114	A	A20	PESTE	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	NO	NO	NO	3	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
115	A	A200	PESTE BUBÓNICA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
116	A	A201	PESTE CELULOCUTÁNEA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
117	A	A202	PESTE NEUMÓNICA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
118	A	A203	MENINGITIS POR PESTE	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
119	A	A207	PESTE SEPTICÉMICA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
120	A	A208	OTRAS FORMAS DE PESTE	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
121	A	A209	PESTE, NO ESPECIFICADA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	007	001	009	NO	NO	NO	SI	007	007	03A	03A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	78	PESTE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
122	A	A21	TULAREMIA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
123	A	A210	TULAREMIA ULCEROGLANDULAR	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
124	A	A211	TULAREMIA OCULOGLANDULAR	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
125	A	A212	TULAREMIA PULMONAR	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
126	A	A213	TULAREMIA GASTROINTESTINAL	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
127	A	A217	TULAREMIA GENERALIZADA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
128	A	A218	OTRAS FORMAS DE TULAREMIA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
129	A	A219	TULAREMIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
130	A	A22	CARBUNCO [ÁNTRAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
131	A	A220	CARBUNCO CUTÁNEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
132	A	A221	CARBUNCO PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
133	A	A222	CARBUNCO GASTROINTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
134	A	A227	CARBUNCO SÉPTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2010 CORRECCION TITULOS	2014	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
135	A	A228	OTRAS FORMAS DE CARBUNCO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
136	A	A229	CARBUNCO, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	A22	ANTRAX	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
137	A	A23	BRUCELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	80	NO	SI	NO	NO	NO	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
138	A	A230	BRUCELOSIS DEBIDA A BRUCELLA MELITENSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
139	A	A231	BRUCELOSIS DEBIDA A BRUCELLA ABORTUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
140	A	A232	BRUCELOSIS DEBIDA A BRUCELLA SUIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
141	A	A233	BRUCELOSIS DEBIDA A BRUCELLA CANIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
142	A	A238	OTRAS BRUCELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
143	A	A239	BRUCELOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	010	NO	NO	NO	SI	008	008	03B	03B	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	80	SI	SI	29	BRUCELOSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
144	A	A24	MUERMO Y MELIOIDOSIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
145	A	A240	MUERMO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
146	A	A241	MELIOIDOSIS AGUDA Y FULMINANTE	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
147	A	A242	MELIOIDOSIS SUBAGUDA Y CRÓNICA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
148	A	A243	OTRAS MELIOIDOSIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
149	A	A244	MELIOIDOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
150	A	A25	FIEBRE POR MORDEDURA DE RATA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
151	A	A250	ESPIRILOSIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
152	A	A251	ESTREPTOBACILOSIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
153	A	A259	FIEBRE POR MORDEDURA DE RATA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
154	A	A26	ERISIPELOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
155	A	A260	ERISIPELOIDE CUTÁNEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
156	A	A267	SEPSIS POR ERYSIPELOTHRIX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2010 CORRECCION TITULOS	2014	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
157	A	A268	OTRAS FORMAS DE ERISIPELOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
158	A	A269	ERISIPELOIDE, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
159	A	A27	LEPTOSPIROSIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
160	A	A270	LEPTOSPIROSIS ICTEROHEMORRÁGICA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	102	LEPTOSPIROSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
161	A	A278	OTRAS FORMAS DE LEPTOSPIROSIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	102	LEPTOSPIROSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
162	A	A279	LEPTOSPIROSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	102	LEPTOSPIROSIS	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
163	A	A28	OTRAS ENFERMEDADES ZOONÓTICAS BACTERIANAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
164	A	A280	PASTEURELOSIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
165	A	A281	ENFERMEDAD POR RASGUÑO DE GATO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
166	A	A282	YERSINIOSIS EXTRAINTESTINAL	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
167	A	A288	OTRAS ENFERMEDADES ZOONÓTICAS BACTERIANAS ESPECIFICADAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
168	A	A289	ENFERMEDAD ZOONÓTICA BACTERIANA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
169	A	A30	LEPRA [ENFERMEDAD DE HANSEN	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	62	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
170	A	A300	LEPRA INDETERMINADA	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
171	A	A301	LEPRA TUBERCULOIDE	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
172	A	A302	LEPRA TUBERCULOIDE LIMÍTROFE	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
173	A	A303	LEPRA LIMÍTROFE	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
174	A	A304	LEPRA LEPROMATOSA LIMÍTROFE	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
175	A	A305	LEPRA LEPROMATOSA	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
176	A	A308	OTRAS FORMAS DE LEPRA	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
177	A	A309	LEPRA, NO ESPECIFICADA	NO	NO	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	011	NO	NO	NO	SI	009	009	03C	03C	29	88	29	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	62	SI	SI	73	LEPRA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
178	A	A31	INFECCIONES DEBIDAS A OTRAS MICOBACTERIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
179	A	A310	INFECCIONES POR MICOBACTERIAS PULMONARES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
180	A	A311	INFECCIÓN CUTÁNEA POR MICOBACTERIAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
181	A	A318	OTRAS INFECCIONES POR MICOBACTERIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
182	A	A319	INFECCIÓN POR MICOBACTERIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
183	A	A32	LISTERIOSIS	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
184	A	A320	LISTERIOSIS CUTÁNEA	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
208	A	A392	MENINGOCOCEMIA AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
185	A	A321	MENINGITIS Y MENINGOENCEFALITIS LISTERIANA	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
186	A	A327	SEPSIS LISTERIANA	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2010 CORRECCION TITULOS	2014	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
187	A	A328	OTRAS FORMAS DE LISTERIOSIS	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
188	A	A329	LISTERIOSIS, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
189	A	A33X	TÉTANOS NEONATAL	SI	NO	000H	027D	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	008	001	012	NO	NO	NO	SI	163H	163H	46J	46J	16	4	16	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	86	TETANOS NEONATAL	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
190	A	A34X	TÉTANOS OBSTÉTRICO	SI	2	010A	054A	NO	NO	NO	SI	SI	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	008	001	013	NO	NO	NO	SI	157	160	43O	43O	45	4	45	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	71	NO	NO	SI	SI	85	TETANOS	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
191	A	A35X	OTROS TÉTANOS	SI	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	008	001	013	NO	NO	NO	SI	014	014	03H	03H	16	4	16	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	85	TETANOS	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
192	A	A36	DIFTERIA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	NO	NO	NO	4	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
193	A	A360	DIFTERIA FARÍNGEA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
194	A	A361	DIFTERIA NASOFARÍNGEA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
195	A	A362	DIFTERIA LARÍNGEA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
196	A	A363	DIFTERIA CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
197	A	A368	OTRAS DIFTERIAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
198	A	A369	DIFTERIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	009	001	014	NO	NO	NO	SI	010	010	03D	03D	14	4	14	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	82	DIFTERIA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
199	A	A37	TOS FERINA [TOS CONVULSIVA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	010	001	015	NO	NO	NO	SI	011	011	NO	NO	NO	4	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	43	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
200	A	A370	TOS FERINA DEBIDA A BORDETELLA PERTUSSIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	010	001	015	NO	NO	NO	SI	011	011	03E	03E	12	4	12	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	43	SI	SI	83	TOS FERINA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
201	A	A371	TOS FERINA DEBIDA A BORDETELLA PARAPERTUSSIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	010	001	015	NO	NO	NO	SI	011	011	03E	03E	12	4	12	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	43	SI	SI	83	TOS FERINA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
202	A	A378	TOS FERINA DEBIDA A OTRAS ESPECIES DE BORDETELLA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	010	001	015	NO	NO	NO	SI	011	011	03E	03E	12	4	12	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	43	SI	SI	83	TOS FERINA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
203	A	A379	TOS FERINA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	010	001	015	NO	NO	NO	SI	011	011	03E	03E	12	4	12	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	43	SI	SI	83	TOS FERINA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
204	A	A38X	ESCARLATINA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	012	012	03F	03F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	33	NO	SI	34	ESCARLATINA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
205	A	A39	ENFERMEDAD MENINGOCÓCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	C	2006 (CAMBIA TITULO)	2006	SI	013	013	NO	NO	NO	5	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
206	A	A390	MENINGITIS MENINGOCÓCICA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	SI	40	MENINGITIS MENINGOCOCICA	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
207	A	A391	SÍNDROME DE WATERHOUSE-FRIDERICHSEN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
209	A	A393	MENINGOCOCEMIA CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
210	A	A394	MENINGOCOCEMIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
211	A	A395	ENFERMEDAD CARDÍACA DEBIDA A MENINGOCOCO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	NO	NO	NO	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
212	A	A398	OTRAS FORMAS DE ENFERMEDAD MENINGOCÓCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	C	2006 (CAMBIA TITULO)	2006	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
213	A	A399	ENFERMEDAD MENINGOCÓCICA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	011	001	016	C	2006 (CAMBIA TITULO)	2006	SI	013	013	03G	03G	17	5	17	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
214	A	A40	SEPSIS ESTREPTOCÓCICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	NO	NO	NO	6	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
215	A	A400	SEPSIS DEBIDA A ESTREPTOCOCO, GRUPO A	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
216	A	A401	SEPSIS DEBIDA A ESTREPTOCOCO, GRUPO B	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
217	A	A402	SEPSIS DEBIDA A ESTREPTOCOCO, GRUPO D Y ENTEROCOCO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS / 2018 CAMBIO DE TITULO	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
218	A	A403	SEPSIS DEBIDA A STREPTOCOCCUS PNEUMONIAE	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	SI	NO	SI	2	CAUSAS INTERMEDIAS	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	176	ENFERMEDAD INVASIVA POR NEUMOCOCO	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
219	A	A408	OTRAS SEPSIS ESTREPTOCÓCICAS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
220	A	A409	SEPSIS ESTREPTOCÓCICA, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
221	A	A41	OTRAS SEPSIS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	NO	NO	NO	6	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
222	A	A410	SEPSIS DEBIDA A STAPHYLOCOCCUS AUREUS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
223	A	A411	SEPSIS DEBIDA A OTRO ESTAFILOCOCO ESPECIFICADO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
224	A	A412	SEPSIS DEBIDA A ESTAFILOCOCO NO ESPECIFICADO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
225	A	A413	SEPSIS DEBIDA A HAEMOPHILUS INFLUENZAE	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	SI	SI	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	99	INFECCIONES INVASIVAS POR HAEMOPHILUS INFLUENZAE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
226	A	A414	SEPSIS DEBIDA A ANAEROBIOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
227	A	A415	SEPSIS DEBIDA A OTROS ORGANISMOS GRAMNEGATIVOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
228	A	A418	OTRAS SEPSIS ESPECIFICADAS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
229	A	A419	SEPSIS, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	012	001	017	C	2010 CORRECCION TITULOS	2014	SI	015	015	03I	03I	38	6	38	NO	NO	NO	SI	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
953	C	C051	TUMOR MALIGNO DEL PALADAR BLANDO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
230	A	A42	ACTINOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
231	A	A420	ACTINOMICOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
232	A	A421	ACTINOMICOSIS ABDOMINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
233	A	A422	ACTINOMICOSIS CERVICOFACIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
234	A	A427	SEPSIS ACTINOMICÓTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2010 CORRECCION TITULOS	2014	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
235	A	A428	OTRAS FORMAS DE ACTINOMICOSIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
236	A	A429	ACTINOMICOSIS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
237	A	A43	NOCARDIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
238	A	A430	NOCARDIOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
239	A	A431	NOCARDIOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
240	A	A438	OTRAS FORMAS DE NOCARDIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
241	A	A439	NOCARDIOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
242	A	A44	BARTONELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
243	A	A440	BARTONELOSIS SISTÉMICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
244	A	A441	BARTONELOSIS CUTÁNEA Y MUCOCUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
245	A	A448	OTRAS FORMAS DE BARTONELOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
246	A	A449	BARTONELOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
247	A	A46X	ERISIPELA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	012	012	03F	03F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	83	NO	SI	35	ERISIPELA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
248	A	A48	OTRAS ENFERMEDADES BACTERIANAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
249	A	A480	GANGRENA GASEOSA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
250	A	A481	ENFERMEDAD DE LOS LEGIONARIOS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
251	A	A482	ENFERMEDAD DE LOS LEGIONARIOS NO NEUMÓNICA (FIEBRE DE PONTIAC)	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
252	A	A483	SÍNDROME DEL CHOQUE TÓXICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	2	CAUSAS INTERMEDIAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
253	A	A484	FIEBRE PURPÚRICA BRASILEÑA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
254	A	A488	OTRAS ENFERMEDADES BACTERIANAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
255	A	A49	INFECCIÓN BACTERIANA DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
256	A	A490	INFECCIÓN ESTAFILOCÓCICA, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2008 CORRECCION TITULOS	2008	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
257	A	A491	INFECCIÓN ESTREPTOCÓCICA Y ENTEROCÓCICA DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2008 CORRECCION TITULOS / 2018 CAMBIO DE TITULO	2008	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
258	A	A492	INFECCIÓN POR HAEMOPHILUS INFLUENZAE, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2008 CORRECCION TITULOS	2008	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
259	A	A493	INFECCIÓN POR MICOPLASMA, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	C	2008 CORRECCION TITULOS	2008	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
260	A	A498	OTRAS INFECCIONES BACTERIANAS DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
261	A	A499	INFECCIÓN BACTERIANA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	018	NO	NO	NO	SI	999	999	03Z	03Z	38	88	38	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
262	A	A50	SÍFILIS CONGÉNITA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
263	A	A500	SÍFILIS CONGÉNITA PRECOZ, SINTOMÁTICA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
264	A	A501	SÍFILIS CONGÉNITA PRECOZ, LATENTE	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	SI	999	NO	NO	NO	NO	NO	NO
265	A	A502	SÍFILIS CONGÉNITA PRECOZ, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	SI	999	NO	NO	NO	NO	SI	NO
266	A	A503	OCULOPATÍA SIFILÍTICA CONGÉNITA TARDÍA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
267	A	A504	NEUROSÍFILIS CONGÉNITA TARDÍA [NEUROSÍFILIS JUVENIL	NO	NO	002A	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
268	A	A505	OTRAS FORMAS DE SÍFILIS CONGÉNITA TARDÍA, SINTOMÁTICA	NO	NO	002A	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	SI	NO
269	A	A506	SÍFILIS CONGÉNITA TARDÍA, LATENTE	NO	NO	002A	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
270	A	A507	SÍFILIS CONGÉNITA TARDÍA, SIN OTRA ESPECIFICACIÓN	NO	NO	002A	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
271	A	A509	SÍFILIS CONGÉNITA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	019	NO	NO	NO	SI	016	016	04A	04A	5	88	5	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	92	SIFILIS CONGENITA	SI	SI	NO	SI	999	NO	NO	NO	NO	NO	NO
272	A	A51	SÍFILIS PRECOZ	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
273	A	A510	SÍFILIS GENITAL PRIMARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
274	A	A511	SÍFILIS PRIMARIA ANAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
275	A	A512	SÍFILIS PRIMARIA EN OTROS SITIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
276	A	A513	SÍFILIS SECUNDARIA DE PIEL Y MEMBRANAS MUCOSAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
277	A	A514	OTRAS SÍFILIS SECUNDARIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
278	A	A515	SÍFILIS PRECOZ, LATENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
279	A	A519	SÍFILIS PRECOZ, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	020	NO	NO	NO	SI	016	016	04B	04B	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
281	A	A520	SÍFILIS CARDIOVASCULAR	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
282	A	A521	NEUROSÍFILIS SINTOMÁTICA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
283	A	A522	NEUROSÍFILIS ASINTOMÁTICA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
284	A	A523	NEUROSÍFILIS NO ESPECIFICADA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
285	A	A527	OTRAS SÍFILIS TARDÍAS SINTOMÁTICAS	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
286	A	A528	SÍFILIS TARDÍA, LATENTE	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
280	A	A52	SÍFILIS TARDÍA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
287	A	A529	SÍFILIS TARDÍA, NO ESPECIFICADA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
288	A	A53	OTRAS SÍFILIS Y LAS NO ESPECIFICADAS	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
289	A	A530	SÍFILIS LATENTE, NO ESPECIFICADA COMO PRECOZ O TARDÍA	NO	NO	002A	120A	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
290	A	A539	SÍFILIS, NO ESPECIFICADA	NO	NO	002A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	021	NO	NO	NO	SI	016	016	04C	04C	5	88	5	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	87	NO	SI	25	SIFILIS ADQUIRIDA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
291	A	A54	INFECCIÓN GONOCÓCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
292	A	A540	INFECCIÓN GONOCÓCICA DEL TRACTO GENITOURINARIO INFERIOR SIN ABSCESO PERIURETRAL Y DE GLÁNDULA ACCESORIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	84	NO	SI	23	INFECCION GONOCOCICA DEL TRACTO GENITOURINARIO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
293	A	A541	INFECCIÓN GONOCÓCICA DEL TRACTO GENITOURINARIO INFERIOR CON ABSCESO PERIURETRAL Y DE GLÁNDULAS ACCESORIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	84	NO	SI	23	INFECCION GONOCOCICA DEL TRACTO GENITOURINARIO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
294	A	A542	PELVIPERITONITIS GONOCÓCICA Y OTRAS INFECCIONES GONOCÓCICAS GENITOURINARIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	C	2003 (SE ELIMINO DAGA)	2003	SI	017	017	04D	04D	7	88	7	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	84	NO	SI	23	INFECCION GONOCOCICA DEL TRACTO GENITOURINARIO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
295	A	A543	INFECCIÓN GONOCÓCICA DEL OJO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
296	A	A544	INFECCIÓN GONOCÓCICA DEL SISTEMA OSTEOMUSCULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
297	A	A545	FARINGITIS GONOCÓCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
298	A	A546	INFECCIÓN GONOCÓCICA DEL ANO Y DEL RECTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
299	A	A548	OTRAS INFECCIONES GONOCÓCICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
300	A	A549	INFECCIÓN GONOCÓCICA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	022	NO	NO	NO	SI	017	017	04D	04D	7	88	7	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	84	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
301	A	A55X	LINFOGRANULOMA (VENÉREO) POR CLAMIDIAS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	85	NO	SI	24	LINFOGRANULOMA VENEREO POR CLAMIDIAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
302	A	A56	OTRAS ENFERMEDADES DE TRANSMISIÓN SEXUAL DEBIDAS A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
303	A	A560	INFECCIÓN DEL TRACTO GENITOURINARIO INFERIOR DEBIDA A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
304	A	A561	INFECCIÓN DEL PELVIPERITONEO Y OTROS ÓRGANOS GENITOURINARIOS DEBIDA A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	C	2003 (SE ELIMINO DAGA)	2003	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
305	A	A562	INFECCIONES DEL TRACTO GENITOURINARIO DEBIDAS A CLAMIDIAS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
306	A	A563	INFECCIÓN DEL ANO Y DEL RECTO DEBIDA A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
307	A	A564	INFECCIÓN DE FARINGE DEBIDA A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
308	A	A568	INFECCIÓN DE TRANSMISIÓN SEXUAL DE OTROS SITIOS DEBIDA A CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	023	NO	NO	NO	SI	018	018	04E	04E	6	88	6	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	85	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
309	A	A57X	CHANCRO BLANDO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	88	NO	SI	21	CHANCRO BLANDO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
310	A	A58X	GRANULOMA INGUINAL	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
311	A	A59	TRICOMONIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	86	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
312	A	A590	TRICOMONIASIS UROGENITAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	86	NO	SI	26	TRICOMONIASIS UROGENITAL	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
313	A	A598	TRICOMONIASIS DE OTROS SITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	86	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
314	A	A599	TRICOMONIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	86	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
315	A	A60	INFECCIÓN ANOGENITAL DEBIDA A VIRUS DEL HERPES [HERPES SIMPLE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	90	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	SI	NO
316	A	A600	INFECCIÓN DE GENITALES Y TRAYECTO UROGENITAL DEBIDA A VIRUS DEL HERPES [HERPES SIMPLE	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	90	NO	SI	22	HERPES GENITAL	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
317	A	A601	INFECCIÓN DE LA PIEL PERIANAL Y RECTO POR VIRUS DEL HERPES SIMPLE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	90	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
318	A	A609	INFECCIÓN ANOGENITAL POR VIRUS DEL HERPES SIMPLE, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	90	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
319	A	A63	OTRAS ENFERMEDADES DE TRANSMISIÓN PREDOMINANTEMENTE SEXUAL, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
320	A	A630	VERRUGAS (VENÉREAS) ANOGENITALES	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	234	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
321	A	A638	OTRAS ENFERMEDADES DE TRANSMISIÓN PREDOMINANTEMENTE SEXUAL, ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
322	A	A64X	ENFERMEDAD DE TRANSMISIÓN SEXUAL NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	013	001	024	NO	NO	NO	SI	999	999	04F	04F	8	88	8	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
323	A	A65X	SÍFILIS NO VENÉREA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
324	A	A66	FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
325	A	A660	LESIONES INICIALES DE FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
326	A	A661	LESIONES PAPILOMATOSAS MÚLTIPLES Y FRAMBESIA CON PASO DE CANGREJO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
327	A	A662	OTRAS LESIONES PRECOCES DE LA PIEL EN LA FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
328	A	A663	HIPERQUERATOSIS DE FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
329	A	A664	GOMA Y ÚLCERAS DE FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
330	A	A665	GANGOSA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
331	A	A666	LESIONES FRAMBÉSICAS DE LOS HUESOS Y DE LAS ARTICULACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
332	A	A667	OTRAS MANIFESTACIONES DE FRAMBESIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
333	A	A668	FRAMBESIA LATENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
334	A	A669	FRAMBESIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
336	A	A670	LESIONES PRIMARIAS DE LA PINTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	72	MAL DEL PINTO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
337	A	A671	LESIONES INTERMEDIAS DE LA PINTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	72	MAL DEL PINTO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
338	A	A672	LESIONES TARDÍAS DE LA PINTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	72	MAL DEL PINTO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
339	A	A673	LESIONES MIXTAS DE LA PINTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	72	MAL DEL PINTO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
340	A	A679	PINTA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	72	MAL DEL PINTO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
341	A	A68	FIEBRES RECURRENTES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	025	NO	NO	NO	SI	019	019	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
342	A	A680	FIEBRE RECURRENTE TRANSMITIDA POR PIOJOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	025	NO	NO	NO	SI	019	019	05B	05B	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
343	A	A681	FIEBRE RECURRENTE TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	025	NO	NO	NO	SI	019	019	05B	05B	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
344	A	A689	FIEBRE RECURRENTE, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	025	NO	NO	NO	SI	019	019	05B	05B	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
345	A	A69	OTRAS INFECCIONES CAUSADAS POR ESPIROQUETAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
346	A	A690	ESTOMATITIS ULCERATIVA NECROTIZANTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
347	A	A691	OTRAS INFECCIONES DE VINCENT	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
348	A	A692	ENFERMEDAD DE LYME	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
349	A	A698	OTRAS INFECCIONES ESPECIFICADAS POR ESPIROQUETAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
350	A	A699	INFECCIÓN POR ESPIROQUETA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05A	05A	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
351	A	A70X	INFECCION DEBIDA A CHLAMYDIA PSITTACI	SI	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	06R	06R	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
352	A	A71	TRACOMA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	026	NO	NO	NO	SI	041	041	NO	NO	NO	88	NO	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	85	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
353	A	A710	ESTADO INICIAL DE TRACOMA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	026	NO	NO	NO	SI	041	041	06M	06M	32	88	32	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	85	NO	SI	74	TRACOMA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
354	A	A711	ESTADO ACTIVO DE TRACOMA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	026	NO	NO	NO	SI	041	041	06M	06M	32	88	32	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	85	NO	SI	74	TRACOMA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
355	A	A719	TRACOMA, NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	026	NO	NO	NO	SI	041	041	06M	06M	32	88	32	NO	SI	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	SI	0	SI	85	NO	SI	74	TRACOMA	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
356	A	A74	OTRAS ENFERMEDADES CAUSADAS POR CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
357	A	A740	CONJUNTIVITIS POR CLAMIDIAS	NO	NO	028D	120A	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	06R	06R	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
358	A	A748	OTRAS ENFERMEDADES POR CLAMIDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	06R	06R	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
359	A	A749	INFECCIÓN POR CLAMIDIAS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	06R	06R	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
360	A	A75	TIFUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	38	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
361	A	A750	TIFUS EPIDÉMICO DEBIDO A RICKETTSIA PROWAZEKII TRANSMITIDO POR PIOJOS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	045	045	07A	07A	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	175	TIFO EPIDEMICO	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
362	A	A751	TIFUS RECRUDESCENTE [ENFERMEDAD DE BRILL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	999	999	07B	07B	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	38	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
363	A	A752	TIFUS DEBIDO A RICKETTSIA TYPHI	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	999	999	07B	07B	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	80	TIFO MURINO	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
364	A	A753	TIFUS DEBIDO A RICKETTSIA TSUTSUGAMUSHI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	999	999	07B	07B	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	38	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
365	A	A759	TIFUS, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	027	NO	NO	NO	SI	999	999	07B	07B	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	38	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
366	A	A77	FIEBRE MACULOSA [RICKETTSIOSIS TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
367	A	A770	FIEBRE MACULOSA DEBIDA A RICKETTSIA RICKETTSII	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	81	FIEBRE MANCHADA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
368	A	A771	FIEBRE MACULOSA DEBIDA A RICKETTSIA CONORII	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
369	A	A772	FIEBRE MACULOSA DEBIDA A RICKETTSIA SIBERICA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
370	A	A773	FIEBRE MACULOSA DEBIDA A RICKETTSIA AUSTRALIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
371	A	A778	OTRAS FIEBRES MACULOSAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
372	A	A779	FIEBRE MACULOSA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
373	A	A78X	FIEBRE Q	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	38	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
374	A	A79	OTRAS RICKETTSIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	38	SI	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
375	A	A790	FIEBRE DE LAS TRINCHERAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	180	OTRAS RICKETTSIOSIS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
376	A	A791	RICKETTSIOSIS PUSTULOSA DEBIDA A RICKETTSIA AKARI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	180	OTRAS RICKETTSIOSIS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
377	A	A798	OTRAS RICKETTSIOSIS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	180	OTRAS RICKETTSIOSIS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
378	A	A799	RICKETTSIOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	07C	07C	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	38	SI	SI	180	OTRAS RICKETTSIOSIS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
379	A	A80	POLIOMIELITIS AGUDA	NO	NO	000H	015A	NO	SI	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	NO	NO	NO	4	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
380	A	A800	POLIOMIELITIS AGUDA PARALÍTICA, ASOCIADA A VACUNA	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
381	A	A801	POLIOMIELITIS AGUDA PARALÍTICA DEBIDA A VIRUS SALVAJE IMPORTADO	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
382	A	A802	POLIOMIELITIS AGUDA PARALÍTICA DEBIDA A VIRUS SALVAJE AUTÓCTONO	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
383	A	A803	OTRAS POLIOMIELITIS AGUDAS PARALÍTICAS Y LAS NO ESPECIFICADAS	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
384	A	A804	POLIOMIELITIS AGUDA NO PARALÍTICA	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
385	A	A809	POLIOMIELITIS AGUDA, SIN OTRA ESPECIFICACIÓN	NO	NO	000H	015A	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	014	001	028	NO	NO	NO	SI	030	030	06A	06A	13	4	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	75	POLIOMIELITIS AGUDA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
386	A	A81	INFECCIONES DEL SISTEMA NERVIOSO CENTRAL POR VIRUS ATÍPICO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	C	2003 (CAMBIA TITULO)	2003	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
387	A	A810	ENFERMEDAD DE CREUTZFELDT-JAKOB	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
388	A	A811	PANENCEFALITIS ESCLEROSANTE SUBAGUDA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
389	A	A812	LEUCOENCEFALOPATÍA MULTIFOCAL PROGRESIVA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
390	A	A818	OTRAS INFECCIONES DEL SISTEMA NERVIOSO CENTRAL POR VIRUS ATÍPICO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	C	2003 (CAMBIA TITULO)	2003	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
391	A	A819	INFECCIONES DEL SISTEMA NERVIOSO CENTRAL POR VIRUS ATÍPICO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	C	2003 (CAMBIA TITULO)	2003	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
392	A	A82	RABIA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	015	001	029	NO	NO	NO	SI	040	040	NO	NO	NO	3	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
393	A	A820	RABIA SELVÁTICA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	015	001	029	NO	NO	NO	SI	040	040	06L	06L	38	3	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	31	RABIA HUMANA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
394	A	A821	RABIA URBANA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	015	001	029	NO	NO	NO	SI	040	040	06L	06L	38	3	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	31	RABIA HUMANA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
395	A	A829	RABIA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	015	001	029	NO	NO	NO	SI	040	040	06L	06L	38	3	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	31	RABIA HUMANA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
396	A	A83	ENCEFALITIS VIRAL TRANSMITIDA POR MOSQUITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
397	A	A830	ENCEFALITIS JAPONESA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	31	3	31	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
398	A	A831	ENCEFALITIS EQUINA DEL OESTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
399	A	A832	ENCEFALITIS EQUINA DEL ESTE	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
400	A	A833	ENCEFALITIS DE SAN LUIS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
401	A	A834	ENCEFALITIS AUSTRALIANA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
402	A	A835	ENCEFALITIS DE CALIFORNIA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
403	A	A836	ENFERMEDAD POR VIRUS ROCÍO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
404	A	A838	OTRAS ENCEFALITIS VIRALES TRANSMITIDAS POR MOSQUITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
405	A	A839	ENCEFALITIS VIRAL TRANSMITIDA POR MOSQUITOS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
406	A	A84	ENCEFALITIS VIRAL TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
407	A	A840	ENCEFALITIS DEL LEJANO ORIENTE TRANSMITIDA POR GARRAPATAS [ENCEFALITIS PRIMAVEROESTIVAL RUSA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
408	A	A841	ENCEFALITIS CENTROEUROPEA TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
409	A	A848	OTRAS ENCEFALITIS VIRALES TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
410	A	A849	ENCEFALITIS VIRAL TRANSMITIDA POR GARRAPATAS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
411	A	A85	OTRAS ENCEFALITIS VIRALES, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
412	A	A850	ENCEFALITIS ENTEROVIRAL	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
413	A	A851	ENCEFALITIS POR ADENOVIRUS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
414	A	A852	ENCEFALITIS VIRAL TRANSMITIDA POR ARTRÓPODOS, SIN OTRA ESPECIFCACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
415	A	A858	OTRAS ENCEFALITIS VIRALES ESPECIFCADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
416	A	A86X	ENCEFALITIS VIRAL, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	030	NO	NO	NO	SI	038	038	06I	06I	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
417	A	A87	MENINGITIS VIRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	5	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
418	A	A870	MENINGITIS ENTEROVIRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	5	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
419	A	A871	MENINGITIS DEBIDA A ADENOVIRUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	5	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
420	A	A872	CORIOMENINGITIS LINFOCÍTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	5	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
421	A	A878	OTRAS MENINGITIS VIRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	5	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
422	A	A879	MENINGITIS VIRAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	5	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
423	A	A88	OTRAS INFECCIONES VIRALES DEL SISTEMA NERVIOSO CENTRAL, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
424	A	A880	FIEBRE EXANTEMÁTICA ENTEROVIRAL [EXANTEMA DE BOSTON	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
425	A	A881	VÉRTIGO EPIDÉMICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
426	A	A888	OTRAS INFECCIONES VIRALES ESPECIFICADAS DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
427	A	A89X	INFECCIÓN VIRAL DEL SISTEMA NERVIOSO CENTRAL, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
428	A	A90X	FIEBRE DEL DENGUE [DENGUE CLÁSICO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	B	2018 ELIMINAR CODIGO	2018	NO	035	035	06F	06F	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	27	DENGUE NO GRAVE	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
429	A	A91X	FIEBRE DEL DENGUE HEMORRÁGICO	SI	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	B	2018 ELIMINAR CODIGO	2018	NO	036	036	06G	06G	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	89	DENGUE GRAVE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
430	A	A92	OTRAS FIEBRES VIRALES TRANSMITIDAS POR MOSQUITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
431	A	A920	ENFERMEDAD POR VIRUS CHIKUNGUNYA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	36	SI	SI	146	ENFERMEDAD POR VIRUS CHIKUNGUNYA	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
432	A	A921	FIEBRE DE O'NYONG-NYONG	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
433	A	A922	FIEBRE EQUINA VENEZOLANA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	88	ENCEFALITIS EQUINA VENEZOLANA	SI	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
434	A	A923	INFECCIÓN POR VIRUS DEL OESTE DEL NILO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	C	2006 (CAMBIA TITULO) 2007 CORRECCION TITULOS	2014	SI	999	999	06N	06N	38	3	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	504	FIEBRE DEL OESTE DEL NILO	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
435	A	A924	FIEBRE DEL VALLE DEL RIFT	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
436	A	A928	OTRAS FIEBRES VIRALES ESPECIFICADAS TRANSMITIDAS POR MOSQUITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	SI	188	FIEBRE POR VIRUS MAYARO	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
437	A	A929	FIEBRE VIRAL TRANSMITIDA POR MOSQUITO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
438	A	A93	OTRAS FIEBRES VIRALES TRANSMITIDAS POR ARTRÓPODOS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
439	A	A930	ENFERMEDAD POR VIRUS DE OROPOUCHE	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
440	A	A931	FIEBRE TRANSMITIDA POR FLEBÓTOMOS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
441	A	A932	FIEBRE DE COLORADO TRANSMITIDA POR GARRAPATAS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
442	A	A938	OTRAS FIEBRES VIRALES ESPECIFICADAS TRANSMITIDAS POR ARTRÓPODOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
443	A	A94X	FIEBRE VIRAL TRANSMITIDA POR ARTRÓPODOS, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
444	A	A95	FIEBRE AMARILLA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	016	001	031	NO	NO	NO	SI	034	034	NO	NO	NO	3	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
445	A	A950	FIEBRE AMARILLA SELVÁTICA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	016	001	031	NO	NO	NO	SI	034	034	06E	06E	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	77	FIEBRE AMARILLA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
446	A	A951	FIEBRE AMARILLA URBANA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	016	001	031	NO	NO	NO	SI	034	034	06E	06E	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	77	FIEBRE AMARILLA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
447	A	A959	FIEBRE AMARILLA, NO ESPECIFICADA	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	016	001	031	NO	NO	NO	SI	034	034	06E	06E	38	3	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	77	FIEBRE AMARILLA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
448	A	A96	FIEBRE HEMORRÁGICA POR ARENAVIRUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
449	A	A960	FIEBRE HEMORRÁGICA DE JUNÍN	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
450	A	A961	FIEBRE HEMORRÁGICA DE MACHUPO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
451	A	A962	FIEBRE DE LASSA	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
452	A	A968	OTRAS FIEBRES HEMORRÁGICAS POR ARENAVIRUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
453	A	A969	FIEBRE HEMORRÁGICA POR ARENAVIRUS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
454	A	A97	DENGUE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	A	2018 CREACION DE CATEGORIA	2018	SI	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
455	A	A970	DENGUE SIN SIGNOS DE ALARMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	A	2018 CREACION DE SUBCATEGORIA	2018	SI	035	035	06F	06F	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	36	SI	SI	27	DENGUE NO GRAVE	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
456	A	A971	DENGUE CON SIGNOS DE ALARMA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	A	2018 CREACION DE SUBCATEGORIA	2018	SI	036	036	06G	06G	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	177	SI	SI	189	DENGUE CON SIGNOS DE ALARMA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
457	A	A972	DENGUE SEVERO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	A	2018 CREACION DE SUBCATEGORIA	2018	SI	036	036	06G	06G	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	89	DENGUE GRAVE	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
458	A	A979	DENGUE, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	A	2018 CREACION DE SUBCATEGORIA	2018	SI	035	035	06F	06F	30	3	30	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	27	DENGUE NO GRAVE	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
459	A	A98	OTRAS FIEBRES VIRALES HEMORRÁGICAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
460	A	A980	FIEBRE HEMORRÁGICA DE CRIMEA-CONGO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
461	A	A981	FIEBRE HEMORRÁGICA DE OMSK	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
462	A	A982	ENFERMEDAD DE LA SELVA KYASANUR	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
463	A	A983	ENFERMEDAD POR EL VIRUS DE MARBURG	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
464	A	A984	ENFERMEDAD POR EL VIRUS DE EBOLA	NO	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	SI	182	ENFERMEDAD POR VIRUS EBOLA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
465	A	A985	FIEBRES HEMORRÁGICAS CON SÍNDROME RENAL	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
466	A	A988	OTRAS FIEBRES HEMORRÁGICAS VIRALES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	3	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
467	A	A99X	FIEBRE VIRAL HEMORRÁGICA, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	017	001	032	NO	NO	NO	SI	999	999	06N	06N	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
468	B	B00	INFECCIONES HERPÉTICA [HERPES SIMPLE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
469	B	B000	ECZEMA HERPÉTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
470	B	B001	DERMATITIS VESICULAR HERPÉTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
471	B	B002	GINGIVOESTOMATITIS Y FARINGOAMIGDALITIS HERPÉTICA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
472	B	B003	MENINGITIS HERPÉTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
473	B	B004	ENCEFALITIS HERPÉTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
474	B	B005	OCULOPATÍA HERPÉTICA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	C	2003 (SE ELIMINO DAGA)	2003	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
475	B	B007	ENFERMEDAD HERPÉTICA DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
476	B	B008	OTRAS FORMAS DE INFECCIONES HERPÉTICAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
477	B	B009	INFECCIÓN DEBIDA AL VIRUS DEL HERPES, NO ESPECIFICADA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	033	NO	NO	NO	SI	042	042	06O	06O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
478	B	B01	VARICELA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	NO	NO	NO	4	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	000	NO	NO	NO	NO	NO	NO
479	B	B010	MENINGITIS DEBIDA A VARICELA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	33	VARICELA	NO	NO	SI	NO	999	NO	NO	NO	NO	SI	NO
480	B	B011	ENCEFALITIS DEBIDA A VARICELA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	33	VARICELA	NO	NO	SI	NO	999	NO	NO	NO	NO	SI	NO
481	B	B012	NEUMONÍA DEBIDA A VARICELA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	33	VARICELA	NO	NO	SI	NO	999	NO	NO	NO	NO	SI	NO
482	B	B018	VARICELA CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	33	VARICELA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
483	B	B019	VARICELA SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	35	NO	SI	33	VARICELA	NO	NO	SI	NO	999	NO	NO	NO	NO	NO	NO
484	B	B02	HERPES ZOSTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
485	B	B020	ENCEFALITIS DEBIDA A HERPES ZOSTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
486	B	B021	MENINGITIS DEBIDA A HERPES ZOSTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
487	B	B022	HERPES ZOSTER CON OTROS COMPROMISOS DEL SISTEMA NERVIOSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
488	B	B023	HERPES ZOSTER OCULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	C	2003 (SE ELIMINO DAGA)	2003	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
489	B	B027	HERPES ZOSTER DISEMINADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
490	B	B028	HERPES ZOSTER CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
491	B	B029	HERPES ZOSTER SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	034	NO	NO	NO	SI	043	043	06P	06P	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	63	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
492	B	B03X	VIRUELA	SI	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	031	031	06B	06B	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
493	B	B04X	VIRUELA DE LOS MONOS	SI	NO	NO	NO	NO	SI	SI	NO	NO	NO	NO	SI	NO	SI	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	031	031	06B	06B	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
494	B	B05	SARAMPIÓN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	NO	NO	NO	4	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
495	B	B050	SARAMPIÓN COMPLICADO CON ENCEFALITIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
496	B	B051	SARAMPIÓN COMPLICADO CON MENINGITIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
497	B	B052	SARAMPIÓN COMPLICADO CON NEUMONÍA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
498	B	B053	SARAMPIÓN COMPLICADO CON OTITIS MEDIA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
499	B	B054	SARAMPIÓN CON COMPLICACIONES INTESTINALES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
500	B	B058	SARAMPIÓN CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
501	B	B059	SARAMPIÓN SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	018	001	035	NO	NO	NO	SI	032	032	06C	06C	15	4	15	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	34	SI	SI	87	SARAMPION	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
502	B	B06	RUBÉOLA [SARAMPIÓN ALEMÁN	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	036	NO	NO	NO	SI	033	033	NO	NO	NO	4	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
503	B	B060	RUBÉOLA CON COMPLICACIONES NEUROLÓGICAS	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	036	NO	NO	NO	SI	033	033	06D	06D	38	4	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	32	RUBEOLA	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
504	B	B068	RUBÉOLA CON OTRAS COMPLICACIONES	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	036	NO	NO	NO	SI	033	033	06D	06D	38	4	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	32	RUBEOLA	SI	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
505	B	B069	RUBÉOLA SIN COMPLICACIONES	NO	NO	028D	120A	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	036	NO	NO	NO	SI	033	033	06D	06D	38	4	38	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	34	SI	SI	32	RUBEOLA	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
506	B	B07X	VERRUGAS VÍRICAS	SI	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	97	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
507	B	B08	OTRAS INFECIONES VÍRICAS CARACTERIZADAS POR LESIONES DE LA PIEL Y DE LAS MEMBRANAS MUCOSAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
508	B	B080	OTRAS INFECCIONES DEBIDAS A ORTOPOXVIRUS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
509	B	B081	MOLUSCO CONTAGIOSO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
510	B	B082	EXANTEMA SÚBITO [SEXTA ENFERMEDAD	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
511	B	B083	ERITEMA INFECCIOSO [QUINTA ENFERMEDAD	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
512	B	B084	ESTOMATITIS VESICULAR ENTEROVIRAL CON EXANTEMA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
513	B	B085	FARINGITIS VESICULAR ENTEROVÍRICA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
514	B	B088	OTRAS INFECCIONES VIRALES ESPECIFICADAS, CARACTERIZADAS POR LESIONES DE LA PIEL Y DE LAS MEMBRANAS MUCOSAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
515	B	B09X	INFECCIÓN VIRAL NO ESPECIFICADA, CARACTERIZADA POR LESIONES DE LA PIEL Y DE LAS MEMBRANAS MUCOSAS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
516	B	B15	HEPATITIS AGUDA TIPO A	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	NO	NO	NO	4	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
517	B	B150	HEPATITIS AGUDA TIPO A, CON COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	4	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	37	HEPATITIS VIRICA A	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
518	B	B159	HEPATITIS AGUDA TIPO A, SIN COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	4	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	64	NO	SI	37	HEPATITIS VIRICA A	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
519	B	B16	HEPATITIS AGUDA TIPO B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	037	NO	NO	NO	SI	039	039	NO	NO	NO	4	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
520	B	B160	HEPATITIS AGUDA TIPO B, CON AGENTE DELTA (COINFECCIÓN), CON COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	037	NO	NO	NO	SI	039	039	06J	06J	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	38	HEPATITIS VIRICA B	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
521	B	B161	HEPATITIS AGUDA TIPO B, CON AGENTE DELTA (COINFECCIÓN), SIN COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	037	NO	NO	NO	SI	039	039	06J	06J	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	38	HEPATITIS VIRICA B	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
522	B	B162	HEPATITIS AGUDA TIPO B, SIN AGENTE DELTA, CON COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	037	NO	NO	NO	SI	039	039	06J	06J	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	38	HEPATITIS VIRICA B	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
523	B	B169	HEPATITIS AGUDA TIPO B, SIN AGENTE DELTA Y SIN COMA HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	037	NO	NO	NO	SI	039	039	06J	06J	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	64	NO	SI	38	HEPATITIS VIRICA B	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
524	B	B17	OTRAS HEPATITIS VIRALES AGUDAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	NO	NO	NO	4	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
525	B	B170	INFECCIÓN (SUPERINFECCIÓN) AGUDA POR AGENTE DELTA EN LA HEPATITIS B CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	C	2018 CAMBIO DE TITULO	NO	SI	039	039	06K	06K	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
526	B	B171	HEPATITIS AGUDA TIPO C	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	20	88	20	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	SI	104	HEPATITIS VIRICA C	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
527	B	B172	HEPATITIS AGUDA TIPO E	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
528	B	B178	OTRAS HEPATITIS VIRALES AGUDAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
529	B	B179	HEPATITIS VIRAL AGUDA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	A	2010 NUEVA CATEGORIA	2014	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
530	B	B18	HEPATITIS VIRAL CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
531	B	B180	HEPATITIS VIRAL TIPO B CRÓNICA, CON AGENTE DELTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
532	B	B181	HEPATITIS VIRAL TIPO B CRÓNICA, SIN AGENTE DELTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	19	4	19	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
533	B	B182	HEPATITIS VIRAL TIPO C CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	20	88	20	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	SI	104	HEPATITIS VIRICA C	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
534	B	B188	OTRAS HEPATITIS VIRALES CRÓNICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
535	B	B189	HEPATITIS VIRAL CRÓNICA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
536	B	B19	HEPATITIS VIRAL, SIN OTRA ESPECIFICACIÓN	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	NO	NO	NO	SI	039	039	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
537	B	B190	HEPATITIS VIRAL NO ESPECIFICADA CON COMA HEPÁTICO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	C	2010 CORRECCION TITULOS	2014	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
538	B	B199	HEPATITIS VIRAL NO ESPECIFICADA SIN COMA HEPÁTICO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	019	001	038	C	2010 CORRECCION TITULOS	2014	SI	039	039	06K	06K	21	88	21	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	39	OTRAS HEPATITIS VIRICAS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
539	B	B20	ENFERMEDAD POR VIRUS DE LA INMUNODEFICIENCIA HUMANA [VIH, RESULTANTE EN ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	NO	NO	NO	7	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
540	B	B200	ENFERMEDAD POR VIH, RESULTANTE EN INFECCIÓN POR MICOBACTERIAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
541	B	B201	ENFERMEDAD POR VIH, RESULTANTE EN OTRAS INFECCIONES BACTERIANAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
542	B	B202	ENFERMEDAD POR VIH, RESULTANTE EN ENFERMEDAD POR CITOMEGALOVIRUS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
543	B	B203	ENFERMEDAD POR VIH, RESULTANTE EN OTRAS INFECCIONES VIRALES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
544	B	B204	ENFERMEDAD POR VIH, RESULTANTE EN CANDIDIASIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
545	B	B205	ENFERMEDAD POR VIH, RESULTANTE EN OTRAS MICOSIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
546	B	B206	ENFERMEDAD POR VIH, RESULTANTE EN NEUMONÍA POR PNEUMOCYSTIS CARINII	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
547	B	B207	ENFERMEDAD POR VIH, RESULTANTE EN INFECCIONES MÚLTIPLES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
548	B	B208	ENFERMEDAD POR VIH, RESULTANTE EN OTRAS ENFERMEDADES INFECCIOSAS O PARASITARIAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
549	B	B209	ENFERMEDAD POR VIH, RESULTANTE EN ENFERMEDAD INFECCIOSA O PARASITARIA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
550	B	B21	ENFERMEDAD POR VIRUS DE LA INMUNODEFICIENCIA HUMANA [VIH, RESULTANTE EN TUMORES MALIGNOS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	NO	NO	NO	7	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
551	B	B210	ENFERMEDAD POR VIH, RESULTANTE EN SARCOMA DE KAPOSI	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
552	B	B211	ENFERMEDAD POR VIH, RESULTANTE EN LINFOMA DE BURKITT	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
553	B	B212	ENFERMEDAD POR VIH, RESULTANTE EN OTROS TIPOS DE LINFOMA NO HODGKIN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
554	B	B213	ENFERMEDAD POR VIH, RESULTANTE EN OTROS TUMORES MALIGNOS DEL TEJIDO LINFOIDE, HEMATOPOYÉTICO Y TEJIDOS RELACIONADOS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
555	B	B217	ENFERMEDAD POR VIH, RESULTANTE EN TUMORES MALIGNOS MÚLTIPLES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
556	B	B218	ENFERMEDAD POR VIH, RESULTANTE EN OTROS TUMORES MALIGNOS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
557	B	B219	ENFERMEDAD POR VIH, RESULTANTE EN TUMORES MALIGNOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
558	B	B22	ENFERMEDAD POR VIRUS DE LA INMUNODEFICIENCIA HUMANA [VIH, RESULTANTE EN OTRAS ENFERMEDADES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	NO	NO	NO	7	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	SI	SI	NO	NO	SI	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
559	B	B220	ENFERMEDAD POR VIH, RESULTANTE EN ENCEFALOPATÍA	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
560	B	B221	ENFERMEDAD POR VIH, RESULTANTE EN NEUMONITIS LINFOIDE INTERSTICIAL	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
561	B	B222	ENFERMEDAD POR VIH, RESULTANTE EN SÍNDROME CAQUÉCTICO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
562	B	B227	ENFERMEDAD POR VIH, RESULTANTE EN ENFERMEDADES MÚLTIPLES CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
563	B	B23	ENFERMEDAD POR VIRUS DE LA INMUNODEFICIENCIA HUMANA [VIH, RESULTANTE EN OTRAS AFECCIONES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	NO	NO	NO	7	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	SI	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
564	B	B230	SÍNDROME DE INFECCIÓN AGUDA DEBIDA A VIH	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
565	B	B231	ENFERMEDAD POR VIH, RESULTANTE EN LINFADENOPATÍA GENERALIZADA (PERSISTENTE)	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
566	B	B232	ENFERMEDAD POR VIH, RESULTANTE EN ANORMALIDADES INMUNOLÓGICAS Y HEMATOLÓGICAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
567	B	B238	ENFERMEDAD POR VIH, RESULTANTE EN OTRAS AFECCIONES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
568	B	B24X	ENFERMEDAD POR VIRUS DE LA INMUNODEFICIENCIA HUMANA [VIH, SIN OTRA ESPECIFICACIÓN	SI	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	SI	SI	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	020	001	039	NO	NO	NO	SI	037	037	06H	06H	9	7	9	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	67	SINDROME DE INMUNODEFICIENCIA ADQUIRIDA	SI	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
569	B	B25	ENFERMEDAD DEBIDA A VIRUS CITOMEGÁLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
570	B	B250	NEUMONITIS DEBIDA A VIRUS CITOMEGÁLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
571	B	B251	HEPATITIS DEBIDA A VIRUS CITOMEGÁLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
572	B	B252	PANCREATITIS DEBIDA A VIRUS CITOMEGÁLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
573	B	B258	OTRAS ENFERMEDADES DEBIDAS A VIRUS CITOMEGÁLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
574	B	B259	ENFERMEDAD POR VIRUS CITOMEGÁLICO, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
575	B	B26	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	NO	NO	NO	4	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
576	B	B260	ORQUITIS POR PAROTIDITIS	NO	1	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
577	B	B261	MENINGITIS POR PAROTIDITIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
578	B	B262	ENCEFALITIS POR PAROTIDITIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
579	B	B263	PANCREATITIS POR PAROTIDITIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
580	B	B268	PAROTIDITIS INFECCIOSA CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
581	B	B269	PAROTIDITIS, SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	040	NO	NO	NO	SI	044	044	06Q	06Q	38	4	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	34	NO	SI	42	PAROTIDITIS INFECCIOSA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
582	B	B27	MONONUCLEOSIS INFECCIOSA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
583	B	B270	MONONUCLEOSIS DEBIDA A HERPES VIRUS GAMMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
584	B	B271	MONONUCLEOSIS POR CITOMEGALOVIRUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
585	B	B278	OTRAS MONONUCLEOSIS INFECCIOSAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
586	B	B279	MONONUCLEOSIS INFECCIOSA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
587	B	B30	CONJUNTIVITIS VIRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
588	B	B300	QUERATOCONJUNTIVITIS DEBIDA A ADENOVIRUS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
589	B	B301	CONJUNTIVITIS DEBIDA A ADENOVIRUS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
590	B	B302	FARINGOCONJUNTIVITIS VIRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
591	B	B303	CONJUNTIVITIS EPIDÉMICA AGUDA HEMORRÁGICA (ENTEROVÍRICA)	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	53	NO	SI	36	CONJUNTIVITIS EPIDEMICA AGUDA HEMORRAGICA	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
593	B	B309	CONJUNTIVITIS VIRAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
594	B	B33	OTRAS ENFERMEDADES VIRALES, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
595	B	B330	MIALGIA EPIDÉMICA	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
596	B	B331	ENFERMEDAD DEL RÍO ROSS	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
597	B	B332	CARDITIS VIRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
598	B	B333	INFECCIONES DEBIDAS A RETROVIRUS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
599	B	B334	SÍNDROME (CARDIO) PULMONAR POR HANTAVIRUS [SPH [SCPH (J17.1)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	A	2006 NUEVA CATEGORIA	2006	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
600	B	B338	OTRAS ENFERMEDADES VIRALES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
601	B	B34	INFECCIÓN VIRAL DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
602	B	B340	INFECCIÓN DEBIDA A ADENOVIRUS, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
603	B	B341	INFECCIÓN DEBIDA A ENTEROVIRUS, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
604	B	B342	INFECCIÓN DEBIDA A CORONAVIRUS, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
605	B	B343	INFECCIÓN DEBIDA A PARVOVIRUS, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
606	B	B344	INFECCIÓN DEBIDA A PAPOVAVIRUS,DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
607	B	B348	OTRAS INFECCIONES VIRALES DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
608	B	B349	INFECCIÓN VIRAL, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
609	B	B35	DERMATOFITOSIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
610	B	B350	TIÑA DE LA BARBA Y DEL CUERO CABELLUDO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
611	B	B351	TIÑA DE LAS UÑAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	67	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
592	B	B308	OTRAS CONJUNTIVITIS VIRALES	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	041	NO	NO	NO	SI	999	999	06Z	06Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	53	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
612	B	B352	TIÑA DE LA MANO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
613	B	B353	TIÑA DEL PIE [TINEA PEDIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
614	B	B354	TIÑA DEL CUERPO [TINEA CORPORIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
615	B	B355	TIÑA IMBRICADA [TINEA IMBRICATA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
616	B	B356	TIÑA INGUINAL [TINEA CRURIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
617	B	B358	OTRAS DERMATOFITOSIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
618	B	B359	DERMATOFITOSIS, NO ESPECIFICADA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	B35	DERMATOFITOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
619	B	B36	OTRAS MICOSIS SUPERFICIALES	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
620	B	B360	PITIRIASIS VERSICOLOR	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
622	B	B362	PIEDRA BLANCA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
623	B	B363	PIEDRA NEGRA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
624	B	B368	OTRAS MICOSIS SUPERFICIALES ESPECIFICADAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
625	B	B369	MICOSIS SUPERFICIAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
626	B	B37	CANDIDIASIS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
627	B	B370	ESTOMATITIS CANDIDIÁSICA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	65	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
628	B	B371	CANDIDIASIS PULMONAR	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
629	B	B372	CANDIDIASIS DE LA PIEL Y LAS UÑAS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
630	B	B373	CANDIDIASIS DE LA VULVA Y DE LA VAGINA	NO	2	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	129	NO	SI	20	CANDIDIASIS UROGENITAL	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
631	B	B374	CANDIDIASIS DE OTRAS LOCALIZACIONES UROGENITALES	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	20	CANDIDIASIS UROGENITAL	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
632	B	B375	MENINGITIS DEBIDA A CANDIDA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
621	B	B361	TIÑA NEGRA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	SI	66	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
633	B	B376	ENDOCARDITIS DEBIDA A CANDIDA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
634	B	B377	SEPSIS DEBIDA A CANDIDA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	C	2010 CORRECCION TITULOS	2014	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
635	B	B378	CANDIDIASIS DE OTROS SITIOS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
636	B	B379	CANDIDIASIS, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
637	B	B38	COCCIDIOIDOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
638	B	B380	COCCIDIOIDOMICOSIS PULMONAR AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
639	B	B381	COCCIDIOIDOMICOSIS PULMONAR CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
640	B	B382	COCCIDIOIDOMICOSIS PULMONAR, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
641	B	B383	COCCIDIOIDOMICOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
642	B	B384	MENINGITIS DEBIDA A COCCIDIOIDOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
643	B	B387	COCCIDIOIDOMICOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
644	B	B388	OTRAS FORMAS DE COCCIDIOIDOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
645	B	B389	COCCIDIOIDOMICOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
647	B	B390	INFECCIÓN PULMONAR AGUDA DEBIDA A HISTOPLASMA CAPSULATUM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
648	B	B391	INFECCIÓN PULMONAR CRÓNICA DEBIDA A HISTOPLASMA CAPSULATUM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
649	B	B392	INFECCIÓN PULMONAR DEBIDA A HISTOPLASMA CAPSULATUM, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
650	B	B393	INFECCIÓN DISEMINADA DEBIDA A HISTOPLASMA CAPSULATUM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
651	B	B394	HISTOPLASMOSIS DEBIDA A HISTOPLASMA CAPSULATUM, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
652	B	B395	INFECCIÓN DEBIDA A HISTOPLASMA DUBOISII	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
653	B	B399	HISTOPLASMOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
646	B	B39	HISTOPLASMOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
654	B	B40	BLASTOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
655	B	B400	BLASTOMICOSIS PULMONAR AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
656	B	B401	BLASTOMICOSIS PULMONAR CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
657	B	B402	BLASTOMICOSIS PULMONAR, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
658	B	B403	BLASTOMICOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
659	B	B407	BLASTOMICOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
660	B	B408	OTRAS FORMAS DE BLASTOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
661	B	B409	BLASTOMICOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
662	B	B41	PARACOCCIDIOIDOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
663	B	B410	PARACOCCIDIOIDOMICOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
664	B	B417	PARACOCCIDIOIDOMICOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
665	B	B418	OTRAS FORMAS DE PARACOCCIDIOIDOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
954	C	C052	TUMOR MALIGNO DE LA ÚVULA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
666	B	B419	PARACOCCIDIOIDOMICOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
667	B	B42	ESPOROTRICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
668	B	B420	ESPOROTRICOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
669	B	B421	ESPOROTRICOSIS LINFOCUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
670	B	B427	ESPOROTRICOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
671	B	B428	OTRAS FORMAS DE ESPOROTRICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
672	B	B429	ESPOROTRICOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
673	B	B43	CROMOMICOSIS Y ABSCESO FEOMICÓTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
674	B	B430	CROMOMICOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
675	B	B431	ABSCESO CEREBRAL FEOMICÓTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
676	B	B432	ABSCESO Y QUISTE SUBCUTÁNEO FEOMICÓTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
677	B	B438	OTRAS FORMAS DE CROMOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
678	B	B439	CROMOMICOSIS,NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
679	B	B44	ASPERGILOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
680	B	B440	ASPERGILOSIS PULMONAR INVASIVA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
681	B	B441	OTRAS ASPERGILOSIS PULMONARES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
682	B	B442	ASPERGILOSIS AMIGDALINA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
683	B	B447	ASPERGILOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
684	B	B448	OTRAS FORMAS DE ASPERGILOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
685	B	B449	ASPERGILOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
686	B	B45	CRIPTOCOCOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
687	B	B450	CRIPTOCOCOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
688	B	B451	CRIPTOCOCOSIS CEREBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	C	2003  CORRECCION TITULO	2003	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
689	B	B452	CRIPTOCOCOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
690	B	B453	CRIPTOCOCOSIS ÓSEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
691	B	B457	CRIPTOCOCOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
692	B	B458	OTRAS FORMAS DE CRIPTOCOCOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
693	B	B459	CRIPTOCOCOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
694	B	B46	CIGOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
695	B	B460	MUCORMICOSIS PULMONAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
696	B	B461	MUCORMICOSIS RINOCEREBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
697	B	B462	MUCORMICOSIS GASTROINTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
698	B	B463	MUCORMICOSIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
699	B	B464	MUCORMICOSIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
700	B	B465	MUCORMICOSIS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
701	B	B468	OTRAS CIGOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
702	B	B469	CIGOMICOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
703	B	B47	MICETOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
704	B	B470	EUMICETOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
705	B	B471	ACTINOMICETOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
706	B	B479	MICETOMA, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
707	B	B48	OTRAS MICOSIS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
708	B	B480	LOBOMICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
709	B	B481	RINOSPORIDIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
710	B	B482	ALESQUERIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
711	B	B483	GEOTRICOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
712	B	B484	PENICILOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
713	B	B487	MICOSIS OPORTUNISTAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
714	B	B488	OTRAS MICOSIS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
715	B	B49X	MICOSIS, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	042	NO	NO	NO	SI	020	020	05C	05C	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
716	B	B50	PALUDISMO [MALARIA DEBIDO A PLASMODIUM FALCIPARUM	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	NO	NO	NO	3	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	37	NO	SI	NO	NO	SI	SI	SI	NO	000	NO	NO	NO	NO	NO	NO
717	B	B500	PALUDISMO DEBIDO A PLASMODIUM FALCIPARUM CON COMPLICACIONES CEREBRALES	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	76	PALUDISMO POR PLASMODIUM FALCIPARUM	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
718	B	B508	OTRO PALUDISMO GRAVE Y COMPLICADO DEBIDO A PLASMODIUM FALCIPARUM	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	76	PALUDISMO POR PLASMODIUM FALCIPARUM	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
719	B	B509	PALUDISMO DEBIDO A PLASMODIUM FALCIPARUM, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	76	PALUDISMO POR PLASMODIUM FALCIPARUM	SI	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
720	B	B51	PALUDISMO [MALARIA DEBIDO A PLASMODIUM VIVAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	NO	NO	NO	3	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	37	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
721	B	B510	PALUDISMO DEBIDO A PLASMODIUM VIVAX CON RUPTURA ESPLÉNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	28	PALUDISMO POR PLASMODIUM VIVAX	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
722	B	B518	PALUDISMO DEBIDO A PLASMODIUM VIVAX CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	28	PALUDISMO POR PLASMODIUM VIVAX	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
723	B	B519	PALUDISMO DEBIDO A PLASMODIUM VIVAX, SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	37	SI	SI	28	PALUDISMO POR PLASMODIUM VIVAX	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
725	B	B520	PALUDISMO DEBIDO A PLASMODIUM MALARIAE CON NEFROPATÍA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
726	B	B528	PALUDISMO DEBIDO A PLASMODIUM MALARIAE CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
727	B	B529	PALUDISMO DEBIDO A PLASMODIUM MALARIAE, SIN COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
728	B	B53	OTRO PALUDISMO [MALARIA CONFIRMADO PARASITOLÓGICAMENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	37	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
729	B	B530	PALUDISMO DEBIDO A PLASMODIUM OVALE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
730	B	B531	PALUDISMO DEBIDO A PLASMODIOS DE LOS SIMIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
731	B	B538	OTRO PALUDISMO CONFIRMADO PARASITOLÓGICAMENTE, NO CLASIFICADO EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
732	B	B54X	PALUDISMO [MALARIA NO ESPECIFICADO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	07D	07D	22	3	22	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	37	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
733	B	B55	LEISHMANIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	022	001	044	NO	NO	NO	SI	047	047	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	40	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
734	B	B550	LEISHMANIASIS VISCERAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	022	001	044	NO	NO	NO	SI	047	047	07E	07E	26	3	26	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	40	SI	SI	144	LEISHMANIASIS VISCERAL	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
735	B	B551	LEISHMANIASIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	022	001	044	NO	NO	NO	SI	047	047	07E	07E	26	3	26	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	40	SI	SI	145	LEISHMANIASIS CUTANEA	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
736	B	B552	LEISHMANIASIS MUCOCUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	022	001	044	NO	NO	NO	SI	047	047	07E	07E	26	3	26	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	40	SI	NO	70	LEISHMANIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
737	B	B559	LEISHMANIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	022	001	044	NO	NO	NO	SI	047	047	07E	07E	26	3	26	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	SI	40	SI	NO	70	LEISHMANIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
738	B	B56	TRIPANOSOMIASIS AFRICANA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
739	B	B560	TRIPANOSOMIASIS GAMBIENSE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
740	B	B561	TRIPANOSOMIASIS RHODESIENSE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
741	B	B569	TRIPANOSOMIASIS AFRICANA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	NO	0	NO	NO	SI	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
742	B	B57	ENFERMEDAD DE CHAGAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	NO	NO	NO	3	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	39	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
743	B	B570	ENFERMEDAD DE CHAGAS AGUDA QUE AFECTA AL CORAZÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	186	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) AGUDA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
724	B	B52	PALUDISMO [MALARIA DEBIDO A PLASMODIUM MALARIAE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	021	001	043	NO	NO	NO	SI	046	046	NO	NO	NO	3	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	37	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
744	B	B571	ENFERMEDAD DE CHAGAS AGUDA QUE NO AFECTA AL CORAZÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	186	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) AGUDA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
745	B	B572	ENFERMEDAD DE CHAGAS (CRÓNICA) QUE AFECTA AL CORAZÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	187	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) CRONICA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	SI	NO
746	B	B573	ENFERMEDAD DE CHAGAS (CRÓNICA) QUE AFECTA AL SISTEMA DIGESTIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	187	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) CRONICA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
747	B	B574	ENFERMEDAD DE CHAGAS (CRÓNICA) QUE AFECTA AL SISTEMA NERVIOSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	187	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) CRONICA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
748	B	B575	ENFERMEDAD DE CHAGAS (CRÓNICA) QUE AFECTA OTROS ÓRGANOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	023	001	045	NO	NO	NO	SI	048	048	07F	07F	24	3	24	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	SI	39	SI	SI	187	TRIPANOSOMIASIS AMERICANA (ENFERMEDAD DE CHAGAS) CRONICA (PARA 2017)	NO	SI	SI	NO	999	NO	NO	NO	NO	NO	NO
749	B	B58	TOXOPLASMOSIS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
750	B	B580	OCULOPATÍA DEBIDA A TOXOPLASMA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
751	B	B581	HEPATITIS DEBIDA A TOXOPLASMA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
752	B	B582	MENINGOENCEFALITIS DEBIDA A TOXOPLASMA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
753	B	B583	TOXOPLASMOSIS PULMONAR	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
754	B	B588	TOXOPLASMOSIS CON OTRO ÓRGANO AFECTADO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
755	B	B589	TOXOPLASMOSIS, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	105	TOXOPLASMOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
756	B	B59X	NEUMOCISTOSIS (J17.3)	SI	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	C	2003 (SE ELIMINO DAGA Y AGREGA CODIGO DE ASTERISCO)	2003	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
757	B	B60	OTRAS ENFERMEDADES DEBIDAS A PROTOZOARIOS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
758	B	B600	BABESIOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
759	B	B601	ACANTAMEBIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
760	B	B602	NAEGLERIASIS	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	NO	SI	0	NO	NO	SI	SI	68	MENINGOENCEFALITIS AMEBIANA PRIMARIA	SI	NO	SI	NO	999	NO	NO	NO	NO	SI	NO
761	B	B608	OTRAS ENFERMEDADES ESPECIFICADAS DEBIDAS A PROTOZOARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
762	B	B64X	ENFERMEDAD DEBIDA A PROTOZOARIOS, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
763	B	B65	ESQUISTOSOMIASIS [BILHARZIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	73	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
764	B	B650	ESQUISTOSOMIASIS DEBIDA A SCHISTOSOMA HAEMATOBIUM (ESQUISTOSOMIASIS URINARIA)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
765	B	B651	ESQUISTOSOMIASIS DEBIDA A SCHISTOSOMA MANSONI [ESQUISTOSOMIASIS INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
766	B	B652	ESQUISTOSOMIASIS DEBIDA A SCHISTOSOMA JAPONICUM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
767	B	B653	DERMATITIS POR CERCARIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
768	B	B658	OTRAS ESQUISTOSOMIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
769	B	B659	ESQUISTOSOMIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	024	001	046	NO	NO	NO	SI	021	021	05D	05D	25	88	25	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	73	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
770	B	B66	OTRAS INFECCIONES DEBIDAS A TREMATODOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
771	B	B660	OPISTORQUIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
772	B	B661	CLONORQUIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
773	B	B662	DICROCOELIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
774	B	B663	FASCIOLIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
775	B	B664	PARAGONIMIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
776	B	B665	FASCIOLOPSIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
777	B	B668	OTRAS INFECCIONES ESPECIFICADAS DEBIDAS A TREMATODOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
778	B	B669	INFECCIÓN DEBIDA A TREMATODOS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	047	NO	NO	NO	SI	999	999	05E	05E	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
780	B	B670	INFECCIÓN DEL HÍGADO DEBIDA A ECHINOCOCCUS GRANULOSUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
781	B	B671	INFECCIÓN DEL PULMÓN DEBIDA A ECHINOCOCCUS GRANULOSUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
782	B	B672	INFECCIÓN DE HUESO DEBIDA A ECHINOCOCCUS GRANULOSUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
783	B	B673	INFECCIÓN DE OTRO ÓRGANO Y DE SITIOS MÚLTIPLES DEBIDA A ECHINOCOCCUS GRANULOSUS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
784	B	B674	INFECCIÓN DEBIDA A ECHINOCOCCUS GRANULOSUS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
779	B	B67	EQUINOCOCOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	72	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
785	B	B675	INFECCIÓN DEL HÍGADO DEBIDA A ECHINOCOCCUS MULTILOCULARIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
786	B	B676	INFECCIÓN DE OTRO ÓRGANO Y DE SITIOS MÚLTIPLES DEBIDA A ECHINOCOCCUS MULTILOCULARIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
787	B	B677	INFECCIÓN DEBIDA A ECHINOCOCCUS MULTILOCULARIS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
788	B	B678	EQUINOCOCOSIS DEL HÍGADO, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
789	B	B679	EQUINOCOCOSIS, OTRA Y LA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	048	NO	NO	NO	SI	022	022	05F	05F	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	72	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
790	B	B68	TENIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	77	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
791	B	B680	TENIASIS DEBIDA A TAENIA SOLIUM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	77	NO	SI	12	TENIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
792	B	B681	INFECCIÓN DEBIDA A TAENIA SAGINATA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	77	NO	SI	12	TENIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
793	B	B689	TENIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	77	NO	SI	12	TENIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
794	B	B69	CISTICERCOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
795	B	B690	CISTICERCOSIS DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	30	CISTICERCOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
796	B	B691	CISTICERCOSIS DEL OJO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	30	CISTICERCOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
797	B	B698	CISTICERCOSIS DE OTROS SITIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	30	CISTICERCOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
798	B	B699	CISTICERCOSIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	30	CISTICERCOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
799	B	B70	DIFILOBOTRIASIS Y ESPARGANOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
800	B	B700	DIFILOBOTRIASIS INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
801	B	B701	ESPARGANOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
802	B	B71	OTRAS INFECCIONES DEBIDAS A CESTODOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
803	B	B710	HIMENOLEPIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
804	B	B711	DIPILIDIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
805	B	B718	OTRAS INFECCIONES DEBIDAS A CESTODOS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
806	B	B719	INFECCIONES DEBIDAS A CESTODOS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
807	B	B72X	DRACONTIASIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	049	NO	NO	NO	SI	023	023	05G	05G	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
808	B	B73X	ONCOCERCOSIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	050	NO	NO	NO	SI	024	024	05H	05H	28	88	28	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	NO	0	SI	38	SI	SI	69	ONCOCERCOSIS	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
809	B	B74	FILARIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	75	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
810	B	B740	FILARIASIS DEBIDA A WUCHERERIA BANCROFTI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
811	B	B741	FILARIASIS DEBIDA A BRUGIA MALAYI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
812	B	B742	FILARIASIS DEBIDA A BRUGIA TIMORI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
813	B	B743	LOAIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
814	B	B744	MANSONELIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
815	B	B748	OTRAS FILARIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
816	B	B749	FILARIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	051	NO	NO	NO	SI	025	025	05I	05I	27	88	27	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	SI	NO	NO	SI	SI	0	SI	75	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
817	B	B75X	TRIQUINOSIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	79	SI	SI	103	TRIQUINOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
818	B	B76	ANQUILOSTOMIASIS Y NECATORIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	052	NO	NO	NO	SI	026	026	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	SI	69	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
819	B	B760	ANQUILOSTOMIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	052	NO	NO	NO	SI	026	026	05J	05J	36	88	36	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	69	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
820	B	B761	NECATORIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	052	NO	NO	NO	SI	026	026	05J	05J	36	88	36	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	69	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
821	B	B768	OTRAS ENFERMEDADES DEBIDAS A ANQUILOSTOMAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	052	NO	NO	NO	SI	026	026	05J	05J	36	88	36	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	69	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
822	B	B769	ENFERMEDAD DEBIDA A ANQUILOSTOMAS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	052	NO	NO	NO	SI	026	026	05J	05J	36	88	36	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	69	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
823	B	B77	ASCARIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	70	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
824	B	B770	ASCARIASIS CON COMPLICACIONES INTESTINALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	34	88	34	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	70	SI	SI	04	ASCARIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
825	B	B778	ASCARIASIS CON OTRAS COMPLICACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	34	88	34	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	70	SI	SI	04	ASCARIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
826	B	B779	ASCARIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	34	88	34	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	70	SI	SI	04	ASCARIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
827	B	B78	ESTRONGILOIDIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	74	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
828	B	B780	ESTRONGILOIDIASIS INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	74	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
829	B	B781	ESTRONGILOIDIASIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	74	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
830	B	B787	ESTRONGILOIDIASIS DISEMINADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	74	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
831	B	B789	ESTRONGILOIDIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	74	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
832	B	B79X	TRICURIASIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	35	88	35	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	78	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
833	B	B80X	ENTEROBIASIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	SI	71	SI	SI	10	ENTEROBIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
834	B	B81	OTRAS HELMINTIASIS INTESTINALES, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
835	B	B810	ANISAQUIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
836	B	B811	CAPILARIASIS INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
837	B	B812	TRICOESTRONGILIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
838	B	B813	ANGIOESTRONGILIASIS INTESTINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
839	B	B814	HELMINTIASIS INTESTINAL MIXTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
840	B	B818	OTRAS HELMINTIASIS INTESTINALES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
841	B	B82	PARASITOSIS INTESTINAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
842	B	B820	HELMINTIASIS INTESTINAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
843	B	B829	PARASITOSIS INTESTINAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
844	B	B83	OTROS HELMINTIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	SI	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
845	B	B830	LARVA MIGRANS VISCERAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
846	B	B831	GNATOSTOMIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
847	B	B832	ANGIOESTRONGILIASIS DEBIDA A PARASTRONGYLUS CANTONENSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	SI	NO
848	B	B833	SINGAMIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
849	B	B834	HIRUDINIASIS INTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
850	B	B838	OTRAS HELMINTIASIS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
851	B	B839	HELMINTIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	053	NO	NO	NO	SI	999	999	05K	05K	37	88	37	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	SI	NO	SI	SI	0	NO	NO	SI	SI	14	OTRAS HELMINTIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
852	B	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
853	B	B850	PEDICULOSIS DEBIDA A PEDICULUS HUMANUS CAPITIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
854	B	B851	PEDICULOSIS DEBIDA A PEDICULUS HUMANUS CORPORIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
855	B	B852	PEDICULOSIS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
856	B	B853	PHTHIRIASIS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
857	B	B854	PEDICULOSIS Y PHTHIRIASIS MIXTAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	82	NO	NO	B85	PEDICULOSIS Y PHTHIRIASIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
858	B	B86X	ESCABIOSIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	SI	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	81	NO	SI	43	ESCABIOSIS	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
859	B	B87	MIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
860	B	B870	MIASIS CUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
861	B	B871	MIASIS EN HERIDAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
862	B	B872	MIASIS OCULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
863	B	B873	MIASIS NASOFARÍNGEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
864	B	B874	MIASIS AURAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
865	B	B878	MIASIS DE OTROS SITIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
866	B	B879	MIASIS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
867	B	B88	OTRAS INFESTACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
868	B	B880	OTRAS ACARIASIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
869	B	B881	TUNGIASIS [INFECCIÓN DEBIDA A PULGA DE ARENA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
870	B	B882	OTRAS INFESTACIONES DEBIDAS A ARTRÓPODOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
871	B	B883	HIRUDINIASIS EXTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
872	B	B888	OTRAS INFESTACIONES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
873	B	B889	INFESTACIÓN, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
874	B	B89X	ENFERMEDAD PARASITARIA, NO ESPECIFICADA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
875	B	B90	SECUELAS DE TUBERCULOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
876	B	B900	SECUELAS DE TUBERCULOSIS DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	05L	05L	3	88	3	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
877	B	B901	SECUELAS DE TUBERCULOSIS GENITOURINARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	05L	05L	3	88	3	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
878	B	B902	SECUELAS DE TUBERCULOSIS DE HUESOS Y ARTICULACIONES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	05L	05L	3	88	3	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
879	B	B908	SECUELAS DE TUBERCULOSIS DE OTROS ÓRGANOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	05L	05L	3	88	3	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
880	B	B909	SECUELAS DE TUBERCULOSIS RESPIRATORIA Y DE TUBERCULOSIS NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	054	NO	NO	NO	SI	027	027	05L	05L	3	88	3	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
881	B	B91X	SECUELAS DE POLIOMIELITIS	SI	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	055	NO	NO	NO	SI	028	028	05M	05M	13	88	13	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
882	B	B92X	SECUELAS DE LEPRA	SI	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	056	NO	NO	NO	SI	029	029	05N	05N	29	88	29	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
883	B	B94	SECUELAS DE OTRAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS DE LOS NO ESPECIFICADAS	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
884	B	B940	SECUELAS DE TRACOMA	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05O	05O	32	88	32	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
885	B	B941	SECUELAS DE ENCEFALITIS VIRAL	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05O	05O	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
886	B	B942	SECUELAS DE HEPATITIS VIRAL	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05O	05O	21	88	21	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
887	B	B948	SECUELAS DE OTRAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS ESPECIFICADAS	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05O	05O	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
888	B	B949	SECUELAS DE ENFERMEDADES INFECCIOSAS Y PARASITARIAS NO ESPECIFICADAS	NO	NO	001A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05O	05O	38	88	38	NO	NO	NO	NO	1	CAUSAS POCO PROBALBES DE SER CAUSA BÁSICA	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
889	B	B95	ESTREPTOCOCOS Y ESTAFILOCOCOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
890	B	B950	ESTREPTOCOCO, GRUPO A, COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
891	B	B951	ESTREPTOCOCO, GRUPO B, COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
892	B	B952	ESTREPTOCOCO, GRUPO D Y ENTEROCOCOS, COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	C	2018 CAMBIO DE TITULO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
893	B	B953	STREPTOCOCCUS PNEUMONIAE COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
894	B	B954	OTROS ESTREPTOCOCOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
895	B	B955	ESTREPTOCOCO NO ESPECIFICADO COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
896	B	B956	STAPHYLOCOCCUS AUREUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
898	B	B958	ESTAFILOCOCO NO ESPECIFICADO, COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
899	B	B96	OTROS AGENTES BACTERIANOS ESPECIFICADOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	C	2010 CORRECCION TITULOS	2014	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
900	B	B960	MYCOPLASMA PNEUMONIAE [M. PNEUMONIAE COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
901	B	B961	KLEBSIELLA PNEUMONIAE [K. PNEUMONIAE COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
902	B	B962	ESCHERICHIA COLI [E. COLI COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
903	B	B963	HAEMOPHILUS INFLUENZAE [H. INFLUENZAE COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
904	B	B964	PROTEUS (MIRABILIS) (MORGANII) COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
905	B	B965	PSEUDOMONAS (AERUGINOSA) COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	C	2010 CORRECCION TITULOS	2014	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
906	B	B966	BACILLUS FRAGILIS [B. FRAGILIS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
907	B	B967	CLOSTRIDIUM PERFRINGENS [C. PERFRINGENS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
908	B	B968	OTROS AGENTES BACTERIANOS ESPECIFICADOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
909	B	B97	AGENTES VIRALES COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
910	B	B970	ADENOVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
911	B	B971	ENTEROVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
912	B	B972	CORONAVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
913	B	B973	RETROVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
897	B	B957	OTROS ESTAFILOCOCOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
914	B	B974	VIRUS SINCICIAL RESPIRATORIO COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
915	B	B975	REOVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
916	B	B976	PARVOVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
917	B	B977	PAPILOMAVIRUS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	SI	1	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	SI	254	NO	SI	101	INFECCION POR VIRUS DEL PAPILOMA HUMANO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
918	B	B978	OTROS AGENTES VIRALES COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	NO	NO	NO	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
919	B	B98	OTROS AGENTES INFECCIOSOS ESPECIFICADOS COMO CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	A	2010 NUEVA CATEGORIA	2014	SI	999	999	05Z	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
920	B	B980	HELICOBACTER PYLORI [H.PYLORI COMO LA CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	A	2010 NUEVA CATEGORIA	2014	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
921	B	B981	VIBRIO VULNIFICUS COMO LA CAUSA DE ENFERMEDADES CLASIFICADAS EN OTROS CAPÍTULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	NO	NO	NO	A	2010 NUEVA CATEGORIA	2014	SI	999	999	05Z	NO	38	88	38	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
922	B	B99X	OTRAS ENFERMEDADES INFECCIOSAS Y LAS NO ESPECIFICADAS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	SI	NO	NO	01	I     CIERTAS ENFERMEDADES INFECCIOSAS Y PARASITARIAS	025	001	057	NO	NO	NO	SI	999	999	05Z	05Z	38	88	38	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
923	C	C00	TUMOR MALIGNO DEL LABIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
924	C	C000	TUMOR MALIGNO DEL LABIO SUPERIOR, CARA EXTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
925	C	C001	TUMOR MALIGNO DEL LABIO INFERIOR, CARA EXTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
926	C	C002	TUMOR MALIGNO DEL LABIO, CARA EXTERNA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
927	C	C003	TUMOR MALIGNO DEL LABIO SUPERIOR, CARA INTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
928	C	C004	TUMOR MALIGNO DEL LABIO INFERIOR, CARA INTERNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
929	C	C005	TUMOR MALIGNO DEL LABIO, CARA INTERNA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
930	C	C006	TUMOR MALIGNO DE LA COMISURA LABIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
931	C	C008	LESIÓN DE SITIOS CONTIGUOS DEL LABIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
932	C	C009	TUMOR MALIGNO DEL LABIO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
933	C	C01X	TUMOR MALIGNO DE LA BASE DE LA LENGUA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
934	C	C02	TUMOR MALIGNO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
935	C	C020	TUMOR MALIGNO DE LA CARA DORSAL DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
936	C	C021	TUMOR MALIGNO DEL BORDE DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
937	C	C022	TUMOR MALIGNO DE LA CARA VENTRAL DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
938	C	C023	TUMOR MALIGNO DE LOS DOS TERCIOS ANTERIORES DE LA LENGUA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
939	C	C024	TUMOR MALIGNO DE LA AMÍGDALA LINGUAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
940	C	C028	LESIÓN DE SITIOS CONTIGUOS DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
941	C	C029	TUMOR MALIGNO DE LA LENGUA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
942	C	C03	TUMOR MALIGNO DE LA ENCÍA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
943	C	C030	TUMOR MALIGNO DE LA ENCÍA SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
944	C	C031	TUMOR MALIGNO DE LA ENCÍA INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
945	C	C039	TUMOR MALIGNO DE LA ENCÍA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
946	C	C04	TUMOR MALIGNO DEL PISO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
947	C	C040	TUMOR MALIGNO DE LA PARTE ANTERIOR DEL PISO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
948	C	C041	TUMOR MALIGNO DE LA PARTE LATERAL DEL PISO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
949	C	C048	LESIÓN DE SITIOS CONTIGUOS DEL PISO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
950	C	C049	TUMOR MALIGNO DEL PISO DE LA BOCA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
951	C	C05	TUMOR MALIGNO DEL PALADAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
952	C	C050	TUMOR MALIGNO DEL PALADAR DURO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
955	C	C058	LESIÓN DE SITIOS CONTIGUOS DEL PALADAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
956	C	C059	TUMOR MALIGNO DEL PALADAR, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
957	C	C06	TUMOR MALIGNO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
958	C	C060	TUMOR MALIGNO DE LA MUCOSA DE LA MEJILLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
959	C	C061	TUMOR MALIGNO DEL VESTÍBULO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
960	C	C062	TUMOR MALIGNO DEL ÁREA RETROMOLAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
961	C	C068	LESIÓN DE SITIOS CONTIGUOS DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
962	C	C069	TUMOR MALIGNO DE LA BOCA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
963	C	C07X	TUMOR MALIGNO DE LA GLÁNDULA PARÓTIDA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
964	C	C08	TUMOR MALIGNO DE OTRAS GLÁNDULAS SALIVALES MAYORES Y DE LAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
965	C	C080	TUMOR MALIGNO DE LA GLÁNDULA SUBMAXILAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
966	C	C081	TUMOR MALIGNO DE LA GLÁNDULA SUBLINGUAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
967	C	C088	LESIÓN DE SITIOS CONTIGUOS DE LAS GLÁNDULAS SALIVALES MAYORES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
968	C	C089	TUMOR MALIGNO DE GLÁNDULA SALIVAL MAYOR, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
969	C	C09	TUMOR MALIGNO DE LA AMÍGDALA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
970	C	C090	TUMOR MALIGNO DE LA FOSA AMIGDALINA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
971	C	C091	TUMOR MALIGNO DEL PILAR AMIGDALINO (ANTERIOR) (POSTERIOR)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
972	C	C098	LESIÓN DE SITIOS CONTIGUOS DE LA AMÍGDALA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
973	C	C099	TUMOR MALIGNO DE LA AMÍGDALA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
974	C	C10	TUMOR MALIGNO DE LA OROFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
975	C	C100	TUMOR MALIGNO DE LA VALÉCULA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
976	C	C101	TUMOR MALIGNO DE LA CARA ANTERIOR DE LA EPIGLOTIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
977	C	C102	TUMOR MALIGNO DE LA PARED LATERAL DE LA OROFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
978	C	C103	TUMOR MALIGNO DE LA PARED POSTERIOR DE LA OROFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
979	C	C104	TUMOR MALIGNO DE LA HENDIDURA BRANQUIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
980	C	C108	LESIÓN DE SITIOS CONTIGUOS DE LA OROFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
981	C	C109	TUMOR MALIGNO DE LA OROFARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
982	C	C11	TUMOR MALIGNO DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
983	C	C110	TUMOR MALIGNO DE LA PARED SUPERIOR DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
984	C	C111	TUMOR MALIGNO DE LA PARED POSTERIOR DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
985	C	C112	TUMOR MALIGNO DE LA PARED LATERAL DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
986	C	C113	TUMOR MALIGNO DE LA PARED ANTERIOR DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
987	C	C118	LESIÓN DE SITIOS CONTIGUOS DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
988	C	C119	TUMOR MALIGNO DE LA NASOFARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
989	C	C12X	TUMOR MALIGNO DEL SENO PIRIFORME	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
990	C	C13	TUMOR MALIGNO DE LA HIPOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
991	C	C130	TUMOR MALIGNO DE LA REGIÓN POSTCRICOIDEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
992	C	C131	TUMOR MALIGNO DEL PLIEGUE ARITENOEPIGLÓTICO, CARA HIPOFARÍNGEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
993	C	C132	TUMOR MALIGNO DE LA PARED POSTERIOR DE LA HIPOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
994	C	C138	LESIÓN DE SITIOS CONTIGUOS DE LA HIPOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
995	C	C139	TUMOR MALIGNO DE LA HIPOFARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
996	C	C14	TUMOR MALIGNO DE OTROS SITIOS Y DE LOS MAL DEFINIDOS DEL LABIO, DE LA CAVIDAD BUCAL Y DE LA FARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
997	C	C140	TUMOR MALIGNO DE LA FARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
998	C	C142	TUMOR MALIGNO DEL ANILLO DE WALDEYER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
999	C	C148	LESIÓN DE SITIOS CONTIGUOS DEL LABIO, DE LA CAVIDAD BUCAL Y DE LA FARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	027	026	058	NO	NO	NO	SI	049A	049A	08	08	62	88	62	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1000	C	C15	TUMOR MALIGNO DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	NO	NO	NO	8	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1001	C	C150	TUMOR MALIGNO DEL ESÓFAGO, PORCIÓN CERVICAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1002	C	C151	TUMOR MALIGNO DEL ESÓFAGO, PORCIÓN TORÁCICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1003	C	C152	TUMOR MALIGNO DEL ESÓFAGO, PORCIÓN ABDOMINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1004	C	C153	TUMOR MALIGNO DEL TERCIO SUPERIOR DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1005	C	C154	TUMOR MALIGNO DEL TERCIO MEDIO DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1006	C	C155	TUMOR MALIGNO DEL TERCIO INFERIOR DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1007	C	C158	LESIÓN DE SITIOS CONTIGUOS DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1008	C	C159	TUMOR MALIGNO DEL ESÓFAGO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	028	026	059	NO	NO	NO	SI	049B	049B	09A	09A	63	8	63	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1009	C	C16	TUMOR MALIGNO DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	NO	NO	NO	9	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1010	C	C160	TUMOR MALIGNO DEL CARDIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1011	C	C161	TUMOR MALIGNO DEL FUNDUS GÁSTRICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1012	C	C162	TUMOR MALIGNO DEL CUERPO DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1013	C	C163	TUMOR MALIGNO DEL ANTRO PILÓRICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1014	C	C164	TUMOR MALIGNO DEL PÍLORO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1015	C	C165	TUMOR MALIGNO DE LA CURVATURA MENOR DEL ESTÓMAGO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1016	C	C166	TUMOR MALIGNO DE LA CURVATURA MAYOR DEL ESTÓMAGO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1017	C	C168	LESIÓN DE SITIOS CONTIGUOS DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1018	C	C169	TUMOR MALIGNO DEL ESTÓMAGO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	029	026	060	NO	NO	NO	SI	049C	049C	09B	09B	64	9	64	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1019	C	C17	TUMOR MALIGNO DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1020	C	C170	TUMOR MALIGNO DEL DUODENO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1021	C	C171	TUMOR MALIGNO DEL YEYUNO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1022	C	C172	TUMOR MALIGNO DEL ÍLEON	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1023	C	C173	TUMOR MALIGNO DEL DIVERTÍCULO DE MECKEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1024	C	C178	LESIÓN DE SITIOS CONTIGUOS DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1025	C	C179	TUMOR MALIGNO DEL INTESTINO DELGADO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049D	049D	09C	09C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1027	C	C180	TUMOR MALIGNO DEL CIEGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1028	C	C181	TUMOR MALIGNO DEL APÉNDICE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1029	C	C182	TUMOR MALIGNO DEL COLON ASCENDENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1030	C	C183	TUMOR MALIGNO DEL ÁNGULO HEPÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1031	C	C184	TUMOR MALIGNO DEL COLON TRANSVERSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1032	C	C185	TUMOR MALIGNO DEL ÁNGULO ESPLÉNICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1033	C	C186	TUMOR MALIGNO DEL COLON DESCENDENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1034	C	C187	TUMOR MALIGNO DEL COLON SIGMOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1035	C	C188	LESIÓN DE SITIOS CONTIGUOS DEL COLON	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1036	C	C189	TUMOR MALIGNO DEL COLON, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	061	NO	NO	NO	SI	049E	049E	09D	09D	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1037	C	C19X	TUMOR MALIGNO DE LA UNIÓN RECTOSIGMOIDEA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1038	C	C20X	TUMOR MALIGNO DEL RECTO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1039	C	C21	TUMOR MALIGNO DEL ANO Y DEL CONDUCTO ANAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	NO	NO	NO	10	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1040	C	C210	TUMOR MALIGNO DEL ANO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1041	C	C211	TUMOR MALIGNO DEL CONDUCTO ANAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1042	C	C212	TUMOR MALIGNO DE LA ZONA CLOACOGÉNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1043	C	C218	LESIÓN DE SITIOS CONTIGUOS DEL ANO, DEL CONDUCTO ANAL Y DEL RECTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	030	026	062	NO	NO	NO	SI	049F	049F	09E	09E	65	10	65	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1044	C	C22	TUMOR MALIGNO DEL HÍGADO Y DE LAS VÍAS BILIARES INTRAHEPÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	NO	NO	NO	11	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1045	C	C220	CARCINOMA DE CÉLULAS HEPÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1046	C	C221	CARCINOMA DE VÍAS BILIARES INTRAHEPÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1047	C	C222	HEPATOBLASTOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1048	C	C223	ANGIOSARCOMA DEL HÍGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1049	C	C224	OTROS SARCOMAS DEL HÍGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1050	C	C227	OTROS CARCINOMAS ESPECIFICADOS DEL HÍGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1051	C	C229	TUMOR MALIGNO DEL HÍGADO, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	031	026	063	NO	NO	NO	SI	049G	049G	09F	09F	66	11	66	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1052	C	C23X	TUMOR MALIGNO DE LA VESÍCULA BILIAR	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	12	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1053	C	C24	TUMOR MALIGNO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LAS VÍAS BILIARES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	NO	NO	NO	12	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1054	C	C240	TUMOR MALIGNO DE LAS VÍAS BILIARES EXTRAHEPÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	12	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1055	C	C241	TUMOR MALIGNO DE LA AMPOLLA DE VATER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	12	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1056	C	C248	LESIÓN DE SITIOS CONTIGUOS DE LAS VÍAS BILIARES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	12	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1057	C	C249	TUMOR MALIGNO DE LAS VÍAS BILIARES, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	12	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1058	C	C25	TUMOR MALIGNO DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	NO	NO	NO	13	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1059	C	C250	TUMOR MALIGNO DE LA CABEZA DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1060	C	C251	TUMOR MALIGNO DEL CUERPO DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1061	C	C252	TUMOR MALIGNO DE LA COLA DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1062	C	C253	TUMOR MALIGNO DEL CONDUCTO PANCREÁTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1063	C	C254	TUMOR MALIGNO DEL PÁNCREAS ENDOCRINO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1064	C	C257	TUMOR MALIGNO DE OTRAS PARTES ESPECIFICADAS DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1065	C	C258	LESIÓN DE SITIOS CONTIGUOS DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1066	C	C259	TUMOR MALIGNO DEL PÁNCREAS, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	032	026	064	NO	NO	NO	SI	049H	049H	09G	09G	67	13	67	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1067	C	C26	TUMOR MALIGNO DE OTROS SITIOS Y DE LOS MAL DEFINIDOS DE LOS ÓRGANOS DIGESTIVOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1068	C	C260	TUMOR MALIGNO DEL INTESTINO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1069	C	C261	TUMOR MALIGNO DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1070	C	C268	LESIÓN DE SITIOS CONTIGUOS DE LOS ÓRGANOS DIGESTIVOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1071	C	C269	TUMOR MALIGNO DE SITIOS MAL DEFINIDOS DE LOS ÓRGANOS DIGESTIVOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	065	NO	NO	NO	SI	049	049	09Z	09Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1072	C	C30	TUMOR MALIGNO DE LAS FOSAS NASALES Y DEL OÍDO MEDIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1073	C	C300	TUMOR MALIGNO DE LA FOSA NASAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1074	C	C301	TUMOR MALIGNO DEL OÍDO MEDIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1075	C	C31	TUMOR MALIGNO DE LOS SENOS PARANASALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1076	C	C310	TUMOR MALIGNO DEL SENO MAXILAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1077	C	C311	TUMOR MALIGNO DEL SENO ETMOIDAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1078	C	C312	TUMOR MALIGNO DEL SENO FRONTAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1080	C	C318	LESIÓN DE SITIOS CONTIGUOS DE LOS SENOS PARANASALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1082	C	C32	TUMOR MALIGNO DE LA LARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	NO	NO	NO	14	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1083	C	C320	TUMOR MALIGNO DE LA GLOTIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1084	C	C321	TUMOR MALIGNO DE LA REGIÓN SUPRAGLÓTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1085	C	C322	TUMOR MALIGNO DE LA REGIÓN SUBGLÓTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1086	C	C323	TUMOR MALIGNO DEL CARTÍLAGO LARÍNGEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1087	C	C328	LESIÓN DE SITIOS CONTIGUOS DE LA LARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1088	C	C329	TUMOR MALIGNO DE LA LARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	033	026	066	NO	NO	NO	SI	049I	049I	10A	10A	78	14	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1089	C	C33X	TUMOR MALIGNO DE LA TRÁQUEA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1090	C	C34	TUMOR MALIGNO DE LOS BRONQUIOS Y DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	NO	NO	NO	15	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1091	C	C340	TUMOR MALIGNO DEL BRONQUIO PRINCIPAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1092	C	C341	TUMOR MALIGNO DEL LÓBULO SUPERIOR, BRONQUIO O PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1093	C	C342	TUMOR MALIGNO DEL LÓBULO MEDIO, BRONQUIO O PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1094	C	C343	TUMOR MALIGNO DEL LÓBULO INFERIOR, BRONQUIO O PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1095	C	C348	LESIÓN DE SITIOS CONTIGUOS DE LOS BRONQUIOS Y DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1096	C	C349	TUMOR MALIGNO DE LOS BRONQUIOS O DEL PULMÓN, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	034	026	067	NO	NO	NO	SI	049J	049J	10B	10B	68	15	68	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1097	C	C37X	TUMOR MALIGNO DEL TIMO	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1098	C	C38	TUMOR MALIGNO DEL CORAZÓN, DEL MEDIASTINO Y DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1099	C	C380	TUMOR MALIGNO DEL CORAZÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1100	C	C381	TUMOR MALIGNO DEL MEDIASTINO ANTERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1101	C	C382	TUMOR MALIGNO DEL MEDIASTINO POSTERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1102	C	C383	TUMOR MALIGNO DEL MEDIASTINO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1081	C	C319	TUMOR MALIGNO DE SENO PARANASAL NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1103	C	C384	TUMOR MALIGNO DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1104	C	C388	LESIÓN DE SITOS CONTIGUOS DEL CORAZÓN, DEL MEDIASTINO Y DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1105	C	C39	TUMOR MALIGNO DE OTROS SITIOS Y DE LOS MAL DEFINIDOS DEL SISTEMA RESPIRATORIO Y DE LOS ÓRGANOS INTRATORÁCICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1106	C	C390	TUMOR MALIGNO DE LA VÍAS RESPIRATORIA SUPERIORES, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1107	C	C398	LESIÓN DE SITIOS CONTIGUOS DE LOS ÓRGANOS RESPIRATORIOS E INTRATORÁCICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1108	C	C399	TUMOR MALIGNO DE SITIOS MAL DEFINIDOS DEL SISTEMA RESPIRATORIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	068	NO	NO	NO	SI	049	049	10Z	10Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1109	C	C40	TUMOR MALIGNO DE LOS HUESOS Y DE LOS CARTÍLAGOS ARTICULARES DE LOS MIEMBROS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1110	C	C400	TUMOR MALIGNO DEL OMÓPLATO Y DE LOS HUESOS LARGOS DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1111	C	C401	TUMOR MALIGNO DE LOS HUESOS CORTOS DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1112	C	C402	TUMOR MALIGNO DE LOS HUESOS LARGOS DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1113	C	C403	TUMOR MALIGNO DE LOS HUESOS CORTOS DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1114	C	C408	LESIÓN DE SITIOS CONTIGUOS DE LOS HUESOS Y DE LOS CARTÍLAGOS ARTICULARES DE LOS MIEMBROS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1115	C	C409	TUMOR MALIGNO DE LOS HUESOS Y DE LOS CARTÍLAGOS ARTICULARES DE LOS MIEMBROS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1116	C	C41	TUMOR MALIGNO DE LOS HUESOS Y DE LOS CARTÍLAGOS ARTICULARES, DE OTROS SITIOS Y DE SITIOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1117	C	C410	TUMOR MALIGNO DE LOS HUESOS DEL CRÁNEO Y DE LA CARA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1118	C	C411	TUMOR MALIGNO DEL HUESO DEL MAXILAR INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1119	C	C412	TUMOR MALIGNO DE LA COLUMNA VERTEBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1120	C	C413	TUMOR MALIGNO DE LA COSTILLA, ESTERNÓN Y CLAVÍCULA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1121	C	C414	TUMOR MALIGNO DE LOS HUESOS DE LA PELVIS, SACRO Y CÓCCIX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1238	C	C630	TUMOR MALIGNO DEL EPIDÍDIMO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1122	C	C418	LESIÓN DE SITIOS CONTIGUOS DEL HUESO Y DEL CARTÍLAGO ARTICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1123	C	C419	TUMOR MALIGNO DEL HUESO Y DEL CARTÍLAGO ARTICULAR, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	069	NO	NO	NO	SI	049K	049K	11A	11A	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1124	C	C43	MELANOMA MALIGNO DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	NO	NO	NO	16	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1125	C	C430	MELANOMA MALIGNO DEL LABIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1126	C	C431	MELANOMA MALIGNO DEL PÁRPADO, INCLUIDA LA COMISURA PALPEBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1127	C	C432	MELANOMA MALIGNO DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1128	C	C433	MELANOMA MALIGNO DE LAS OTRAS PARTES Y LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1129	C	C434	MELANOMA MALIGNO DEL CUERO CABELLUDO Y DEL CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1130	C	C435	MELANOMA MALIGNO DEL TRONCO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1131	C	C436	MELANOMA MALIGNO DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	C	2003 CORRECCION TITULO	2003	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1132	C	C437	MELANOMA MALIGNO DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	C	2003 CORRECCION TITULO	2003	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1133	C	C438	MELANOMA MALIGNO DE SITIOS CONTIGUOS DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1134	C	C439	MELANOMA MALIGNO DE PIEL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	035	026	070	NO	NO	NO	SI	049L	049L	11B	11B	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1135	C	C44	OTROS TUMORES MALIGNOS DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	NO	NO	NO	16	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1136	C	C440	TUMOR MALIGNO DE LA PIEL DEL LABIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1137	C	C441	TUMOR MALIGNO DE LA PIEL DEL PÁRPADO, INCLUIDA LA COMISURA PALPEBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1138	C	C442	TUMOR MALIGNO DE LA PIEL DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1139	C	C443	TUMOR MALIGNO DE LA PIEL DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1140	C	C444	TUMOR MALIGNO DE LA PIEL DEL CUERO CABELLUDO Y DEL CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1141	C	C445	TUMOR MALIGNO DE LA PIEL DEL TRONCO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1142	C	C446	TUMOR MALIGNO DE LA PIEL DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1143	C	C447	TUMOR MALIGNO DE LA PIEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1144	C	C448	LESIÓN DE SITIOS CONTIGUOS DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1145	C	C449	TUMOR MALIGNO DE LA PIEL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	071	NO	NO	NO	SI	049	049	11C	11C	69	16	69	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	251	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1146	C	C45	MESOTELIOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1147	C	C450	MESOTELIOMA DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1148	C	C451	MESOTELIOMA DEL PERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1149	C	C452	MESOTELIOMA DEL PERICARDIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1150	C	C457	MESOTELIOMA DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1151	C	C459	MESOTELIOMA, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1152	C	C46	SARCOMA DE KAPOSI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1153	C	C460	SARCOMA DE KAPOSI DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1154	C	C461	SARCOMA DE KAPOSI DEL TEJIDO BLANDO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1155	C	C462	SARCOMA DE KAPOSI DEL PALADAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1156	C	C463	SARCOMA DE KAPOSI DE LOS GANGLIOS LINFÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1157	C	C467	SARCOMA DE KAPOSI DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1158	C	C468	SARCOMA DE KAPOSI DE MÚLTIPLES ÓRGANOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1159	C	C469	SARCOMA DE KAPOSI DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1160	C	C47	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS Y DEL SISTEMA NERVIOSO AUTÓNOMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1161	C	C470	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DE LA CABEZA, CARA Y CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1162	C	C471	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1163	C	C472	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1164	C	C473	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DEL TÓRAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1165	C	C474	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DEL ABDOMEN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1166	C	C475	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DE LA PELVIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1167	C	C476	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS DEL TRONCO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1213	C	C549	TUMOR MALIGNO DEL CUERPO DEL ÚTERO, PARTE NO ESPECIFICADA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1168	C	C478	LESIÓN DE SITIOS CONTIGUOS DE LOS NERVIOS PERIFÉRICOS Y DEL SISTEMA NERVIOSO AUTÓNOMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1169	C	C479	TUMOR MALIGNO DE LOS NERVIOS PERIFÉRICOS Y DEL SISTEMA NERVIOSO AUTÓNOMO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1170	C	C48	TUMOR MALIGNO DEL PERITONEO Y DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1171	C	C480	TUMOR MALIGNO DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1172	C	C481	TUMOR MALIGNO DE PARTE ESPECIFICADA DEL PERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1173	C	C482	TUMOR MALIGNO DEL PERITONEO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1174	C	C488	LESIÓN DE SITIOS CONTIGUOS DEL PERITONEO Y DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1175	C	C49	TUMOR MALIGNO DE OTROS TEJIDOS CONJUNTIVOS Y DE TEJIDOS BLANDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1176	C	C490	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DE LA CABEZA, CARA Y CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1177	C	C491	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1178	C	C492	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1179	C	C493	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DEL TÓRAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1180	C	C494	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DEL ABDOMEN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1181	C	C495	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DE LA PELVIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1182	C	C496	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO DEL TRONCO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1183	C	C498	LESIÓN DE SITIOS CONTIGUOS DEL TEJIDO CONJUNTIVO Y DEL TEJIDO BLANDO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1184	C	C499	TUMOR MALIGNO DEL TEJIDO CONJUNTIVO Y TEJIDO BLANDO, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	072	NO	NO	NO	SI	049N	049N	11E	11E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1185	C	C50	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	NO	NO	NO	17	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1186	C	C500	TUMOR MALIGNO DEL PEZÓN Y ARÉOLA MAMARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1187	C	C501	TUMOR MALIGNO DE LA PORCIÓN CENTRAL DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1188	C	C502	TUMOR MALIGNO DEL CUADRANTE SUPERIOR INTERNO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1189	C	C503	TUMOR MALIGNO DEL CUADRANTE INFERIOR INTERNO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1190	C	C504	TUMOR MALIGNO DEL CUADRANTE SUPERIOR EXTERNO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1191	C	C505	TUMOR MALIGNO DEL CUADRANTE INFERIOR EXTERNO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1192	C	C506	TUMOR MALIGNO DE LA PROLONGACIÓN AXILAR DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1193	C	C508	LESIÓN DE SITIOS CONTIGUOS DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1194	C	C509	TUMOR MALIGNO DE LA MAMA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	036	026	073	NO	NO	NO	SI	049M	049M	11D	11D	70	17	70	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	119	TUMOR MALIGNO DE LA MAMA	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1195	C	C51	TUMOR MALIGNO DE LA VULVA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1196	C	C510	TUMOR MALIGNO DEL LABIO MAYOR	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1197	C	C511	TUMOR MALIGNO DEL LABIO MENOR	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1198	C	C512	TUMOR MALIGNO DEL CLÍTORIS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1199	C	C518	LESIÓN DE SITIOS CONTIGUOS DE LA VULVA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1200	C	C519	TUMOR MALIGNO DE LA VULVA, PARTE NO ESPECIFICADA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1201	C	C52X	TUMOR MALIGNO DE LA VAGINA	SI	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049W	049W	12K	12K	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1202	C	C53	TUMOR MALIGNO DEL CUELLO DEL ÚTERO	NO	2	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	037	026	074	NO	NO	NO	SI	049O	049O	NO	NO	NO	18	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
1203	C	C530	TUMOR MALIGNO DEL ENDOCÉRVIX	NO	2	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	037	026	074	NO	NO	NO	SI	049O	049O	12A	12A	71	18	71	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	97	TUMOR MALIGNO DEL CUELLO DEL UTERO	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1204	C	C531	TUMOR MALIGNO DEL EXOCÉRVIX	NO	2	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	037	026	074	NO	NO	NO	SI	049O	049O	12A	12A	71	18	71	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	97	TUMOR MALIGNO DEL CUELLO DEL UTERO	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1205	C	C538	LESIÓN DE SITIOS CONTIGUOS DEL CUELLO DEL ÚTERO	NO	2	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	037	026	074	NO	NO	NO	SI	049O	049O	12A	12A	71	18	71	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	97	TUMOR MALIGNO DEL CUELLO DEL UTERO	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1206	C	C539	TUMOR MALIGNO DEL CUELLO DEL ÚTERO, SIN OTRA ESPECIFICACIÓN	NO	2	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	037	026	074	NO	NO	NO	SI	049O	049O	12A	12A	71	18	71	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	97	TUMOR MALIGNO DEL CUELLO DEL UTERO	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1207	C	C54	TUMOR MALIGNO DEL CUERPO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	NO	NO	NO	18	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1208	C	C540	TUMOR MALIGNO DEL ISTMO UTERINO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1209	C	C541	TUMOR MALIGNO DEL ENDOMETRIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1210	C	C542	TUMOR MALIGNO DEL MIOMETRIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1211	C	C543	TUMOR MALIGNO DEL FONDO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1212	C	C548	LESIÓN DE SITIOS CONTIGUOS DEL CUERPO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1214	C	C55X	TUMOR MALIGNO DEL ÚTERO, PARTE NO ESPECIFICADA	SI	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	038	026	075	NO	NO	NO	SI	049Q	049Q	12C	12C	72	18	72	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1215	C	C56X	TUMOR MALIGNO DEL OVARIO	SI	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	039	026	076	NO	NO	NO	SI	049R	049R	12D	12D	73	19	73	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1216	C	C57	TUMOR MALIGNO DE OTROS ÓRGANOS GENITALES FEMENINOS Y DE LOS NO ESPECIFICADOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1217	C	C570	TUMOR MALIGNO DE LA TROMPA DE FALOPIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1218	C	C571	TUMOR MALIGNO DEL LIGAMENTO ANCHO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1219	C	C572	TUMOR MALIGNO DEL LIGAMENTO REDONDO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1220	C	C573	TUMOR MALIGNO DEL PARAMETRIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1221	C	C574	TUMOR MALIGNO DE LOS ANEXOS UTERINOS, SIN OTRA ESPECIFICACIÓN	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1222	C	C577	TUMOR MALIGNO DE OTRAS PARTES ESPECIFICADAS DE LOS ÓRGANOS GENITALES FEMENINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1223	C	C578	LESIÓN DE SITIOS CONTIGUOS DE LOS ÓRGANOS GENITALES FEMENINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1224	C	C579	TUMOR MALIGNO DE ÓRGANO GENITAL FEMENINO, PARTE NO ESPECIFICADA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049	049	12E	12E	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1225	C	C58X	TUMOR MALIGNO DE LA PLACENTA	SI	2	010A	054A	NO	NO	NO	NO	SI	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	076	NO	NO	NO	SI	049P	049P	12B	12B	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	121	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1226	C	C60	TUMOR MALIGNO DEL PENE	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1227	C	C600	TUMOR MALIGNO DEL PREPUCIO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1228	C	C601	TUMOR MALIGNO DEL GLANDE	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1229	C	C602	TUMOR MALIGNO DEL CUERPO DEL PENE	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1230	C	C608	LESIÓN DE SITIOS CONTIGUOS DEL PENE	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1231	C	C609	TUMOR MALIGNO DEL PENE, PARTE NO ESPECIFICADA	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1232	C	C61X	TUMOR MALIGNO DE LA PRÓSTATA	SI	1	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	040	026	077	NO	NO	NO	SI	049T	049T	12F	12F	74	20	74	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1233	C	C62	TUMOR MALIGNO DEL TESTÍCULO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049U	049U	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1234	C	C620	TUMOR MALIGNO DEL TESTÍCULO NO DESCENDIDO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049U	049U	12G	12G	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1235	C	C621	TUMOR MALIGNO DEL TESTÍCULO DESCENDIDO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049U	049U	12G	12G	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1236	C	C629	TUMOR MALIGNO DEL TESTÍCULO, NO ESPECIFICADO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049U	049U	12G	12G	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1237	C	C63	TUMOR MALIGNO DE OTROS ÓRGANOS GENITALES MACULINOS Y DE LOS NO ESPECIFICADOS	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1239	C	C631	TUMOR MALIGNO DEL CORDÓN ESPERMÁTICO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1240	C	C632	TUMOR MALIGNO DEL ESCROTO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1241	C	C637	TUMOR MALIGNO DE OTRAS PARTES ESPECIFICADAS DE LOS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1242	C	C638	LESIÓN DE SITIOS CONTIGUOS DE LOS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1243	C	C639	TUMOR MALIGNO DE ÓRGANO GENITAL MASCULINO, PARTE NO ESPECIFICADA	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	078	NO	NO	NO	SI	049	049	12I	12I	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1244	C	C64X	TUMOR MALIGNO DEL RIÑÓN, EXCEPTO DE LA PELVIS RENAL	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	21	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1245	C	C65X	TUMOR MALIGNO DE LA PELVIS RENAL	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1246	C	C66X	TUMOR MALIGNO DEL URÉTER	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1247	C	C67	TUMOR MALIGNO DE LA VEJIGA URINARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	NO	NO	NO	22	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1248	C	C670	TUMOR MALIGNO DEL TRÍGONO VESICAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1249	C	C671	TUMOR MALIGNO DE LA CÚPULA VESICAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1250	C	C672	TUMOR MALIGNO DE LA PARED LATERAL DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1251	C	C673	TUMOR MALIGNO DE LA PARED ANTERIOR DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1252	C	C674	TUMOR MALIGNO DE LA PARED POSTERIOR DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1253	C	C675	TUMOR MALIGNO DEL CUELLO DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1254	C	C676	TUMOR MALIGNO DEL ORIFICIO URETERAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1255	C	C677	TUMOR MALIGNO DEL URACO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1256	C	C678	LESIÓN DE SITIOS CONTIGUOS DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1257	C	C679	TUMOR MALIGNO DE LA VEJIGA URINARIA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	041	026	079	NO	NO	NO	SI	049V	049V	12H	12H	75	22	75	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1258	C	C68	TUMOR MALIGNO DE OTROS ÓGANOS URINARIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1259	C	C680	TUMOR MALIGNO DE LA URETRA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1260	C	C681	TUMOR MALIGNO DE LAS GLÁNDULAS PARAURETRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1261	C	C688	LESIÓN DE SITIOS CONTIGUOS DE LOS ÓRGANOS URINARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1262	C	C689	TUMOR MALIGNO DE ÓRGANO URINARIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	080	NO	NO	NO	SI	049	049	12J	12J	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1263	C	C69	TUMOR MALIGNO DEL OJO Y SUS ANEXOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1264	C	C690	TUMOR MALIGNO DE LA CONJUNTIVA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1265	C	C691	TUMOR MALIGNO DE LA CÓRNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1266	C	C692	TUMOR MALIGNO DE LA RETINA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1267	C	C693	TUMOR MALIGNO DE LA COROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1268	C	C694	TUMOR MALIGNO DEL CUERPO CILIAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1269	C	C695	TUMOR MALIGNO DE LA GLÁNDULA Y CONDUCTO LAGRIMALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1270	C	C696	TUMOR MALIGNO DE LA ÓRBITA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1271	C	C698	LESIÓN DE SITIOS CONTIGUOS DEL OJO Y SUS ANEXOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1272	C	C699	TUMOR MALIGNO DEL OJO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	081	NO	NO	NO	SI	049Z	049Z	13C	13C	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1273	C	C70	TUMOR MALIGNO DE LAS MENINGES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1274	C	C700	TUMOR MALIGNO DE LAS MENINGES CEREBRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1275	C	C701	TUMOR MALIGNO DE LAS MENINGES RAQUÍDEAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1276	C	C709	TUMOR MALIGNO DE LAS MENINGES, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1277	C	C71	TUMOR MALIGNO DEL ENCÉFALO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	NO	NO	NO	23	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1278	C	C710	TUMOR MALIGNO DEL CEREBRO, EXCEPTO LÓBULOS Y VENTRÍCULOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1279	C	C711	TUMOR MALIGNO DEL LÓBULO FRONTAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1280	C	C712	TUMOR MALIGNO DEL LÓBULO TEMPORAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1281	C	C713	TUMOR MALIGNO DEL LÓBULO PARIETAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1282	C	C714	TUMOR MALIGNO DEL LÓBULO OCCIPITAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1283	C	C715	TUMOR MALIGNO DEL VENTRÍCULO CEREBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1284	C	C716	TUMOR MALIGNO DEL CEREBELO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1285	C	C717	TUMOR MALIGNO DEL PEDÚNCULO CEREBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1286	C	C718	LESIÓN DE SITIOS CONTIGUOS DEL ENCÉFALO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1287	C	C719	TUMOR MALIGNO DEL ENCÉFALO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	082	NO	NO	NO	SI	049X	049X	13A	13A	78	23	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1288	C	C72	TUMOR MALIGNO DE LA MÉDULA ESPINAL, DE LOS NERVIOS CRANEALES Y DE OTRAS PARTES DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	NO	NO	NO	88	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1289	C	C720	TUMOR MALIGNO DE LA MÉDULA ESPINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1290	C	C721	TUMOR MALIGNO DE LA COLA DE CABALLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1291	C	C722	TUMOR MALIGNO DEL NERVIO OLFATORIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1292	C	C723	TUMOR MALIGNO DEL NERVIO ÓPTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1293	C	C724	TUMOR MALIGNO DEL NERVIO ACÚSTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1294	C	C725	TUMOR MALIGNO DE OTROS NERVIOS CRANEALES Y LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1295	C	C728	LESIÓN DE SITIOS CONTIGUOS DEL ENCÉFALO Y OTRAS PARTES DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1296	C	C729	TUMOR MALIGNO DEL SISTEMA NERVIOSO CENTRAL, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	042	026	083	NO	NO	NO	SI	049Y	049Y	13B	13B	78	88	78	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1297	C	C73X	TUMOR MALIGNO DE LA GLÁNDULA TIROIDES	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1298	C	C74	TUMOR MALIGNO DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1299	C	C740	TUMOR MALIGNO DE LA CORTEZA DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1300	C	C741	TUMOR MALIGNO DE LA MÉDULA DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1301	C	C749	TUMOR MALIGNO DE LA GLÁNDULA SUPRARRENAL, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1302	C	C75	TUMOR MALIGNO DE OTRAS GLÁNDULAS ENDOCRINAS Y DE ESTRUCTURAS AFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1303	C	C750	TUMOR MALIGNO DE LA GLÁNDULA PARATIROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1304	C	C751	TUMOR MALIGNO DE LA HIPÓFISIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1305	C	C752	TUMOR MALIGNO DEL CONDUCTO CRANEOFARÍNGEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1306	C	C753	TUMOR MALIGNO DE LA GLÁNDULA PINEAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1307	C	C754	TUMOR MALIGNO DEL CUERPO CAROTÍDEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1308	C	C755	TUMOR MALIGNO DEL CUERPO AÓRTICO Y OTROS CUERPOS CROMAFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1309	C	C758	TUMOR MALIGNO PLURIGLANDULAR, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1310	C	C759	TUMOR MALIGNO DE GLÁNDULA ENDOCRINA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1311	C	C76	TUMOR MALIGNO DE OTROS SITIOS Y DE LOS SITIOS MAL DEFINIDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1312	C	C760	TUMOR MALIGNO DE LA CABEZA, CARA Y CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1313	C	C761	TUMOR MALIGNO DEL TÓRAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1314	C	C762	TUMOR MALIGNO DEL ABDOMEN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1315	C	C763	TUMOR MALIGNO DE LA PELVIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1316	C	C764	TUMOR MALIGNO DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1317	C	C765	TUMOR MALIGNO DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1318	C	C767	TUMOR MALIGNO DE OTROS SITIOS MAL DEFINIDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1319	C	C768	LESIÓN DE SITIOS CONTIGUOS MAL DEFINIDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1320	C	C77	TUMOR MALIGNO SECUNDARIO Y EL NO ESPECIFICADO DE LOS GANGLIOS LINFÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1321	C	C770	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS DE LA CABEZA, CARA Y CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1322	C	C771	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS INTRATORÁCICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1323	C	C772	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS INTRAABDOMINALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1324	C	C773	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS DE LA AXILA Y DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1325	C	C774	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS DE LA REGIÓN INGUINAL Y DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1326	C	C775	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS DE LA PELVIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1327	C	C778	TUMOR MALIGNO DE LOS GANGLIOS LINFÁTICOS DE REGIONES MÚLTIPLES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1328	C	C779	TUMOR MALIGNO DEL GANGLIO LINFÁTICO, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1329	C	C78	TUMOR MALIGNO SECUNDARIO DE LOS ÓRGANOS RESPIRATORIOS Y DIGESTIVOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1330	C	C780	TUMOR MALIGNO SECUNDARIO DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1331	C	C781	TUMOR MALIGNO SECUNDARIO DEL MEDIASTINO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1332	C	C782	TUMOR MALIGNO SECUNDARIO DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1360	C	C817	OTROS LINFOMAS DE HODGKIN CLÁSICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1333	C	C783	TUMOR MALIGNO SECUNDARIO DE OTROS ÓRGANOS RESPIRATORIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1334	C	C784	TUMOR MALIGNO SECUNDARIO DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1335	C	C785	TUMOR MALIGNO SECUNDARIO DEL INTESTINO GRUESO Y DEL RECTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1336	C	C786	TUMOR MALIGNO SECUNDARIO DEL PERITONEO Y DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1337	C	C787	TUMOR MALIGNO SECUNDARIO DEL HÍGADO Y DE LOS CONDUCTOS BILIARES INTRAHEPÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	C	2009 CORRECCION TITULOS	2014	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1338	C	C788	TUMOR MALIGNO SECUNDARIO DE OTROS ÓRGANOS DIGESTIVOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1339	C	C79	TUMOR MALIGNO SECUNDARIO DE OTROS SITIOS Y DE SITIOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	C	2010 CORRECCION TITULOS	2014	SI	049	049	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1340	C	C790	TUMOR MALIGNO SECUNDARIO DEL RIÑÓN Y DE LA PELVIS RENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1341	C	C791	TUMOR MALIGNO SECUNDARIO DE LA VEJIGA, Y DE OTROS ÓRGANOS Y LOS NO ESPECIFICADOS DE LAS VÍAS URINARIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1342	C	C792	TUMOR MALIGNO SECUNDARIO DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1343	C	C793	TUMOR MALIGNO SECUNDARIO DEL ENCÉFALO Y DE LAS MENINGES CEREBRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1344	C	C794	TUMOR MALIGNO SECUNDARIO DE OTRAS PARTES DEL SISTEMA NERVIOSO Y DE LAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1345	C	C795	TUMOR MALIGNO SECUNDARIO DE LOS HUESOS Y DE LA MÉDULA ÓSEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1346	C	C796	TUMOR MALIGNO SECUNDARIO DEL OVARIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1347	C	C797	TUMOR MALIGNO SECUNDARIO DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1348	C	C798	TUMOR MALIGNO SECUNDARIO DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1349	C	C799	TUMOR MALIGNO SECUNDARIO, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	A	2010 NUEVA CATEGORIA	2014	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1350	C	C80	TUMOR MALIGNO DE SITIOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	A	2010 CAMBIO X POR CATEGORIAS	2014	SI	049	049	13Z	13Z	NO	88	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1351	C	C800	TUMOR MALIGNO, DE SITIO PRIMARIO DESCONOCIDO, ASÍ DESCRITO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	A	2010 NUEVA CATEGORIA	2014	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1352	C	C809	TUMOR MALIGNO, SITIO PRIMARIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	A	2010 NUEVA CATEGORIA/2011 CORRECCION TITULOS	2014	SI	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1353	C	C80X	TUMOR MALIGNO DE SITIOS NO ESPECIFICADOS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	084	B	2010 CAMBIO X POR CATEGORIAS	2014	NO	049	049	13Z	13Z	78	88	78	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1354	C	C81	LINFOMA DE HODGKIN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1355	C	C810	LINFOMA DE HODGKIN CON PREDOMINIO LINFOCÍTICO NODULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1356	C	C811	LINFOMA DE HODGKIN CLÁSICO CON ESCLEROSIS NODULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1357	C	C812	LINFOMA DE HODGKIN CLÁSICO CON CELULARIDAD MIXTA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1358	C	C813	LINFOMA DE HODGKIN CLÁSICO CON DEPLECIÓN LINFOCÍTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1361	C	C819	LINFOMA DE HODGKIN, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	085	C	2010 CORRECCION TITULOS	2014	SI	0491	0491	14A	14A	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1362	C	C82	LINFOMA FOLICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1363	C	C820	LINFOMA FOLICULAR GRADO I	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1364	C	C821	LINFOMA FOLICULAR GRADO II	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1365	C	C822	LINFOMA FOLICULAR GRADO III NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1366	C	C823	LINFOMA FOLICULAR GRADO IIIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1367	C	C824	LINFOMA FOLICULAR GRADO IIIB	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1368	C	C825	LINFOMA CENTRO FOLICULAR DIFUSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1369	C	C826	LINFOMA CENTRO FOLICULAR CUTÁNEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1370	C	C827	OTROS TIPOS ESPECIFICADOS DE LINFOMA FOLICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1371	C	C829	LINFOMA FOLICULAR, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1372	C	C83	LINFOMA NO FOLICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1373	C	C830	LINFOMA DE CÉLULAS B PEQUEÑAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1374	C	C831	LINFOMA DE CÉLULAS DEL MANTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1375	C	C832	LINFOMA NO HODGKIN MIXTO, DE CÉLULAS PEQUEÑAS Y GRANDES (DIFUSO)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1376	C	C833	LINFOMA DE CÉLULAS GRANDES B DIFUSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1377	C	C834	LINFOMA NO HODGKIN INMUNOBLÁSTICO (DIFUSO)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1378	C	C835	LINFOMA LINFOBLÁSTICO (DIFUSO)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1380	C	C837	LINFOMA DE BURKITT	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1381	C	C838	OTROS TIPOS ESPECIFICADOS DE LINFOMA NO FOLICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1382	C	C839	LINFOMA NO FOLICULAR (DIFUSO), SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1383	C	C84	LINFOMA DE CÉLULAS T/NK MADURAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1385	C	C841	ENFERMEDAD DE SÉZARY	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	NO	NO	NO	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1386	C	C842	LINFOMA DE ZONA T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1387	C	C843	LINFOMA LINFOEPITELIOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1388	C	C844	LINFOMA PERIFÉRICO DE CÉLULAS T, NO CLASIFICADO EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1389	C	C845	OTROS LINFOMAS DE CÉLULAS T/NK MADURAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1390	C	C846	LINFOMA ANAPLÁSICO DE CÉLULAS GRANDES ALK-POSITIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1391	C	C847	LINFOMA ANAPLÁSICO DE CÉLULAS GRANDES ALK-NEGATIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1392	C	C848	LINFOMA CUTÁNEO DE CÉLULAS T, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1393	C	C849	LINFOMA DE CÉLULAS T/NK MADURAS, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1394	C	C85	LINFOMA NO HODGKIN DE OTRO TIPO Y EL NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	043	026	086	NO	NO	NO	SI	0492	0492	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1395	C	C850	LINFOSARCOMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1396	C	C851	LINFOMA DE CÉLULAS B, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	NO	NO	NO	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1397	C	C852	LINFOMA MEDIASTINAL DE CÉLULAS B GRANDES (DEL TIMO)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1398	C	C857	OTROS TIPOS ESPECIFICADOS DE LINFOMA NO HODGKIN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	NO	NO	NO	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1399	C	C859	LINFOMA NO HODGKIN, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	C	2010 CORRECCION TITULOS	2014	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1400	C	C86	OTROS TIPOS ESPECIFICADOS DE LINFOMA DE CÉLULAS T/NK	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	NO	24	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1401	C	C860	LINFOMA EXTRANODAL DE CÉLULAS T/NK, TIPO NASAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1402	C	C861	LINFOMA HEPATOESPLÉNICO DE CÉLULAS T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1379	C	C836	LINFOMA NO HODGKIN INDIFERENCIADO (DIFUSO)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	B	2010 ELIMINAR CATEGORIA	2014	NO	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1384	C	C840	MICOSIS FUNGOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	NO	NO	NO	SI	0492	0492	14B	14B	76	24	76	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1403	C	C862	LINFOMA DE CÉLULAS T TIPO ENTEROPATÍA (INTESTINAL)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1404	C	C863	LINFOMA DE CÉLULAS T TIPO PANICULITIS SUBCUTÁNEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1405	C	C864	LINFOMA BLÁSTICO DE CÉLULAS NK	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1406	C	C865	LINFOMA ANGIOINMUNOBLÁSTICO DE CÉLULAS T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1407	C	C866	TRASTORNOS LINFOPROLIFERATIVOS PRIMARIO CUTÁNEOS DE CÉLULAS T CD30-POSITIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	043	026	086	A	2010 NUEVA CATEGORIA	2014	SI	0492	0492	14B	14B	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1408	C	C88	ENFERMEDADES INMUNOPROLIFERATIVAS MALIGNAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	088	C	2010 CORRECCION TITULOS	2014	SI	049	049	NO	NO	NO	24	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1409	C	C880	MACROGLOBULINEMIA DE WALDENSTRÖM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1410	C	C881	ENFERMEDAD DE CADENA PESADA ALFA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	B	2010 ELIMINAR CATEGORIA	2014	NO	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1411	C	C882	OTRAS ENFERMEDADES DE CADENA PESADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	C	2010 CORRECCION TITULOS	2014	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1412	C	C883	ENFERMEDAD INMUNOPROLIFERATIVA DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1413	C	C884	LINFOMA DE CÉLULAS B EXTRANODAL DE ZONA MARGINAL DE TEJIDO LINFOIDE ASOCIADO A MUCOSAS [LINFOMA TLAM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	A	2010 NUEVA CATEGORIA	2014	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1414	C	C887	OTRAS ENFERMEDADES INMUNOPROLIFERATIVAS MALIGNAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1415	C	C889	ENFERMEDAD INMUNOPROLIFERATIVA MALIGNA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1416	C	C90	MIELOMA MÚLTIPLE Y TUMORES MALIGNOS DE CÉLULAS PLASMÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	044	026	088	NO	NO	NO	SI	0493	0493	NO	NO	NO	24	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1418	C	C901	LEUCEMIA DE CÉLULAS PLASMÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	044	026	088	NO	NO	NO	SI	0493	0493	14C	14C	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1419	C	C902	PLASMOCITOMA EXTRAMEDULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	044	026	088	C	2010 CORRECCION TITULOS	2014	SI	0493	0493	14C	14C	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1420	C	C903	PLASMOCITOMA SOLITARIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	044	026	088	A	2010 NUEVA CATEGORIA	2014	SI	0493	0493	14C	14C	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1421	C	C91	LEUCEMIA LINFOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1422	C	C910	LEUCEMIA LINFOBLÁSTICA AGUDA [LLA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1417	C	C900	MIELOMA MÚLTIPLE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	044	026	088	NO	NO	NO	SI	0493	0493	14C	14C	76	24	76	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1423	C	C911	LEUCEMIA LINFOCÍTICA CRÓNICA DE CÉLULA TIPO B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1424	C	C912	LEUCEMIA LINFOCÍTICA SUBAGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	B	2010 ELIMINAR CATEGORIA	2014	NO	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1425	C	C913	LEUCEMIA PROLINFOCÍTICA DE CÉLULA TIPO B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1426	C	C914	LEUCEMIA DE CÉLULAS VELLOSAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1427	C	C915	LEUCEMIA/LINFOMA DE CÉLULAS T ADULTAS [HTLV-1-ASOCIADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1428	C	C916	LEUCEMIA PROLINFOCÍTICA DE CÉLULAS TIPO T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1429	C	C917	OTRAS LEUCEMIAS LINFOIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1430	C	C918	LEUCEMIA TIPO BURKITT DE CÉLULAS B MADURAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1431	C	C919	LEUCEMIA LINFOIDE, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1432	C	C92	LEUCEMIA MIELOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1433	C	C920	LEUCEMIA MIELOBLÁSTICA AGUDA [LMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1434	C	C921	LEUCEMIA MIELOIDE CRÓNICA [LMC, BCR/ABL-POSITIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1435	C	C922	LEUCEMIA MIELOIDE CRÓNICA ATÍPICA, BCR/ABL-NEGATIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1436	C	C923	SARCOMA MIELOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1437	C	C924	LEUCEMIA PROMIELOCÍTICA AGUDA [LPA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1438	C	C925	LEUCEMIA MIELOMONOCÍTICA AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1439	C	C926	LEUCEMIA MIELOIDE AGUDA CON ANORMALIDAD 11Q23	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1441	C	C928	LEUCEMIA MIELOIDE AGUDA CON DISPLASIA MULTILINAJE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1442	C	C929	LEUCEMIA MIELOIDE, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1443	C	C93	LEUCEMIA MONOCÍTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1444	C	C930	LEUCEMIA MONOCÍTICA/MONOBLÁSTICA AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1440	C	C927	OTRAS LEUCEMIAS MIELOIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1445	C	C931	LEUCEMIA MIELOMONOCÍTICA CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1446	C	C932	LEUCEMIA MONOCÍTICA SUBAGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	B	2010 ELIMINAR CATEGORIA	2014	NO	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1447	C	C933	LEUCEMIA MIELOMONOCÍTICA JUVENIL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1448	C	C937	OTRAS LEUCEMIAS MONOCÍTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1449	C	C939	LEUCEMIA MONOCÍTICA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1450	C	C94	OTRAS LEUCEMIAS DE TIPO CELULAR ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1451	C	C940	LEUCEMIA ERITROIDE AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1452	C	C941	ERITREMIA CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	B	2010 ELIMINAR CATEGORIA	2014	NO	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1453	C	C942	LEUCEMIA MEGACARIOBLÁSTICA AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1454	C	C943	LEUCEMIA DE MASTOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1455	C	C944	PANMIELOSIS AGUDA CON MIELOFIBROSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	C	2010 CORRECCION TITULOS	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1456	C	C945	MIELOFIBROSIS AGUDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	B	2010 ELIMINAR CATEGORIA	2014	NO	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1457	C	C946	ENFERMEDAD MIELODISPLÁSICA Y MIELOPROLIFERATIVA, NO CLASIFICADA EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	A	2010 NUEVA CATEGORIA	2014	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1458	C	C947	OTRAS LEUCEMIAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1459	C	C95	LEUCEMIA DE CÉLULAS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	NO	NO	NO	24	NO	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1460	C	C950	LEUCEMIA AGUDA, CÉLULAS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1461	C	C951	LEUCEMIA CRÓNICA, CÉLULAS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1462	C	C952	LEUCEMIA SUBAGUDA, CÉLULAS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	B	2010 ELIMINAR CATEGORIA	2014	NO	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1463	C	C957	OTRAS LEUCEMIAS DE CÉLULAS DE TIPO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1464	C	C959	LEUCEMIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	045	026	087	NO	NO	NO	SI	0494	0494	14D	14D	77	24	77	NO	SI	SI	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1465	C	C96	OTROS TUMORES MALIGNOS Y LOS NO ESPECIFICADOS DEL TEJIDO LINFÁTICO, DE LOS ÓRGANOS HEMATOPOYÉTICOS Y DE TEJIDOS AFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	NO	NO	NO	24	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1466	C	C960	HISTIOCITOSIS DE CÉLULAS DE LANGERHANS MULTIFOCAL Y MULTISISTÉMICA (DISEMINADA) [ENFERMEDAD DE LETTERER-SIWE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	C	2010 CORRECCION TITULOS	2014	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1467	C	C961	HISTIOCITOSIS MALIGNA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	B	2010 ELIMINAR CATEGORIA	2014	NO	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1468	C	C962	TUMOR MALIGNO DE MASTOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1469	C	C963	LINFOMA HISTIOCÍTICO VERDADERO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	B	2010 ELIMINAR CATEGORIA	2014	NO	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1470	C	C964	SARCOMA DE CÉLULAS DENDRÍTICAS (CÉLULAS ACCESORIAS)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	A	2010 NUEVA CATEGORIA	2014	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1471	C	C965	HISTIOCITOSIS DE CÉLULAS DE LANGERHANS MULTIFOCAL Y UNISISTÉMICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	A	2010 NUEVA CATEGORIA	2014	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1472	C	C966	HISTIOCITOSIS DE CÉLULAS DE LANGERHANS UNIFOCAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	A	2010 NUEVA CATEGORIA	2014	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1473	C	C967	OTROS TUMORES MALIGNOS ESPECIFICADOS DEL TEJIDO LINFÁTICO, HEMATOPOYÉTICO Y TEJIDOS AFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1474	C	C968	SARCOMA HISTIOCÍTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	A	2010 NUEVA CATEGORIA	2014	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1475	C	C969	TUMOR MALIGNO DEL TEJIDO LINFÁTICO, HEMATOPOYÉTICO Y TEJIDOS AFINES, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	046	026	088	NO	NO	NO	SI	049	049	14Z	14Z	78	24	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1476	C	C97X	TUMORES MALIGNOS (PRIMARIOS) DE SITIOS MÚLTIPLES INDEPENDIENTES	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	046	026	084	NO	NO	NO	SI	049	049	15	15	78	88	78	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1477	D	D00	CARCINOMA IN SITU DE LA CAVIDAD BUCAL, DEL ESÓFAGO Y DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1478	D	D000	CARCINOMA IN SITU DEL LABIO, DE LA CAVIDAD BUCAL Y DE LA FARINGE	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1479	D	D001	CARCINOMA IN SITU DEL ESÓFAGO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1480	D	D002	CARCINOMA IN SITU DEL ESTÓMAGO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1481	D	D01	CARCINOMA IN SITU DE OTROS ÓRGANOS DIGESTIVOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1482	D	D010	CARCINOMA IN SITU DEL COLON	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1483	D	D011	CARCINOMA IN SITU DE LA UNIÓN RECTOSIGMOIDEA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1484	D	D012	CARCINOMA IN SITU DEL RECTO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1485	D	D013	CARCINOMA IN SITU DEL ANO Y DEL CONDUCTO ANAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1486	D	D014	CARCINOMA IN SITU DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DEL INTESTINO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1487	D	D015	CARCINOMA IN SITU DEL HÍGADO, DE LA VESÍCULA BILIAR Y DEL CONDUCTO BILIAR	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1488	D	D017	CARCINOMA IN SITU DE OTRAS PARTES ESPECIFICADAS DE ÓRGANOS DIGESTIVOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1489	D	D019	CARCINOMA IN SITU DE ÓRGANOS DIGESTIVOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1490	D	D02	CARCINOMA IN SITU DEL SISTEMA RESPIRATORIO Y DEL OÍDO MEDIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1491	D	D020	CARCINOMA IN SITU DE LA LARINGE	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1492	D	D021	CARCINOMA IN SITU DE LA TRÁQUEA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1493	D	D022	CARCINOMA IN SITU DEL BRONQUIO Y DEL PULMÓN	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1494	D	D023	CARCINOMA IN SITU DE OTRAS PARTES DEL SISTEMA RESPIRATORIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1495	D	D024	CARCINOMA IN SITU DE ÓRGANOS RESPIRATORIOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1496	D	D03	MELANOMA IN SITU	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1497	D	D030	MELANOMA IN SITU DEL LABIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1498	D	D031	MELANOMA IN SITU DEL PÁRPADO Y DE LA COMISURA PALPEBRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1499	D	D032	MELANOMA IN SITU DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1500	D	D033	MELANOMA IN SITU DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1501	D	D034	MELANOMA IN SITU DEL CUERO CABELLUDO Y DEL CUELLO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1502	D	D035	MELANOMA IN SITU DEL TRONCO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1503	D	D036	MELANOMA IN SITU DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1504	D	D037	MELANOMA IN SITU DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1505	D	D038	MELANOMA IN SITU DE OTROS SITIOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1506	D	D039	MELANOMA IN SITU, SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1507	D	D04	CARCINOMA IN SITU DE LA PIEL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1508	D	D040	CARCINOMA IN SITU DE LA PIEL DEL LABIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1509	D	D041	CARCINOMA IN SITU DE LA PIEL DEL PÁRPADO Y DE LA COMISURA PALPEBRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1510	D	D042	CARCINOMA IN SITU DE LA PIEL DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1511	D	D043	CARCINOMA IN SITU DE LA PIEL DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1512	D	D044	CARCINOMA IN SITU DE LA PIEL DEL CUERO CABELLUDO Y CUELLO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1513	D	D045	CARCINOMA IN SITU DE LA PIEL DEL TRONCO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1514	D	D046	CARCINOMA IN SITU DE LA PIEL DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1515	D	D047	CARCINOMA IN SITU DE LA PIEL DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1516	D	D048	CARCINOMA IN SITU DE LA PIEL DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1517	D	D049	CARCINOMA IN SITU DE LA PIEL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1518	D	D05	CARCINOMA IN SITU DE LA MAMA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1519	D	D050	CARCINOMA IN SITU LOBULAR	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1520	D	D051	CARCINOMA IN SITU INTRACANALICULAR	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1521	D	D057	OTROS CARCINOMAS IN SITU DE LA MAMA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1522	D	D059	CARCINOMA IN SITU DE LA MAMA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1523	D	D06	CARCINOMA IN SITU DEL CUELLO DEL ÚTERO	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	089	NO	NO	NO	SI	050	050	NO	NO	NO	25	NO	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	NO	NO	NO	SI	NO	NO	000	NO	NO	NO	NO	NO	NO
1524	D	D060	CARCINOMA IN SITU DEL ENDOCÉRVIX	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	089	NO	NO	NO	SI	050	050	16A	16A	79	25	79	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	118	DISPLASIA CERVICAL SEVERA Y CACU IN SITU	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1525	D	D061	CARCINOMA IN SITU DEL EXOCÉRVIX	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	089	NO	NO	NO	SI	050	050	16A	16A	79	25	79	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	118	DISPLASIA CERVICAL SEVERA Y CACU IN SITU	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1526	D	D067	CARCINOMA IN SITU DE OTRAS PARTES ESPECIFICADAS DEL CUELLO DEL ÚTERO	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	089	NO	NO	NO	SI	050	050	16A	16A	79	25	79	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	118	DISPLASIA CERVICAL SEVERA Y CACU IN SITU	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1527	D	D069	CARCINOMA IN SITU DEL CUELLO DEL ÚTERO, PARTE NO ESPECIFICADA	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	089	NO	NO	NO	SI	050	050	16A	16A	79	25	79	NO	SI	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	SI	0	NO	NO	NO	SI	118	DISPLASIA CERVICAL SEVERA Y CACU IN SITU	NO	SI	NO	NO	999	NO	NO	NO	NO	NO	NO
1528	D	D07	CARCINOMA IN SITU DE OTROS ÓRGANOS GENITALES Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1529	D	D070	CARCINOMA IN SITU DEL ENDOMETRIO	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1530	D	D071	CARCINOMA IN SITU DE LA VULVA	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1531	D	D072	CARCINOMA IN SITU DE LA VAGINA	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1532	D	D073	CARCINOMA IN SITU DE OTROS SITIOS DE ÓRGANOS GENITALES FEMENINOS Y DE LOS NO ESPECIFICADOS	NO	2	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1533	D	D074	CARCINOMA IN SITU DEL PENE	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1534	D	D075	CARCINOMA IN SITU DE LA PRÓSTATA	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1535	D	D076	CARCINOMA IN SITU DE OTROS ÓRGANOS GENITALES MASCULINOS Y DE LOS NO ESPECIFICADOS	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1536	D	D09	CARCINOMA IN SITU DE OTROS SITIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1537	D	D090	CARCINOMA IN SITU DE LA VEJIGA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1538	D	D091	CARCINOMA IN SITU DE OTROS ÓRGANOS URINARIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1539	D	D092	CARCINOMA IN SITU DEL OJO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1540	D	D093	CARCINOMA IN SITU DE LA GLÁNDULA TIROIDES Y DE OTRAS GLÁNDULAS ENDOCRINAS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1541	D	D097	CARCINOMA IN SITU DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1542	D	D099	CARCINOMA IN SITU, SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	16Z	16Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1543	D	D10	TUMOR BENIGNO DE LA BOCA Y DE LA FARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1544	D	D100	TUMOR BENIGNO DEL LABIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1545	D	D101	TUMOR BENIGNO DE LA LENGUA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1546	D	D102	TUMOR BENIGNO DEL PISO DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1547	D	D103	TUMOR BENIGNO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA BOCA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1548	D	D104	TUMOR BENIGNO DE LA AMÍGDALA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1549	D	D105	TUMOR BENIGNO DE OTRAS PARTES DE LA OROFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	254	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1550	D	D106	TUMOR BENIGNO DE LA NASOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	254	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1551	D	D107	TUMOR BENIGNO DE LA HIPOFARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	254	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1552	D	D109	TUMOR BENIGNO DE LA FARINGE, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	254	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1553	D	D11	TUMOR BENIGNO DE LAS GLÁNDULAS SALIVALES MAYORES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1554	D	D110	TUMOR BENIGNO DE LA GLÁNDULA PARÓTIDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1555	D	D117	TUMOR BENIGNO DE OTRAS GLÁNDULAS SALIVALES MAYORES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1556	D	D119	TUMOR BENIGNO DE LA GLÁNDULA SALIVAL MAYOR, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1557	D	D12	TUMOR BENIGNO DEL COLON, DEL RECTO, DEL CONDUCTO ANAL Y DEL ANO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1558	D	D120	TUMOR BENIGNO DEL CIEGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1559	D	D121	TUMOR BENIGNO DEL APÉNDICE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1560	D	D122	TUMOR BENIGNO DEL COLON ASCENDENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1561	D	D123	TUMOR BENIGNO DEL COLON TRANSVERSO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1562	D	D124	TUMOR BENIGNO DEL COLON DESCENDENTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1563	D	D125	TUMOR BENIGNO DEL COLON SIGMOIDE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1564	D	D126	TUMOR BENIGNO DEL COLON, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1565	D	D127	TUMOR BENIGNO DE LA UNIÓN RECTOSIGMOIDEA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1566	D	D128	TUMOR BENIGNO DEL RECTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1567	D	D129	TUMOR BENIGNO DEL CONDUCTO ANAL Y DEL ANO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1568	D	D13	TUMOR BENIGNO DE OTRAS PARTES Y DE LAS MAL DEFINIDAS DEL SISTEMA DIGESTIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1569	D	D130	TUMOR BENIGNO DEL ESÓFAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1570	D	D131	TUMOR BENIGNO DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1571	D	D132	TUMOR BENIGNO DEL DUODENO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1572	D	D133	TUMOR BENIGNO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1573	D	D134	TUMOR BENIGNO DEL HÍGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1574	D	D135	TUMOR BENIGNO DE LAS VÍAS BILIARES EXTRAHEPÁTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1575	D	D136	TUMOR BENIGNO DEL PÁNCREAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1576	D	D137	TUMOR BENIGNO DEL PÁNCREAS ENDOCRINO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1577	D	D139	TUMOR BENIGNO DE SITIOS MAL DEFINIDOS DEL SISTEMA DIGESTIVO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1578	D	D14	TUMOR BENIGNO DEL OÍDO MEDIO Y DEL SISTEMA RESPIRATORIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1579	D	D140	TUMOR BENIGNO DEL OÍDO MEDIO, DE LA CAVIDAD NASAL Y DE LOS SENOS PARANASALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1580	D	D141	TUMOR BENIGNO DE LA LARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	254	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1582	D	D143	TUMOR BENIGNO DE LOS BRONQUIOS Y DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1583	D	D144	TUMOR BENIGNO DEL SISTEMA RESPIRATORIO, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1584	D	D15	TUMOR BENIGNO DE OTROS ÓRGANOS INTRATORÁCICOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1585	D	D150	TUMOR BENIGNO DEL TIMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1586	D	D151	TUMOR BENIGNO DEL CORAZÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1587	D	D152	TUMOR BENIGNO DEL MEDIASTINO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1588	D	D157	TUMOR BENIGNO DE OTROS ÓRGANOS INTRATORÁCICOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1589	D	D159	TUMOR BENIGNO DE ÓRGANO INTRATORÁCICO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1590	D	D16	TUMOR BENIGNO DEL HUESO Y DEL CARTÍLAGO ARTICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1591	D	D160	TUMOR BENIGNO DEL OMÓPLATO Y HUESOS LARGOS DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1592	D	D161	TUMOR BENIGNO DE LOS HUESOS CORTOS DEL MIEMBRO SUPERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1593	D	D162	TUMOR BENIGNO DE LOS HUESOS LARGOS DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1594	D	D163	TUMOR BENIGNO DE LOS HUESOS CORTOS DEL MIEMBRO INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1595	D	D164	TUMOR BENIGNO DE LOS HUESOS DEL CRÁNEO Y DE LA CARA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1596	D	D165	TUMOR BENIGNO DEL MAXILAR INFERIOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1597	D	D166	TUMOR BENIGNO DE LA COLUMNA VERTEBRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1598	D	D167	TUMOR BENIGNO DE LAS COSTILLAS, ESTERNÓN Y CLAVÍCULA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1599	D	D168	TUMOR BENIGNO DE LOS HUESOS PÉLVICOS, SACRO Y CÓCCIX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1600	D	D169	TUMOR BENIGNO DEL HUESO Y DEL CARTÍLAGO ARTICULAR, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1601	D	D17	TUMORES BENIGNOS LIPOMATOSOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1602	D	D170	TUMOR BENIGNO LIPOMATOSO DE PIEL Y DE TEJIDO SUBCUTÁNEO DE CABEZA, CARA Y CUELLO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1603	D	D171	TUMOR BENIGNO LIPOMATOSO DE PIEL Y DE TEJIDO SUBCUTÁNEO DEL TRONCO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1604	D	D172	TUMOR BENIGNO LIPOMATOSO DE PIEL Y DE TEJIDO SUBCUTÁNEO DE MIEMBROS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1605	D	D173	TUMOR BENIGNO LIPOMATOSO DE PIEL Y DE TEJIDO SUBCUTÁNEO DE OTROS SITIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1606	D	D174	TUMOR BENIGNO LIPOMATOSO DE LOS ÓRGANOS INTRATORÁCICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1607	D	D175	TUMOR BENIGNO LIPOMATOSO DE LOS ÓRGANOS INTRAABDOMINALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1608	D	D176	TUMOR BENIGNO LIPOMATOSO DEL CORDÓN ESPERMÁTICO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1609	D	D177	TUMOR BENIGNO LIPOMATOSO DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1610	D	D179	TUMOR BENIGNO LIPOMATOSO, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1611	D	D18	HEMANGIOMA Y LINFANGIOMA DE CUALQUIER SITIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1612	D	D180	HEMANGIOMA, DE CUALQUIER SITIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1613	D	D181	LINFANGIOMA, DE CUALQUIER SITIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1614	D	D19	TUMORES BENIGNOS DEL TEJIDO MESOTELIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1615	D	D190	TUMOR BENIGNO DEL TEJIDO MESOTELIAL DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1616	D	D191	TUMOR BENIGNO DEL TEJIDO MESOTELIAL DEL PERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1617	D	D197	TUMOR BENIGNO DEL TEJIDO MESOTELIAL DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1618	D	D199	TUMOR BENIGNO DEL TEJIDO MESOTELIAL, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1619	D	D20	TUMOR BENIGNO DEL TEJIDO BLANDO DEL PERITONEO Y DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1620	D	D200	TUMOR BENIGNO DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1621	D	D201	TUMOR BENIGNO DEL PERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1622	D	D21	OTROS TUMORES BENIGNOS DEL TEJIDO CONJUNTIVO Y DE LOS TEJIDOS BLANDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1623	D	D210	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y DE OTROS TEJIDOS BLANDOS DE CABEZA, CARA Y CUELLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1624	D	D211	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y DE OTROS TEJIDOS BLANDOS DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1625	D	D212	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y DE OTROS TEJIDOS BLANDOS DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1626	D	D213	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y DE OTROS TEJIDOS BLANDOS DEL TÓRAX	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1627	D	D214	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y OTROS TEJIDOS BLANDOS DEL ABDOMEN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1628	D	D215	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y OTROS TEJIDOS BLANDOS DE LA PELVIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1629	D	D216	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y OTROS TEJIDOS BLANDOS DEL TRONCO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1630	D	D219	TUMOR BENIGNO DEL TEJIDO CONJUNTIVO Y OTROS TEJIDOS BLANDOS, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1631	D	D22	NEVO MELANOCÍTICO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1632	D	D220	NEVO MELANOCÍTICO DEL LABIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1633	D	D221	NEVO MELANOCÍTICO DEL PÁRPADO, INCLUIDA LA COMISURA PALPEBRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1634	D	D222	NEVO MELANOCÍTICO DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1635	D	D223	NEVO MELANOCÍTICO DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1636	D	D224	NEVO MELANOCÍTICO DEL CUERO CABELLUDO Y DEL CUELLO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1637	D	D225	NEVO MELANOCÍTICO DEL TRONCO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1638	D	D226	NEVO MELANOCÍTICO DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1639	D	D227	NEVO MELANOCÍTICO DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1640	D	D229	NEVO MELANOCÍTICO, SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1641	D	D23	OTROS TUMORES BENIGNOS DE LA PIEL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1642	D	D230	TUMOR BENIGNO DE LA PIEL DEL LABIO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1643	D	D231	TUMOR BENIGNO DE LA PIEL DEL PÁRPADO, INCLUIDA LA COMISURA PALPEBRAL	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1644	D	D232	TUMOR BENIGNO DE LA PIEL DE LA OREJA Y DEL CONDUCTO AUDITIVO EXTERNO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1645	D	D233	TUMOR BENIGNO DE LA PIEL DE OTRAS PARTES Y DE LAS NO ESPECIFICADAS DE LA CARA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1646	D	D234	TUMOR BENIGNO DE LA PIEL DEL CUERO CABELLUDO Y DEL CUELLO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1647	D	D235	TUMOR BENIGNO DE LA PIEL DEL TRONCO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1648	D	D236	TUMOR BENIGNO DE LA PIEL DEL MIEMBRO SUPERIOR, INCLUIDO EL HOMBRO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1649	D	D237	TUMOR BENIGNO DE LA PIEL DEL MIEMBRO INFERIOR, INCLUIDA LA CADERA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1650	D	D239	TUMOR BENIGNO DE LA PIEL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	090	NO	NO	NO	SI	051	051	17A	17A	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	252	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1651	D	D24X	TUMOR BENIGNO DE LA MAMA	SI	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	091	NO	NO	NO	SI	052	052	17B	17B	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	SI	126	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1652	D	D25	LEIOMIOMA DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	092	NO	NO	NO	SI	053	053	NO	NO	NO	25	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	245	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1653	D	D250	LEIOMIOMA SUBMUCOSO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	092	NO	NO	NO	SI	053	053	17C	17C	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	245	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1654	D	D251	LEIOMIOMA INTRAMURAL DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	092	NO	NO	NO	SI	053	053	17C	17C	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	245	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1655	D	D252	LEIOMIOMA SUBSEROSO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	092	NO	NO	NO	SI	053	053	17C	17C	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	245	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1656	D	D259	LEIOMIOMA DEL ÚTERO, SIN OTRA ESPECIFICACIÓN	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	092	NO	NO	NO	SI	053	053	17C	17C	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	245	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1657	D	D26	OTROS TUMORES BENIGNOS DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1658	D	D260	TUMOR BENIGNO DEL CUELLO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1659	D	D261	TUMOR BENIGNO DEL CUERPO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1660	D	D267	TUMOR BENIGNO DE OTRAS PARTES ESPECIFICADAS DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1661	D	D269	TUMOR BENIGNO DEL ÚTERO, PARTE NO ESPECIFICADA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1662	D	D27X	TUMOR BENIGNO DEL OVARIO	SI	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	093	NO	NO	NO	SI	054	054	17D	17D	79	25	79	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1663	D	D28	TUMOR BENIGNO DE OTROS ÓRGANOS GENITALES FEMENINOS Y DE LOS NO ESPECIFICADOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1664	D	D280	TUMOR BENIGNO DE LA VULVA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1665	D	D281	TUMOR BENIGNO DE LA VAGINA	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1666	D	D282	TUMOR BENIGNO DE LA TROMPA DE FALOPIO Y DE LOS LIGAMENTOS UTERINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1667	D	D287	TUMOR BENIGNO DE OTROS SITIOS ESPECIFICADOS DE LOS ÓRGANOS GENITALES FEMENINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1668	D	D289	TUMOR BENIGNO DE ÓRGANO GENITAL FEMENINO, SITIO NO ESPECIFICADO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1669	D	D29	TUMOR BENIGNO DE LOS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1670	D	D290	TUMOR BENIGNO DEL PENE	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1671	D	D291	TUMOR BENIGNO DE LA PRÓSTATA	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1672	D	D292	TUMOR BENIGNO DE LOS TESTÍCULOS	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1673	D	D293	TUMOR BENIGNO DEL EPIDÍDIMO	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1674	D	D294	TUMOR BENIGNO DEL ESCROTO	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1675	D	D297	TUMOR BENIGNO DE OTROS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1676	D	D299	TUMOR BENIGNO DE ÓRGANO GENITAL MASCULINO, SITIO NO ESPECIFICADO	NO	1	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1677	D	D30	TUMOR BENIGNO DE LOS ÓRGANOS URINARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1678	D	D300	TUMOR BENIGNO DEL RIÑÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1679	D	D301	TUMOR BENIGNO DE LA PELVIS RENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1680	D	D302	TUMOR BENIGNO DEL URÉTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1681	D	D303	TUMOR BENIGNO DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1682	D	D304	TUMOR BENIGNO DE LA URETRA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1683	D	D307	TUMOR BENIGNO DE OTROS ÓRGANOS URINARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1684	D	D309	TUMOR BENIGNO DE ÓRGANO URINARIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	094	NO	NO	NO	SI	055	055	17E	17E	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1685	D	D31	TUMOR BENIGNO DEL OJO Y SUS ANEXOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1686	D	D310	TUMOR BENIGNO DE LA CONJUNTIVA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1687	D	D311	TUMOR BENIGNO DE LA CÓRNEA	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1688	D	D312	TUMOR BENIGNO DE LA RETINA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1689	D	D313	TUMOR BENIGNO DE LA COROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1690	D	D314	TUMOR BENIGNO DEL CUERPO CILIAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1691	D	D315	TUMOR BENIGNO DE LAS GLÁNDULAS Y DE LOS CONDUCTOS LAGRIMALES	NO	NO	NO	NO	SI	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1692	D	D316	TUMOR BENIGNO DE LA ÓRBITA, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1693	D	D319	TUMOR BENIGNO DEL OJO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1694	D	D32	TUMORES BENIGNOS DE LAS MENINGES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1695	D	D320	TUMOR BENIGNO DE LAS MENINGES CEREBRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1696	D	D321	TUMOR BENIGNO DE LAS MENINGES RAQUÍDEAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1697	D	D329	TUMOR BENIGNO DE LAS MENINGES, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1698	D	D33	TUMOR BENIGNO DEL ENCÉFALO Y DE OTRAS PARTES DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1699	D	D330	TUMOR BENIGNO DEL ENCÉFALO, SUPRATENTORIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1700	D	D331	TUMOR BENIGNO DEL ENCÉFALO, INFRATENTORIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1701	D	D332	TUMOR BENIGNO DEL ENCÉFALO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1702	D	D333	TUMOR BENIGNO DE LOS NERVIOS CRANEALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1703	D	D334	TUMOR BENIGNO DE LA MÉDULA ESPINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1704	D	D337	TUMOR BENIGNO DE OTRAS PARTES ESPECIFICADAS DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1705	D	D339	TUMOR BENIGNO DEL SISTEMA NERVIOSO CENTRAL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	095	NO	NO	NO	SI	056	056	17F	17F	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1706	D	D34X	TUMOR BENIGNO DE LA GLÁNDULA TIROIDES	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	057	057	17G	17G	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1707	D	D35	TUMOR BENIGNO DE OTRAS GLÁNDULAS ENDOCRINAS Y DE LAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1708	D	D350	TUMOR BENIGNO DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1709	D	D351	TUMOR BENIGNO DE LA GLÁNDULA PARATIROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1710	D	D352	TUMOR BENIGNO DE LA HIPÓFISIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1711	D	D353	TUMOR BENIGNO DEL CONDUCTO CRANEOFARINGEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1712	D	D354	TUMOR BENIGNO DE LA GLÁNDULA PINEAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1713	D	D355	TUMOR BENIGNO DEL CUERPO CAROTÍDEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1714	D	D356	TUMOR BENIGNO DEL CUERPO AÓRTICO Y DE OTROS CUERPOS CROMAFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1715	D	D357	TUMOR BENIGNO DE OTRAS GLÁNDULAS ENDOCRINAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1716	D	D358	TUMOR BENIGNO PLURIGLANDULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1717	D	D359	TUMOR BENIGNO DE GLÁNDULA ENDOCRINA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1718	D	D36	TUMOR BENIGNO DE OTROS SITIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1719	D	D360	TUMOR BENIGNO DE LOS GANGLIOS LINFÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1720	D	D361	TUMOR BENIGNO DE LOS NERVIOS PERIFÉRICOS Y DEL SISTEMA NERVIOSO AUTÓNOMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1721	D	D367	TUMOR BENIGNO DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1722	D	D369	TUMOR BENIGNO DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	17Z	17Z	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1723	D	D37	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA CAVIDAD BUCAL Y DE LOS ÓRGANOS DIGESTIVOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1724	D	D370	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL LABIO, DE LA CAVIDAD BUCAL Y DE LA FARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1725	D	D371	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ESTÓMAGO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1726	D	D372	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL INTESTINO DELGADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1727	D	D373	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL APÉNDICE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1728	D	D374	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL COLON	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1729	D	D375	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL RECTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1730	D	D376	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL HÍGADO, DE LA VESÍCULA BILIAR Y DEL CONDUCTO BILIAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1731	D	D377	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS ÓRGANOS DIGESTIVOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1732	D	D379	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE ÓRGANOS DIGESTIVOS, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1733	D	D38	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL OÍDO MEDIO Y DE LOS ÓRGANOS RESPIRATORIOS E INTRATORÁCICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1734	D	D380	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LARINGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1735	D	D381	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA TRÁQUEA, DE LOS BRONQUIOS Y DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1737	D	D383	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL MEDIASTINO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1738	D	D384	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TIMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1739	D	D385	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS ÓRGANOS RESPIRATORIOS Y DEL OÍDO MEDIO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	C	2003 CORRECCION TITUO	2003	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1740	D	D386	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE ÓRGANOS RESPIRATORIOS, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1741	D	D39	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS ÓRGANOS GENITALES FEMENINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1742	D	D390	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ÚTERO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1743	D	D391	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL OVARIO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1745	D	D397	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS ÓRGANOS GENITALES FEMENINOS	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1746	D	D399	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE ÓRGANO GENITAL FEMENINO NO ESPECIFICADO	NO	2	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1747	D	D40	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1748	D	D400	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA PRÓSTATA	NO	1	010A	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1749	D	D401	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TESTÍCULO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1750	D	D407	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS ÓRGANOS GENITALES MASCULINOS	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1751	D	D409	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE ÓRGANO GENITAL MASCULINO NO ESPECIFICADO	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1752	D	D41	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS ÓRGANOS URINARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1736	D	D382	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA PLEURA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1753	D	D410	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL RIÑÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1754	D	D411	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA PELVIS RENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1755	D	D412	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL URÉTER	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1756	D	D413	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA URETRA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1757	D	D414	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA VEJIGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1758	D	D417	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS ÓRGANOS URINARIOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1759	D	D419	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE ÓRGANO URINARIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1760	D	D42	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LAS MENINGES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1761	D	D420	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LAS MENINGES CEREBRALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1762	D	D421	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LAS MENINGES RAQUÍDEAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1763	D	D429	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LAS MENINGES, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1764	D	D43	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ENCÉFALO Y DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1765	D	D430	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ENCÉFALO, SUPRATENTORIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1766	D	D431	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ENCÉFALO, INFRATENTORIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1767	D	D432	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL ENCÉFALO, PARTE NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1768	D	D433	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS NERVIOS CRANEALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1769	D	D434	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA MÉDULA ESPINAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1770	D	D437	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTRAS PARTES ESPECIFICADAS DEL SISTEMA NERVIOSO CENTRAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1771	D	D439	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL SISTEMA NERVIOSO CENTRAL, SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1772	D	D44	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LAS GLÁNDULAS ENDOCRINAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1773	D	D440	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA GLÁNDULA TIROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1774	D	D441	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA GLÁNDULA SUPRARRENAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1775	D	D442	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA GLÁNDULA PARATIROIDES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1776	D	D443	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA GLÁNDULA HIPÓFISIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1777	D	D444	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL CONDUCTO CRANEOFARÍNGEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1778	D	D445	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA GLÁNDULA PINEAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1779	D	D446	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL CUERPO CAROTÍDEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1780	D	D447	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL CUERPO AÓRTICO Y OTROS CUERPOS CROMAFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1781	D	D448	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO CON AFECTACIÓN PLURIGLANDULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1782	D	D449	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE GLÁNDULA ENDOCRINA NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1783	D	D45X	POLICITEMIA VERA	SI	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1784	D	D46	SÍNDROMES MIELODISPLÁSICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1785	D	D460	ANEMIA REFRACTARIA SIN SIDEROBLASTOS EN FORMA DE ANILLO, ASÍ DESCRITA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	C	2018 CAMBIO DE TITULO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1786	D	D461	ANEMIA REFRACTARIA CON SIDEROBLASTOS EN FORMA DE ANILLO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	C	2010 CORRECCION TITULOS	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1787	D	D462	ANEMIA REFRACTARIA CON EXCESO DE BLASTOS [AREB	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	C	2010 CORRECCION TITULOS	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1788	D	D463	ANEMIA REFRACTARIA CON EXCESO DE BLASTOS CON TRANSFORMACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	B	2010 ELIMINAR CATEGORIA	2014	NO	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1789	D	D464	ANEMIA REFRACTARIA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1790	D	D465	ANEMIA REFRACTARIA CON DISPLASIA MULTILINAJE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	A	2010 NUEVA CATEGORIA	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1791	D	D466	SÍNDROME MIELODISPLÁSICO CON ANORMALIDAD CROMOSÓMICA AISLADA DEL (5Q)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	A	2010 NUEVA CATEGORIA	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1792	D	D467	OTROS SÍNDROMES MIELODISPLÁSICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1794	D	D47	OTROS TUMORES DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TEJIDO LINFÁTICO, DE LOS ÓRGANOS HEMATOPOYÉTICOS Y DE TEJIDOS AFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1795	D	D470	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS MASTOCITOS E HISTIOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1793	D	D469	SÍNDROME MIELODISPLÁSICO, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1796	D	D471	ENFERMEDAD MIELOPROLIFERATIVA CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1797	D	D472	GAMMOPATÍA MONOCLONAL DE SIGNIFICADO INCIERTO [GMSI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	C	2010 CORRECCION TITULOS	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1798	D	D473	TROMBOCITOPENIA (HEMORRÁGICA) ESENCIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1799	D	D474	OSTEOMIELOFIBROSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	A	2010 NUEVA CATEGORIA	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1800	D	D475	LEUCEMIA EOSINOFÍLICA CRÓNICA [SÍNDROME HIPEREOSINOFÍLICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	A	2010 NUEVA CATEGORIA	2014	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1801	D	D477	OTROS TUMORES ESPECIFICADOS DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TEJIDO LINFÁTICO, DE LOS ÓRGANOS HEMATOPOYÉTICOS Y DE TEJIDOS AFINES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1802	D	D479	TUMORES DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TEJIDO LINFÁTICO, DE LOS ÓRGANOS HEMATOPOYÉTICOS Y DE TEJIDOS AFINES, NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1803	D	D48	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS SITIOS Y DE LOS NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	NO	NO	NO	25	NO	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1804	D	D480	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL HUESO Y CARTÍLAGO ARTICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1805	D	D481	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL TEJIDO CONJUNTIVO Y OTRO TEJIDO BLANDO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1806	D	D482	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LOS NERVIOS PERIFÉRICOS Y DEL SISTEMA NERVIOSO AUTÓNOMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1807	D	D483	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL RETROPERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1808	D	D484	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DEL PERITONEO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1809	D	D485	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1810	D	D486	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE LA MAMA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1811	D	D487	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO DE OTROS SITIOS ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1812	D	D489	TUMOR DE COMPORTAMIENTO INCIERTO O DESCONOCIDO, DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	SI	SI	02	II    TUMORES (NEOPLASIAS)	047	026	096	NO	NO	NO	SI	999	999	18	18	79	25	79	NO	NO	NO	NO	4	CAUSAS NO ESPECIFICADAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1813	D	D50	ANEMIAS POR DEFICIENCIA DE HIERRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	097	NO	NO	NO	SI	058	058	NO	NO	NO	27	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1814	D	D500	ANEMIA POR DEFICIENCIA DE HIERRO SECUNDARIA A PÉRDIDA DE SANGRE (CRÓNICA)	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	097	NO	NO	NO	SI	058	058	19A	19A	58	27	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1815	D	D501	DISFAGIA SIDEROPÉNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	097	NO	NO	NO	SI	058	058	19A	19A	58	27	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1816	D	D508	OTRAS ANEMIAS POR DEFICIENCIA DE HIERRO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	097	NO	NO	NO	SI	058	058	19A	19A	58	27	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1817	D	D509	ANEMIA POR DEFICIENCIA DE HIERRO SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	097	NO	NO	NO	SI	058	058	19A	19A	58	27	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1818	D	D51	ANEMIA POR DEFICIENCIA DE VITAMINA B12	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	27	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1819	D	D510	ANEMIA POR DEFICIENCIA DE VITAMINA B12 DEBIDA A DEFICIENCIA DEL FACTOR INTRÍNSECO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1820	D	D511	ANEMIA POR DEFICIENCIA DE VITAMINA B12 DEBIDA A MALA ABSORCIÓN SELECTIVA DE VITAMINA B12 CON PROTEINURIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1821	D	D512	DEFICIENCIA DE TRASCOBALAMINA II	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1822	D	D513	OTRAS ANEMIAS POR DEFICIENCIA DIETÉTICA DE VITAMINA B12	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1823	D	D518	OTRAS ANEMIAS POR DEFICIENCIA DE VITAMINA B12	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1824	D	D519	ANEMIA POR DEFICIENCIA DE VITAMINA B12, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	SI	28	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1825	D	D52	ANEMIA POR DEFICIENCIA DE FOLATOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	27	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1826	D	D520	ANEMIA POR DEFICIENCIA DIETÉTICA DE FOLATOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1827	D	D521	ANEMIA POR DEFICIENCIA DE FOLATOS INDUCIDA POR DROGAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1828	D	D528	OTRAS ANEMIAS POR DEFICIENCIA DE FOLATOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1829	D	D529	ANEMIA POR DEFICIENCIA DE FOLATOS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1830	D	D53	OTRAS ANEMIAS NUTRICIONALES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	27	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1831	D	D530	ANEMIA POR DEFICIENCIA DE PROTEÍNAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1832	D	D531	OTRAS ANEMIAS MEGALOBLÁSTICAS, NO CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1833	D	D532	ANEMIA ESCORBÚTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1834	D	D538	OTRAS ANEMIAS NUTRICIONALES ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1835	D	D539	ANEMIA NUTRICIONAL, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	27	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1836	D	D55	ANEMIA DEBIDA A TRASTORNOS ENZIMÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1837	D	D550	ANEMIA DEBIDA A DEFICIENCIA DE GLUCOSA-6-FOSFATO DESHIDROGENASA [G6FD	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1838	D	D551	ANEMIA DEBIDA A OTROS TRASTORNOS DEL METABOLISMO DEL GLUTATIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1839	D	D552	ANEMIA DEBIDA A TRASTORNOS DE LAS ENZIMAS GLUCOLÍTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1840	D	D553	ANEMIA DEBIDA A TRASTORNOS DEL METABOLISMO DE LOS NUCLEÓTIDOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1842	D	D559	ANEMIA DEBIDA A TRASTORNOS ENZIMÁTICOS, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1843	D	D56	TALASEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1844	D	D560	ALFA TALASEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1845	D	D561	BETA TALASEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1846	D	D562	DELTA-BETA TALASEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1847	D	D563	RASGO TALASÉMICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1848	D	D564	PERSISTENCIA HEREDITARIA DE LA HEMOGLOBINA FETAL [PHHF	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1849	D	D568	OTRAS TALASEMIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1850	D	D569	TALASEMIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1851	D	D57	TRASTORNOS FALCIFORMES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1852	D	D570	ANEMIA FALCIFORME CON CRISIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1841	D	D558	OTRAS ANEMIAS DEBIDAS A TRASTORNOS ENZIMÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1853	D	D571	ANEMIA FALCIFORME SIN CRISIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1854	D	D572	TRASTORNOS FALCIFORMES HETEROCIGOTOS DOBLES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1855	D	D573	RASGO DREPANOCÍTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1856	D	D578	OTROS TRASTORNOS FALCIFORMES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1857	D	D58	OTRAS ANEMIAS HEMOLÍTICAS HEREDITARIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1858	D	D580	ESFEROCITOSIS HEREDITARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1859	D	D581	ELIPTOCITOSIS HEREDITARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1860	D	D582	OTRAS HEMOGLOBINOPATÍAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1861	D	D588	OTRAS ANEMIAS HEMOLÍTICAS HEREDITARIAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1862	D	D589	ANEMIA HEMOLÍTICA HEREDITARIA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1863	D	D59	ANEMIA HEMOLÍTICA ADQUIRIDA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1864	D	D590	ANEMIA HEMOLÍTICA AUTOINMUNE INDUCIDA POR DROGAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1865	D	D591	OTRAS ANEMIAS HEMOLÍTICAS AUTOINMUNES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1866	D	D592	ANEMIA HEMOLÍTICA NO AUTOINMUNE INDUCIDA POR DROGAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1867	D	D593	SÍNDROME HEMOLÍTICO-URÉMICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1868	D	D594	OTRAS ANEMIAS HEMOLÍTICAS NO AUTOINMUNES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1869	D	D595	HEMOGLOBINURIA PAROXÍSTICA NOCTURNA [MARCHIAFAVA- MICHELI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1870	D	D596	HEMOGLOBINURIA DEBIDA A HEMÓLISIS POR OTRAS CAUSAS EXTERNAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1871	D	D598	OTRAS ANEMIAS HEMOLÍTICAS ADQUIRIDAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1872	D	D599	ANEMIA HEMOLÍTICA ADQUIRIDA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1873	D	D60	APLASIA ADQUIRIDA, EXCLUSIVA DE LA SERIE ROJA [ERITROBLASTOPENIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1874	D	D600	APLASIA CRÓNICA ADQUIRIDA, EXCLUSIVA DE LA SERIE ROJA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1875	D	D601	APLASIA TRANSITORIA ADQUIRIDA, EXCLUSIVA DE LA SERIE ROJA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1876	D	D608	OTRAS APLASIAS ADQUIRIDAS, EXCLUSIVAS DE LA SERIE ROJA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1877	D	D609	APLASIA ADQUIRIDA, EXCLUSIVA DE LA SERIE ROJA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1878	D	D61	OTRAS ANEMIAS APLÁSTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1879	D	D610	ANEMIA APLÁSTICA CONSTITUCIONAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1880	D	D611	ANEMIA APLÁSTICA INDUCIDA POR DROGAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1881	D	D612	ANEMIA APLÁSTICA DEBIDA A OTROS AGENTES EXTERNOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1882	D	D613	ANEMIA APLÁSTICA IDIOPÁTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1883	D	D618	OTRAS ANEMIAS APLÁSTICAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1884	D	D619	ANEMIA APLÁSTICA, SIN OTRA ESPECIFICACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1885	D	D62X	ANEMIA POSTHEMORRÁGICA AGUDA	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1886	D	D63	ANEMIA EN ENFERMEDADES CRÓNICAS CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	NO	098	NO	NO	NO	SI	058	058	19B	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	SI
1887	D	D630	ANEMIA EN ENFERMEDAD NEOPLÁSICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	NO	098	NO	NO	NO	SI	058	058	19B	NO	NO	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	SI
1888	D	D638	ANEMIA EN OTRAS ENFERMEDADES CRÓNICAS CLASIFICADAS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	NO	098	NO	NO	NO	SI	058	058	19B	NO	NO	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	SI
1889	D	D64	OTRAS ANEMIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1890	D	D640	ANEMIA SIDEROBLÁSTICA HEREDITARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1891	D	D641	ANEMIA SIDEROBLÁSTICA SECUNDARIA A OTRA ENFERMEDAD	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1892	D	D642	ANEMIA SIDEROBLÁSTICA SECUNDARIA, DEBIDA A DROGAS Y TOXINAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1893	D	D643	OTRAS ANEMIAS SIDEROBLÁSTICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1894	D	D644	ANEMIA DISERITROPOYÉTICA CONGÉNITA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1895	D	D648	OTRAS ANEMIAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1896	D	D649	ANEMIA DE TIPO NO ESPECIFICADO	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	049	048	098	NO	NO	NO	SI	058	058	19B	19B	58	88	58	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1897	D	D65X	COAGULACIÓN INTRAVASCULAR DISEMINADA [SÍNDROME DE DESFIBRINACIÓN	SI	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	3	CAUSAS INMEDIATAS	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1898	D	D66X	DEFICIENCIA HEREDITARIA DEL FACTOR VIII	SI	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1899	D	D67X	DEFICIENCIA HEREDITARIA DEL FACTOR IX	SI	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1900	D	D68	OTROS DEFECTOS DE LA COAGULACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1901	D	D680	ENFERMEDAD DE VON WILLEBRAND	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1902	D	D681	DEFICIENCIA HEREDITARIA DEL FACTOR XI	NO	1	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1903	D	D682	DEFICIENCIA HEREDITARIA DE OTROS FACTORES DE LA COAGULACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1904	D	D683	TRASTORNO HEMORRÁGICO DEBIDO A ANTICOAGULANTES CIRCULANTES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	A	2003 NUEVA SUBCATEGORIA	2003	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1905	D	D684	DEFICIENCIA ADQUIRIDA DE FACTORES DE LA COAGULACIÓN	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1906	D	D685	TROMBOFILIA PRIMARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	A	2010 NUEVA CATEGORIA	2014	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1907	D	D686	OTRA TROMBOFILIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	A	2010 NUEVA CATEGORIA	2014	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1908	D	D688	OTROS DEFECTOS ESPECIFICADOS DE LA COAGULACIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1909	D	D689	DEFECTO DE LA COAGULACIÓN, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1910	D	D69	PÚRPURA Y OTRAS AFECCIONES HEMORRÁGICAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1911	D	D690	PÚRPURA ALÉRGICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1912	D	D691	DEFECTO CUALITATIVOS DE LAS PLAQUETAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1913	D	D692	OTRAS PÚRPURAS NO TROMBOCITOPÉNICAS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1914	D	D693	PÚRPURA TROMBOCITOPÉNICA IDIOPÁTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1915	D	D694	OTRAS TROMBOCITOPENIAS PRIMARIAS	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1916	D	D695	TROMBOCITOPENIA SECUNDARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1917	D	D696	TROMBOCITOPENIA NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1918	D	D698	OTRAS AFECCIONES HEMORRÁGICAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1919	D	D699	AFECCIÓN HEMORRÁGICA, NO ESPECIFICADA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	SI	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	999	NO	NO	NO	NO	NO	NO
1920	D	D70X	AGRANULOCITOSIS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1921	D	D71X	TRASTORNOS FUNCIONALES DE LOS POLIMORFONUCLEARES NEUTRÓFILOS	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1922	D	D72	OTROS TRASTORNOS DE LOS LEUCOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1923	D	D720	ANOMALÍAS GENÉTICAS DE LOS LEUCOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1924	D	D721	EOSINOFILIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1925	D	D728	OTROS TRASTORNOS ESPECIFICADOS DE LOS LEUCOCITOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1926	D	D729	TRASTORNO DE LOS LEUCOCITOS, NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1927	D	D73	ENFERMEDADES DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1928	D	D730	HIPOESPLENISMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1929	D	D731	HIPERESPLENISMO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1930	D	D732	ESPLENOMEGALIA CONGESTIVA CRÓNICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1931	D	D733	ABSCESO DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1932	D	D734	QUISTE DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1933	D	D735	INFARTO DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1934	D	D738	OTRAS ENFERMEDADES DEL BAZO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1935	D	D739	ENFERMEDAD DEL BAZO, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1936	D	D74	METAHEMOGLOBINEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1937	D	D740	METAHEMOGLOBINEMIA CONGÉNITA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1938	D	D748	OTRAS METAHEMOGLOBINEMIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1939	D	D749	METAHEMOGLOBINEMIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1940	D	D75	OTRAS ENFERMEDADES DE LA SANGRE Y DE LOS ÓRGANOS HEMATOPOYÉTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1942	D	D751	POLICITEMIA SECUNDARIA	NO	NO	028D	120A	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1941	D	D750	ERITROCITOSIS FAMILIAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1943	D	D752	TROMBOCITOSIS ESENCIAL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	B	2010 ELIMINAR CATEGORIA	2014	NO	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1944	D	D758	OTRAS ENFERMEDADES ESPECIFICADAS DE LA SANGRE Y DE LOS ÓRGANOS HEMATOPOYÉTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1945	D	D759	ENFERMEDAD DE LA SANGRE Y DE LOS ÓRGANOS HEMATOPOYÉTICOS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1946	D	D76	OTRAS ENFERMEDADES ESPECIFICADAS CON PARTICIPACIÓN DEL TEJIDO LINFORRETICULAR Y DEL TEJIDO RETICULOHISTIOCÍTICO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	C	2010 CORRECCION TITULOS	2014	SI	999	999	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1947	D	D760	HISTIOCITOSIS DE LAS CÉLULAS DE LANGERHANS, NO CLASIFICADA EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	B	2010 ELIMINAR CATEGORIA	2014	NO	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1948	D	D761	LINFOHISTIOCITOSIS HEMOFAGOCÍTICA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1949	D	D762	SÍNDROME HEMOFAGOCÍTICO ASOCIADO A INFECCIÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	1	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1950	D	D763	OTROS SÍNDROMES HISTIOCÍTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	099	NO	NO	NO	SI	999	999	19Z	19Z	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1951	D	D77X	OTROS TRASTORNOS DE LA SANGRE Y DE LOS ÓRGANOS HEMATOPOYÉTICOS EN ENFERMEDADES CLASIFICADAS EN OTRA PARTE	SI	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	NO	099	NO	NO	NO	SI	999	999	19Z	NO	NO	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	SI
1952	D	D80	INMUNODEFICIENCIA CON PREDOMINIO DE DEFECTOS DE LOS ANTICUERPOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1953	D	D800	HIPOGAMMAGLOBULINEMIA HEREDITARIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1955	D	D802	DEFICIENCIA SELECTIVA DE INMUNOGLOBULINA A [IGA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1956	D	D803	DEFICIENCIA SELECTIVA DE SUBCLASES DE LA INMUNOGLOBULINA G [IGG	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1957	D	D804	DEFICIENCIA SELECTIVA DE INMUNOGLOBULINA M [IGM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1958	D	D805	INMUNODEFICIENCIA CON INCREMENTO DE INMUNOGLOBULINA M [IGM	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1959	D	D806	DEFICIENCIA DE ANTICUERPOS CON INMUNOGLOBULINAS CASI NORMALES O CON HIPERINMUNOGLOBULINEMIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1960	D	D807	HIPOGAMMAGLOBULINEMIA TRANSITORIA DE LA INFANCIA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1961	D	D808	OTRAS INMUNODEFICIENCIAS CON PREDOMINIO DE DEFECTOS DE LOS ANTICUERPOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1962	D	D809	INMUNODEFICIENCIA CON PREDOMINIO DE DEFECTOS DE LOS ANTICUERPOS, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1963	D	D81	INMUNODEFICIENCIAS COMBINADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1964	D	D810	INMUNODEFICIENCIA COMBINADA SEVERA [IDCS CON DISGENESIA RETICULAR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1965	D	D811	INMUNODEFICIENCIA COMBINADA SEVERA [IDCS CON LINFOCITOPENIA T Y B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1966	D	D812	INMUNODEFICIENCIA COMBINADA SEVERA [IDCS CON CIFRA BAJA O NORMAL DE LINFOCITOS B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1967	D	D813	DEFICIENCIA DE LA ADENOSINA DEAMINASA [ADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1968	D	D814	SÍNDROME DE NEZELOF	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1969	D	D815	DEFICIENCIA DE LA FOSFORILASA PURINONUCLEÓSIDA [FPN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1982	D	D83	INMUNODEFICIENCIA VARIABLE COMÚN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1970	D	D816	DEFICIENCIA DE LA CLASE I DEL COMPLEJO DE HISTOCOMPATIBILIDAD MAYOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1971	D	D817	DEFICIENCIA DE LA CLASE II DEL COMPLEJO DE HISTOCOMPATIBILIDAD MAYOR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1972	D	D818	OTRAS INMUNODEFICIENCIAS COMBINADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1973	D	D819	INMUNODEFICIENCIA COMBINADA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1974	D	D82	INMUNODEFICIENCIA ASOCIADA CON OTROS DEFECTOS MAYORES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1975	D	D820	SÍNDROME DE WISKOTT-ALDRICH	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1976	D	D821	SÍNDROME DE DI GEORGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1977	D	D822	INMUNODEFICIENCIA CON ENANISMO MICROMÉLICO [MIEMBROS CORTOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1978	D	D823	INMUNODEFICIENCIA CONSECUTIVA A RESPUESTA DEFECTUOSA HEREDITARIA CONTRA EL VIRUS DE EPSTEIN-BARR	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1979	D	D824	SÍNDROME DE HIPERINMUNOGLOBULINA E [IGE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1980	D	D828	INMUNODEFICIENCIA ASOCIADA CON OTROS DEFECTOS MAYORES ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1995	D	D861	SARCOIDOSIS DE LOS GANGLIOS LINFÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1996	D	D862	SARCOIDOSIS DEL PULMÓN Y DE LOS GANGLIOS LINFÁTICOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1997	D	D863	SARCOIDOSIS DE LA PIEL	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1998	D	D868	SARCOIDOSIS DE OTROS SITIOS ESPECIFICADOS O DE SITIOS COMBINADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1999	D	D869	SARCOIDOSIS DE SITIO NO ESPECIFICADO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
2000	D	D89	OTROS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD, NO CLASIFICADOS EN OTRA PARTE	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1981	D	D829	INMUNODEFICIENCIA ASOCIADA CON DEFECTOS MAYORES NO ESPECIFICADOS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1983	D	D830	INMUNODEFICIENCIA VARIABLE COMÚN CON PREDOMINIO DE ANORMALIDADES EN EL NÚMERO Y LA FUNCIÓN DE LOS LINFOCITOS B	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1984	D	D831	INMUNODEFICIENCIA VARIABLE COMÚN CON PREDOMINIO DE TRASTORNOS INMUNORREGULADORES DE LOS LINFOCITOS T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1985	D	D832	INMUNODEFICIENCIA VARIABLE COMÚN CON AUTOANTICUERPOS ANTI-B O ANTI-T	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1986	D	D838	OTRAS INMUNODEFICIENCIAS VARIABLES COMUNES	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1987	D	D839	INMUNODEFICIENCIA VARIABLE COMÚN, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1988	D	D84	OTRAS INMUNODEFICIENCIAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1989	D	D840	DEFECTO DE LA FUNCIÓN DEL ANTÍGENO-1 DEL LINFOCITO [LFA-1	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1990	D	D841	DEFECTO DEL SISTEMA DEL COMPLEMENTO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1991	D	D848	OTRAS INMUNODEFICIENCIAS ESPECIFICADAS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1992	D	D849	INMUNODEFICIENCIA, NO ESPECIFICADA	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	2	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
1993	D	D86	SARCOIDOSIS	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	SI	NO	NO	NA	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	NO	NO	NO	88	NO	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	000	NO	NO	NO	NO	NO	NO
1994	D	D860	SARCOIDOSIS DEL PULMÓN	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	SI	NO	SI	SI	3	NO	NO	NO	03	III   ENFERMEDADES DE LA SANGRE Y DE LOS ORGANOS HEMATOPOYETICOS, Y CIERTOS TRASTORNOS QUE AFECTAN EL MECANISMO DE LA INMUNIDAD	050	048	100	NO	NO	NO	SI	059	059	19C	19C	81	88	81	NO	NO	NO	NO	5	CAUSAS ÚTILES PARA MORTALIDAD	NO	NO	NO	NO	NO	0	NO	NO	NO	NO	NO	NO	NO	NO	NO	NO	999	NO	NO	NO	NO	NO	NO
\.


--
-- Data for Name: generos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generos (id_genero, descripcion_genero) FROM stdin;
1	Masculino
2	Femenino
\.


--
-- Data for Name: nacionalidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nacionalidades (descripcion_nacionalidad, id_nacionalidad) FROM stdin;
V-	1
E-	2
No Posee	0
\.


--
-- Data for Name: parroquias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parroquias (id_parroquia, id_municipio, parroquia) FROM stdin;
1139	463	Otras
611	225	El Cafetal
612	225	Las Minas
613	225	Nuestra Señora del Rosario
619	229	Chacao
622	231	El Hatillo
647	241	Leoncio Martínez
648	241	Petare
649	241	Caucagüita
650	241	Filas de Mariche
651	241	La Dolorita
1117	462	Altagracia
1118	462	Antímano
1119	462	Caricuao
1120	462	Catedral
1121	462	Coche
1122	462	El Junquito
1123	462	El Paraíso
1124	462	El Recreo
1125	462	El Valle
1126	462	La Candelaria
1127	462	La Pastora
1128	462	La Vega
1129	462	Macarao
1130	462	San Agustín
1131	462	San Bernardino
1132	462	San José
1133	462	San Juan
1134	462	San Pedro
1135	462	Santa Rosalía
1136	462	Santa Teresa
1137	462	Sucre (Catia)
1138	462	23 de enero
\.


--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personas (doc_identidad, nombres, apellidos, fecha_nacimiento, id_genero, id_person, id_nacionalidad) FROM stdin;
admin	admin	admin	1975-01-01	2	0	1
28117206	Newmans	Rodriguez Robles	1999-02-04	1	67	2
\N	Fernando	Mazales	2020-10-20	1	71	0
	Fernando	Mazale	2020-10-20	1	72	0
\N	Carla	Peratra	2021-02-07	1	75	0
3040400	Carlos	Brener	1980-02-04	1	70	1
11020020	Nathaly	Yepez	1980-02-11	1	76	1
304040404	Maria	Fernandez	1980-02-08	2	77	1
\.


--
-- Data for Name: tipos_de_entrada_caso_epidemi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipos_de_entrada_caso_epidemi (id_tipo_entrada, descripcion_tipo_entrada) FROM stdin;
1	Primerizo
2	Sucesivo
\.


--
-- Data for Name: tipos_operaciones_caso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipos_operaciones_caso (id_tipo_operacion, descripcion_tipo_operacion) FROM stdin;
1	Registro
2	Actualizacion
3	Eliminacion
4	Importacion
\.


--
-- Data for Name: usuario_bitacora; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario_bitacora (usuario_alias, id_bitacora, bitacora_codigo, bitacora_fecha, bitacora_hora_inicio, bitacora_hora_final, bitacora_nivel_usuario, bitacora_year) FROM stdin;
newman206	740	CB893688891	2021-01-04	04:55:58 pm	04:57:32 pm	1	2021
newman206	741	CB070516942	2021-01-04	04:57:36 pm	04:58:43 pm	1	2021
newman206	742	CB061072173	2021-01-04	04:58:47 pm	04:59:12 pm	1	2021
newman206	743	CB314649004	2021-01-04	04:59:12 pm	05:00:01 pm	1	2021
newman206	744	CB892282175	2021-01-04	05:00:05 pm	\N	1	2021
newman206	745	CB141968326	2021-01-05	04:58:39 pm	04:59:14 pm	1	2021
newman206	746	CB220976377	2021-01-05	05:06:32 pm	\N	1	2021
newman206	28719	CB267479998	2021-01-05	09:12:40 pm	09:15:26 pm	1	2021
newman206	28720	CB608469709	2021-01-05	09:21:46 pm	09:22:03 pm	1	2021
newman206	28721	CB8929049610	2021-01-05	09:22:07 pm	09:22:14 pm	1	2021
newman206	28722	CB4087656611	2021-01-05	09:22:26 pm	09:31:59 pm	1	2021
newman206	28723	CB0105040912	2021-01-05	09:37:33 pm	09:38:15 pm	1	2021
newman206	28725	CB8246401514	2021-01-05	09:40:23 pm	09:40:36 pm	1	2021
newman206	28726	CB7630286815	2021-01-05	09:41:29 pm	09:42:04 pm	1	2021
newman206	28727	CB6028713416	2021-01-05	09:42:38 pm	09:47:54 pm	1	2021
newman206	28730	CB9034911718	2021-01-06	08:45:03 am	\N	1	2021
newman206	28731	CB8191803619	2021-01-06	03:15:41 pm	\N	1	2021
newman206	28732	CB6624321920	2021-01-07	10:38:40 am	10:39:01 am	1	2021
newman206	28733	CB7783724221	2021-01-07	10:56:08 am	10:59:06 am	1	2021
newman206	28734	CB0003870022	2021-01-07	10:59:14 am	10:59:22 am	1	2021
admin	28735	CB5487882523	2021-01-07	10:59:32 am	10:59:32 am	1	2021
admin	28736	CB6966131224	2021-01-07	10:59:32 am	\N	1	2021
admin	28737	CB3295785325	2021-01-07	05:30:36 pm	05:30:37 pm	1	2021
admin	28738	CB5209909426	2021-01-07	05:30:37 pm	05:30:39 pm	1	2021
admin	28739	CB0673846427	2021-01-07	05:30:39 pm	05:30:39 pm	1	2021
admin	28740	CB8048484228	2021-01-07	05:30:39 pm	05:57:21 pm	1	2021
admin	28741	CB4561977229	2021-01-07	05:57:33 pm	05:58:07 pm	1	2021
newman206	28742	CB9197109630	2021-01-07	06:29:42 pm	06:30:05 pm	1	2021
admin	28743	CB4421027331	2021-01-07	06:30:12 pm	06:37:44 pm	1	2021
admin	28744	CB5296098432	2021-01-07	06:37:47 pm	06:54:55 pm	1	2021
admin	28746	CB0945916733	2021-01-07	06:55:00 pm	\N	1	2021
newman206	28747	CB0293217134	2021-01-08	09:55:19 am	\N	1	2021
admin	28752	CB4440128839	2021-01-08	03:58:31 pm	\N	1	2021
newman206	28753	CB9236962040	2021-01-08	03:59:24 pm	\N	1	2021
newman206	28754	CB4818747841	2021-01-08	04:00:01 pm	04:01:25 pm	1	2021
newman206	28755	CB4533936242	2021-01-08	04:01:55 pm	04:15:00 pm	1	2021
newman206	28756	CB8606444243	2021-01-08	04:15:54 pm	04:52:29 pm	1	2021
newman206	28757	CB1061019144	2021-01-08	05:01:27 pm	\N	1	2021
admin	28758	CB0687271045	2021-02-03	09:22:55 pm	09:32:54 pm	1	2021
newman206	28748	CB4545436435	2021-01-08	12:21:06 pm	12:31:50 pm	1	2021
newman206	28749	CB5192968636	2021-01-08	12:32:20 pm	12:32:44 pm	1	2021
newman206	28750	CB4200285637	2021-01-08	12:32:47 pm	12:33:41 pm	1	2021
newman206	28751	CB9610788938	2021-01-08	12:33:45 pm	12:38:03 pm	1	2021
admin	28759	CB2499741646	2021-02-03	09:32:57 pm	10:17:49 pm	1	2021
admin	28761	CB5627558547	2021-02-03	10:17:53 pm	\N	1	2021
admin	28762	CB1864128348	2021-02-03	10:32:13 pm	\N	1	2021
admin	28763	CB3265308249	2021-02-03	11:38:24 pm	\N	1	2021
admin	28764	CB9765676050	2021-02-03	11:41:11 pm	\N	1	2021
admin	28765	CB1160378251	2021-02-04	12:04:49 am	\N	1	2021
admin	28766	CB6806199152	2021-02-04	12:09:12 am	\N	1	2021
admin	28768	CB8640231254	2021-02-04	08:34:39 am	\N	1	2021
admin	28767	CB7170897553	2021-02-04	08:34:37 am	08:34:39 am	1	2021
admin	28770	CB7163499856	2021-02-04	08:43:11 am	\N	1	2021
admin	28769	CB9829840155	2021-02-04	08:34:39 am	08:56:53 am	1	2021
admin	28771	CB1352327357	2021-02-04	08:57:37 am	09:10:19 am	1	2021
admin	28772	CB3392499958	2021-02-04	09:10:36 am	09:10:43 am	1	2021
admin	28773	CB3845047559	2021-02-04	09:34:23 am	09:57:32 am	1	2021
admin	28774	CB9265694960	2021-02-04	10:41:17 am	11:12:24 am	1	2021
admin	28775	CB9154232961	2021-02-04	11:31:44 am	11:59:28 am	1	2021
admin	28776	CB6264359662	2021-02-04	12:09:10 pm	\N	1	2021
admin	28777	CB5624119663	2021-02-04	06:08:38 pm	\N	1	2021
admin	28778	CB5426011064	2021-02-04	11:18:32 pm	\N	1	2021
admin	28790	CB1047608165	2021-02-05	09:54:18 am	\N	1	2021
admin	28794	CB2569372066	2021-02-05	03:21:14 pm	\N	1	2021
admin	28799	CB6213192867	2021-02-05	04:49:21 pm	\N	1	2021
admin	28807	CB6938635368	2021-02-06	11:23:49 am	\N	1	2021
admin	28814	CB3613977069	2021-02-06	03:32:03 pm	\N	1	2021
admin	28821	CB3236945670	2021-02-06	05:46:05 pm	\N	1	2021
admin	28822	CB6040560871	2021-02-06	07:14:11 pm	\N	1	2021
admin	28823	CB9507960172	2021-02-06	08:43:19 pm	\N	1	2021
admin	28829	CB3173707973	2021-02-07	09:21:17 am	\N	1	2021
admin	28830	CB5940905174	2021-02-07	10:26:19 am	\N	1	2021
admin	28831	CB2521981575	2021-02-07	07:04:06 pm	\N	1	2021
admin	28832	CB7160125076	2021-02-08	11:17:01 am	\N	1	2021
admin	28833	CB8088452677	2021-02-08	07:42:41 pm	\N	1	2021
admin	28834	CB5697906378	2021-02-08	09:22:05 pm	\N	1	2021
admin	28835	CB6274425279	2021-02-09	11:15:13 am	\N	1	2021
admin	28838	CB6337286280	2021-02-09	05:50:44 pm	08:40:18 pm	1	2021
admin	28839	CB6763064581	2021-02-09	08:41:10 pm	08:44:35 pm	1	2021
admin	28840	CB5041659782	2021-02-09	08:44:57 pm	\N	1	2021
admin	28841	CB0800154583	2021-02-11	12:08:22 am	\N	1	2021
admin	28874	CB4169050684	2021-02-11	01:13:34 am	\N	1	2021
admin	28895	CB1346438285	2021-02-11	09:34:37 pm	\N	1	2021
admin	28897	CB3123340186	2021-02-11	10:27:30 pm	\N	1	2021
admin	28906	CB3012164987	2021-02-12	09:57:53 pm	\N	1	2021
admin	28909	CB8157473486	2021-02-13	12:09:19 pm	12:09:20 pm	1	2021
admin	28910	CB8683597187	2021-02-13	12:09:20 pm	\N	1	2021
admin	28912	CB2345160888	2021-02-13	02:27:10 pm	\N	1	2021
admin	28917	CB0437115889	2021-02-13	05:17:01 pm	05:18:22 pm	1	2021
admin	28918	CB0813371690	2021-02-13	05:18:23 pm	05:18:23 pm	1	2021
admin	28919	CB8268287991	2021-02-13	05:18:23 pm	05:18:45 pm	1	2021
admin	28920	CB8031226392	2021-02-13	05:18:45 pm	05:18:53 pm	1	2021
admin	28921	CB8330224393	2021-02-13	05:18:54 pm	05:19:56 pm	1	2021
admin	28922	CB9650090894	2021-02-13	05:19:56 pm	05:20:12 pm	1	2021
admin	28923	CB3042111395	2021-02-13	05:20:12 pm	05:20:21 pm	1	2021
admin	28924	CB0765146596	2021-02-13	09:38:12 pm	09:38:22 pm	1	2021
admin	28925	CB0623866097	2021-02-13	09:39:05 pm	\N	1	2021
admin	28926	CB1387624898	2021-02-14	10:23:55 am	10:50:20 am	1	2021
admin	28927	CB7266557199	2021-02-14	10:50:24 am	11:45:37 am	1	2021
admin	28931	CB23964576100	2021-02-14	11:45:58 am	12:02:21 pm	1	2021
admin	28932	CB83418803101	2021-02-14	12:02:24 pm	\N	1	2021
admin	28933	CB04393774102	2021-02-14	09:16:55 pm	09:17:46 pm	1	2021
admin	28934	CB88104523103	2021-02-14	09:20:33 pm	09:20:52 pm	1	2021
admin	28935	CB91967149104	2021-02-14	09:22:57 pm	09:24:13 pm	1	2021
newman207	28936	CB40906787105	2021-02-14	09:25:09 pm	10:38:56 pm	2	2021
admin	28937	CB10515501106	2021-02-14	10:39:02 pm	10:42:17 pm	1	2021
newman207	28938	CB85399868107	2021-02-14	10:42:20 pm	10:43:28 pm	3	2021
admin	28939	CB19434525108	2021-02-14	10:43:32 pm	10:43:58 pm	1	2021
newman207	28940	CB15178102109	2021-02-14	10:44:02 pm	\N	1	2021
admin	28941	CB12159200110	2021-02-15	10:47:28 am	10:47:30 am	1	2021
admin	28942	CB70922476111	2021-02-15	10:47:30 am	\N	1	2021
admin	28943	CB57720997112	2021-02-15	12:49:37 pm	\N	1	2021
admin	28946	CB41242056113	2021-02-15	02:42:35 pm	\N	1	2021
admin	28948	CB35844750114	2021-02-15	04:12:11 pm	04:12:17 pm	1	2021
newman207	28949	CB90084389115	2021-02-15	04:12:22 pm	\N	1	2021
newman207	28950	CB92256612116	2021-02-15	09:21:05 pm	\N	1	2021
newman207	28962	CB42502422117	2021-02-16	11:45:20 am	\N	1	2021
admin	28963	CB51088990118	2021-02-16	03:22:17 pm	\N	1	2021
admin	28964	CB36861680119	2021-02-16	06:50:58 pm	\N	1	2021
admin	28965	CB12418069120	2021-02-16	09:59:46 pm	\N	1	2021
admin	28967	CB02748881121	2021-02-17	09:24:00 am	\N	1	2021
newman207	28968	CB64666910122	2021-02-17	02:06:09 pm	\N	1	2021
newman207	28969	CB64208565123	2021-02-18	03:17:21 pm	\N	1	2021
newman207	28970	CB71189139124	2021-02-18	04:23:55 pm	\N	1	2021
newman207	28971	CB95386498125	2021-02-18	08:40:49 pm	\N	1	2021
newman207	28972	CB40895084126	2021-02-19	05:29:41 pm	\N	1	2021
newman207	28973	CB82447795127	2021-02-19	06:33:27 pm	\N	1	2021
newman207	28974	CB03753411128	2021-02-19	09:18:02 pm	10:09:53 pm	1	2021
newman207	28975	CB71946372129	2021-02-19	10:16:02 pm	10:16:47 pm	1	2021
newman207	28976	CB45011121130	2021-02-19	10:16:52 pm	10:19:30 pm	1	2021
newman207	28977	CB14118302131	2021-02-19	10:19:37 pm	\N	1	2021
newman207	28978	CB56261192132	2021-02-20	11:07:41 am	\N	1	2021
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (alias, id_nivel_permiso, id_estado, pass_encrypt, email, telefono, id_person) FROM stdin;
admin	1	1	Z1M5RlRDMFQ4aTlIZURQSWdrWTJmZz09	admin	admin	0
newman206	1	0	Wk8vdWFYT1YwVDV0WGhLVGZ1aVJtZz09	newman2@gmail.com	04120293034	1
newman207	1	1	Wk8vdWFYT1YwVDV0WGhLVGZ1aVJtZz09	newmanrodriguez1999@gmail.com	04120304098	67
maria222	1	1	ckJ3aVRDRnhpcmx2MXJYWVljUUt3UT09	marianati11@gmail.com	04123030303	77
nataly1818	1	1	YWFyanpjcU5wRmxIcFV3VG1OQ0dudz09	nataly1818@gmail.com	04120404003	76
\.


--
-- Data for Name: usuarios_estados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios_estados (id_estado, descripcion_estado) FROM stdin;
0	Inactivo
1	Activo
2	Reiniciado
\.


--
-- Data for Name: usuarios_niveles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios_niveles (id_nivel_permiso, descripcion_nivel_permiso) FROM stdin;
1	Administrador
2	Normal
3	Invitado
\.


--
-- Data for Name: usuarios_preguntas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios_preguntas (usuario_alias, id_pregunta, respuesta) FROM stdin;
admin	1	Nlptb2h3SnNmK1oxamJ4WkNRWk1qUT09
admin	2	UUhWdXVUWXhhenNUTVRUUGxxZEIvQT09
newman206	1	eDJORGNVUURPK2xnS0JnY0xxcFVEdz09
newman206	2	TnNXZW9hOS9mN29jRHpUbnIxZVVldz09
newman207	1	eDJORGNVUURPK2xnS0JnY0xxcFVEdz09
newman207	2	TnNXZW9hOS9mN29jRHpUbnIxZVVldz09
nataly1818	1	T1lCbU81UHgyUWZPaTZRelo2eWZ6Zz09
nataly1818	2	SzFMMU0vYk9YcHJsRk5hTzMxcnc1Zz09
maria222	1	T1lCbU81UHgyUWZPaTZRelo2eWZ6Zz09
maria222	2	SzFMMU0vYk9YcHJsRk5hTzMxcnc1Zz09
\.


--
-- Data for Name: usuarios_preguntas_disponibles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios_preguntas_disponibles (id_pregunta, descripcion_preguntas) FROM stdin;
1	¿Cual fue el nombre de tu primera mascota?
2	¿Cual es el nombre de tu artista favorita?
\.


--
-- Name: agrupacion_epi12_id_agrupacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agrupacion_epi12_id_agrupacion_seq', 10, true);


--
-- Name: agrupacion_epi12_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agrupacion_epi12_seq', 1, false);


--
-- Name: atribs_especiales_cie10_id_atrib_rango_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.atribs_especiales_cie10_id_atrib_rango_seq', 2, true);


--
-- Name: bitacora_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bitacora_seq', 28978, true);


--
-- Name: casos_epidemi_bitacora_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.casos_epidemi_bitacora_seq', 12708, true);


--
-- Name: casos_epidemi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.casos_epidemi_seq', 1, false);


--
-- Name: casos_epidemiologicos_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.casos_epidemiologicos_seq', 1, false);


--
-- Name: parroquias_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parroquias_seq', 1, false);


--
-- Name: person_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.person_seq', 1, false);


--
-- Name: persona_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.persona_seq', 77, true);


--
-- Name: tipos_operaciones_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipos_operaciones_seq', 3, true);


--
-- Name: agrupacion_epi agrupacion_epi12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agrupacion_epi
    ADD CONSTRAINT agrupacion_epi12_pkey PRIMARY KEY (id_agrupacion);


--
-- Name: atribs_especiales_epi atribs_especiales_cie10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atribs_especiales_epi
    ADD CONSTRAINT atribs_especiales_cie10_pkey PRIMARY KEY (id_atrib_especial);


--
-- Name: usuario_bitacora bitacora_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario_bitacora
    ADD CONSTRAINT bitacora_pkey PRIMARY KEY (id_bitacora);


--
-- Name: casos_epidemi casosEpidemi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi
    ADD CONSTRAINT "casosEpidemi_pkey" PRIMARY KEY (id_caso_epidemi);


--
-- Name: casos_epidemi_bitacora casos_epidemi_bitacora_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi_bitacora
    ADD CONSTRAINT casos_epidemi_bitacora_pkey PRIMARY KEY (id_bitacora);


--
-- Name: data_cie10 data_cie10_catalog_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_cie10
    ADD CONSTRAINT data_cie10_catalog_key_key UNIQUE (catalog_key);


--
-- Name: data_cie10 data_cie10_consecutivo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_cie10
    ADD CONSTRAINT data_cie10_consecutivo_key UNIQUE (consecutivo);


--
-- Name: data_cie10 data_cie10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_cie10
    ADD CONSTRAINT data_cie10_pkey PRIMARY KEY (catalog_key);


--
-- Name: generos generos_idGenero_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generos
    ADD CONSTRAINT "generos_idGenero_key" UNIQUE (id_genero);


--
-- Name: generos generos_idGenero_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generos
    ADD CONSTRAINT "generos_idGenero_key1" UNIQUE (id_genero);


--
-- Name: generos generos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generos
    ADD CONSTRAINT generos_pkey PRIMARY KEY (id_genero);


--
-- Name: nacionalidades nacionalidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nacionalidades
    ADD CONSTRAINT nacionalidad_pkey PRIMARY KEY (id_nacionalidad);


--
-- Name: parroquias parroquias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parroquias
    ADD CONSTRAINT parroquias_pkey PRIMARY KEY (id_parroquia);


--
-- Name: personas personas_id_nacionalidad_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.personas
    ADD CONSTRAINT personas_id_nacionalidad_check CHECK ((id_nacionalidad < 3)) NOT VALID;


--
-- Name: personas personas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_pkey PRIMARY KEY (id_person);


--
-- Name: tipos_de_entrada_caso_epidemi tipos_de_entrada_caso_epidemi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_de_entrada_caso_epidemi
    ADD CONSTRAINT tipos_de_entrada_caso_epidemi_pkey PRIMARY KEY (id_tipo_entrada);


--
-- Name: tipos_operaciones_caso tipos_operaciones_descripcion_tipo_operacion_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_operaciones_caso
    ADD CONSTRAINT tipos_operaciones_descripcion_tipo_operacion_key UNIQUE (descripcion_tipo_operacion);


--
-- Name: tipos_operaciones_caso tipos_operaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_operaciones_caso
    ADD CONSTRAINT tipos_operaciones_pkey PRIMARY KEY (id_tipo_operacion);


--
-- Name: usuarios_estados usuariosEstados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_estados
    ADD CONSTRAINT "usuariosEstados_pkey" PRIMARY KEY (id_estado);


--
-- Name: usuarios_niveles usuariosNiveles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_niveles
    ADD CONSTRAINT "usuariosNiveles_pkey" PRIMARY KEY (id_nivel_permiso);


--
-- Name: usuarios_preguntas_disponibles usuariosPreguntasDisponibles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_preguntas_disponibles
    ADD CONSTRAINT "usuariosPreguntasDisponibles_pkey" PRIMARY KEY (id_pregunta);


--
-- Name: usuarios_preguntas usuariosPreguntas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_preguntas
    ADD CONSTRAINT "usuariosPreguntas_pkey" PRIMARY KEY (usuario_alias, id_pregunta);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (alias);


--
-- Name: fki_casos_epidemi_bitacora_ibfk_1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_casos_epidemi_bitacora_ibfk_1 ON public.casos_epidemi USING btree (id_parroquia);


--
-- Name: fki_casos_epidemi_bitacora_ibfk_2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_casos_epidemi_bitacora_ibfk_2 ON public.casos_epidemi_bitacora USING btree (id_person_caso);


--
-- Name: fki_casos_epidemi_bitacora_ibfk_3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_casos_epidemi_bitacora_ibfk_3 ON public.casos_epidemi USING btree (catalog_key_cie10);


--
-- Name: fki_casos_epidemi_bitacora_ibkf_3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_casos_epidemi_bitacora_ibkf_3 ON public.casos_epidemi_bitacora USING btree (id_tipo_operacion);


--
-- Name: fki_casos_epidemi_fkey4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_casos_epidemi_fkey4 ON public.casos_epidemi USING btree (id_tipo_entrada);


--
-- Name: fki_orden_informe_casos_epidemi_bitacora_ibfk_1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_orden_informe_casos_epidemi_bitacora_ibfk_1 ON public.agrupacion_epi USING btree (key_cie10_inicio);


--
-- Name: fki_orden_informe_casos_epidemi_bitacora_ibfk_3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_orden_informe_casos_epidemi_bitacora_ibfk_3 ON public.agrupacion_epi USING btree (key_cie10_final);


--
-- Name: fki_personas_fkey3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_personas_fkey3 ON public.personas USING btree (id_nacionalidad);


--
-- Name: fki_usuarios_fkey3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_usuarios_fkey3 ON public.usuarios USING btree (id_person);


--
-- Name: casos_epidemi_bitacora casos_epidemi_bitacora_ibkf_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi_bitacora
    ADD CONSTRAINT casos_epidemi_bitacora_ibkf_3 FOREIGN KEY (id_tipo_operacion) REFERENCES public.tipos_operaciones_caso(id_tipo_operacion) NOT VALID;


--
-- Name: casos_epidemi casos_epidemi_fkey4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi
    ADD CONSTRAINT casos_epidemi_fkey4 FOREIGN KEY (id_tipo_entrada) REFERENCES public.tipos_de_entrada_caso_epidemi(id_tipo_entrada) NOT VALID;


--
-- Name: casos_epidemi casos_epidemi_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi
    ADD CONSTRAINT casos_epidemi_ibfk_1 FOREIGN KEY (id_parroquia) REFERENCES public.parroquias(id_parroquia) NOT VALID;


--
-- Name: casos_epidemi casos_epidemi_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi
    ADD CONSTRAINT casos_epidemi_ibfk_2 FOREIGN KEY (id_person) REFERENCES public.personas(id_person) NOT VALID;


--
-- Name: casos_epidemi casos_epidemi_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.casos_epidemi
    ADD CONSTRAINT casos_epidemi_ibfk_3 FOREIGN KEY (catalog_key_cie10) REFERENCES public.data_cie10(catalog_key) ON UPDATE CASCADE NOT VALID;


--
-- Name: personas personas_fkey3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_fkey3 FOREIGN KEY (id_nacionalidad) REFERENCES public.nacionalidades(id_nacionalidad) NOT VALID;


--
-- Name: personas personas_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_ibfk_1 FOREIGN KEY (id_genero) REFERENCES public.generos(id_genero) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios usuarios_fkey3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_fkey3 FOREIGN KEY (id_person) REFERENCES public.personas(id_person) NOT VALID;


--
-- Name: usuarios usuarios_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_ibfk_1 FOREIGN KEY (id_nivel_permiso) REFERENCES public.usuarios_niveles(id_nivel_permiso) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios usuarios_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_ibfk_3 FOREIGN KEY (id_estado) REFERENCES public.usuarios_estados(id_estado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios_preguntas usuariospreguntas_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_preguntas
    ADD CONSTRAINT usuariospreguntas_ibfk_1 FOREIGN KEY (usuario_alias) REFERENCES public.usuarios(alias) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuarios_preguntas usuariospreguntas_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios_preguntas
    ADD CONSTRAINT usuariospreguntas_ibfk_3 FOREIGN KEY (id_pregunta) REFERENCES public.usuarios_preguntas_disponibles(id_pregunta) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

